# Chapter 4: Crop threshold, input saturation and UK pollinator association screens
# Per-crop GAM fitting with ceiling detection, climate-pesticide Kendall screen,
# and UK pollinator negative-control screen.
# Produces the tables and figures for the pollinator analysis section of Chapter 4.
#
# Inputs:
#   CH4_Results/CH4_Combined_Spain_UK_panel_1970_2024_with_biodiv_extras.csv
#   CH4_newData/StapleCrops.csv
#
# Outputs (in CH4_Results/):
#   CH4_crop_panel_thresholds_input_climate.csv
#   CH4_crop_threshold_gam_screen.csv
#   CH4_input_saturation_ceiling_screen.csv
#   CH4_climate_input_pesticide_kendall_screen.csv
#   CH4_UK_pollinator_crop_response_screen.csv
#   Figures in Figures_CH4_crop_thresholds/

suppressPackageStartupMessages({
  library(dplyr); library(readr); library(tidyr); library(stringr)
  library(purrr); library(ggplot2); library(mgcv); library(zoo); library(viridis)
})

ROOT       <- "~/Documents/FoodSecurityV2"
RESULT_DIR <- file.path(ROOT, "CH4_Results")
FIG_DIR    <- file.path(RESULT_DIR, "Figures_CH4_crop_thresholds")
dir.create(FIG_DIR, recursive = TRUE, showWarnings = FALSE)

df      <- readr::read_csv(file.path(RESULT_DIR,
             "CH4_Combined_Spain_UK_panel_1970_2024_with_biodiv_extras.csv"),
             show_col_types = FALSE)
staples <- readr::read_csv(file.path(ROOT, "CH4_newData", "StapleCrops.csv"),
             show_col_types = FALSE)

theme_ch4 <- function(base_size = 10) {
  ggplot2::theme_classic(base_size = base_size) +
    ggplot2::theme(
      plot.title         = ggplot2::element_text(face="bold", size=base_size+3),
      plot.subtitle      = ggplot2::element_text(size=base_size-1, margin=ggplot2::margin(b=6)),
      axis.title         = ggplot2::element_text(face="bold", size=base_size),
      axis.text          = ggplot2::element_text(size=base_size-1),
      strip.text         = ggplot2::element_text(face="bold", size=base_size-1),
      legend.position    = "bottom",
      panel.grid.major.y = ggplot2::element_line(colour="grey90", linewidth=0.22),
      panel.grid.major.x = ggplot2::element_blank(),
      panel.grid.minor   = ggplot2::element_blank(),
      plot.margin        = ggplot2::margin(10,12,10,10)
    )
}

save_plot <- function(p, filename, width=10, height=7)
  ggplot2::ggsave(file.path(FIG_DIR, filename), p, width=width, height=height, dpi=320, bg="white")

safe_cor <- function(x, y) {
  ok <- stats::complete.cases(x, y)
  if (sum(ok) < 8) return(c(tau=NA_real_, p=NA_real_, n=sum(ok)))
  kt <- suppressWarnings(stats::cor.test(x[ok], y[ok], method="kendall", exact=FALSE))
  c(tau=unname(kt$estimate), p=kt$p.value, n=sum(ok))
}

crop_items <- c("Wheat","Barley","Oats","Rye","Rice","Maize","Potatoes",
                "Beans, dry","Broad beans and horse beans, dry","Lentils, dry","Peas, dry")

crop_panel <- staples |>
  dplyr::filter(Item %in% crop_items, Element %in% c("Yield","Area harvested"),
                Year >= 1970, Year <= 2024,
                Area %in% c("Spain","United Kingdom of Great Britain and Northern Ireland")) |>
  dplyr::mutate(Country=dplyr::if_else(Area=="Spain","Spain","UK"), Crop=Item,
                Crop_group=dplyr::case_when(
                  Crop %in% c("Wheat","Barley","Oats","Rye","Rice","Maize") ~ "Cereal",
                  Crop=="Potatoes" ~ "Tuber", TRUE ~ "Pulse")) |>
  dplyr::select(Country, Year, Crop, Crop_group, Element, Value) |>
  tidyr::pivot_wider(names_from=Element, values_from=Value) |>
  dplyr::rename(Yield_crop_kg_ha=Yield, HarvestedArea_crop_ha=`Area harvested`) |>
  dplyr::left_join(df, by=c("Country","Year")) |>
  dplyr::arrange(Country, Crop, Year) |>
  dplyr::group_by(Country, Crop) |>
  dplyr::mutate(
    Yield_yoy_pct        = 100*(Yield_crop_kg_ha-dplyr::lag(Yield_crop_kg_ha))/dplyr::lag(Yield_crop_kg_ha),
    N_eff_crop           = Yield_crop_kg_ha / N_kg_ha,
    P_eff_crop           = Yield_crop_kg_ha / P_kg_ha,
    K_eff_crop           = Yield_crop_kg_ha / K_kg_ha,
    Pesticide_eff_crop   = Yield_crop_kg_ha / Pesticide_kg_ha,
    Total_input_kg_ha    = N_kg_ha + P_kg_ha + K_kg_ha + Pesticide_kg_ha,
    Total_input_eff_crop = Yield_crop_kg_ha / Total_input_kg_ha,
    BII_interp           = zoo::na.approx(BII, Year, na.rm=FALSE),
    BIIFP_interp         = zoo::na.approx(BII_loss_footprint_total_km2, Year, na.rm=FALSE)
  ) |>
  dplyr::ungroup()

readr::write_csv(crop_panel, file.path(RESULT_DIR, "CH4_crop_panel_thresholds_input_climate.csv"))

climate_vars <- intersect(
  c("bio1","bio2","bio4","bio5","bio6","bio7","bio12","bio13","bio14","bio15",
    "aet_annual_sum_mm","def_annual_sum_mm","soil_annual_mean_mm","pdsi_annual_mean",
    "tmean_mean_DJF","tmean_mean_MAM","tmean_mean_JJA","tmean_mean_SON",
    "ppt_sum_DJF","ppt_sum_MAM","ppt_sum_JJA","ppt_sum_SON",
    "def_sum_DJF","def_sum_MAM","def_sum_JJA","def_sum_SON",
    "pdsi_mean_DJF","pdsi_mean_MAM","pdsi_mean_JJA","pdsi_mean_SON"),
  names(crop_panel))

input_vars <- intersect(
  c("N_kg_ha","P_kg_ha","K_kg_ha","Pesticide_kg_ha","Pesticide_tonnes",
    "Herbicides_tonnes","Insecticides_tonnes","Fungicides_Bactericides_tonnes",
    "PlantGrowthRegulators_tonnes","OtherPesticides_tonnes","Rodenticides_tonnes"),
  names(crop_panel))

biodiv_vars <- intersect(
  c("BII","BII_interp","BII_loss_footprint_total_km2","BIIFP_interp","UK_pollinator_index"),
  names(crop_panel))

responses <- intersect(
  c("Yield_crop_kg_ha","HarvestedArea_crop_ha","Yield_yoy_pct",
    "N_eff_crop","P_eff_crop","K_eff_crop","Pesticide_eff_crop","Total_input_eff_crop"),
  names(crop_panel))

predictors <- c(climate_vars, input_vars, biodiv_vars)

# GAM screen with ceiling detection
fit_gam_ceiling <- function(dat, response, predictor) {
  d <- dplyr::select(dat, dplyr::all_of(c(response, predictor))) |> dplyr::filter(stats::complete.cases(dat[c(response,predictor)]))
  if (nrow(d) < 10 || length(unique(d[[predictor]])) < 5)
    return(tibble::tibble(response=response, predictor=predictor, n=nrow(d),
                          r_sq=NA_real_, dev_explained=NA_real_, edf=NA_real_,
                          p_value_smooth=NA_real_, possible_ceiling=FALSE, ceiling_x=NA_real_))
  k_use <- min(5, max(3, floor(nrow(d)/4)))
  m <- tryCatch(
    mgcv::gam(as.formula(paste0(response," ~ s(",predictor,", k=",k_use,")")),
              data=d, method="REML"), error=function(e) NULL)
  if (is.null(m))
    return(tibble::tibble(response=response, predictor=predictor, n=nrow(d),
                          r_sq=NA_real_, dev_explained=NA_real_, edf=NA_real_,
                          p_value_smooth=NA_real_, possible_ceiling=FALSE, ceiling_x=NA_real_))
  xseq <- seq(min(d[[predictor]], na.rm=TRUE), max(d[[predictor]], na.rm=TRUE), length.out=200)
  pred_df <- tibble::tibble(!!predictor := xseq)
  pr   <- stats::predict(m, newdata=pred_df, se.fit=TRUE)
  fits <- as.numeric(pr$fit)
  slps <- c(NA, diff(fits)/diff(xseq))
  max_sl <- max(abs(slps), na.rm=TRUE)
  cand   <- which(xseq >= stats::quantile(xseq, 0.65) & fits >= stats::quantile(fits, 0.80) & abs(slps) <= 0.15*max_sl)
  ceiling_x <- if (length(cand) > 0) min(xseq[cand]) else NA_real_
  sm <- summary(m)
  tibble::tibble(response=response, predictor=predictor, n=nrow(d),
    r_sq=sm$r.sq, dev_explained=sm$dev.expl, edf=sm$s.table[1,"edf"],
    p_value_smooth=sm$s.table[1,"p-value"], possible_ceiling=!is.na(ceiling_x), ceiling_x=ceiling_x)
}

gam_screen <- crop_panel |>
  dplyr::group_by(Country, Crop, Crop_group) |>
  dplyr::group_modify(~{
    purrr::map_dfr(responses, function(r) purrr::map_dfr(predictors, function(p) fit_gam_ceiling(.x, r, p)))
  }) |>
  dplyr::ungroup() |>
  dplyr::arrange(dplyr::desc(dev_explained))

readr::write_csv(gam_screen, file.path(RESULT_DIR, "CH4_crop_threshold_gam_screen.csv"))

readr::write_csv(
  dplyr::filter(gam_screen,
    response %in% c("Yield_crop_kg_ha","N_eff_crop","P_eff_crop","K_eff_crop",
                    "Pesticide_eff_crop","Total_input_eff_crop"),
    predictor %in% input_vars, !is.na(dev_explained), n >= 10) |>
  dplyr::arrange(dplyr::desc(possible_ceiling), dplyr::desc(dev_explained)),
  file.path(RESULT_DIR, "CH4_input_saturation_ceiling_screen.csv"))

# Climate-pesticide Kendall screen
readr::write_csv(
  crop_panel |>
    dplyr::select(Country, Year, dplyr::all_of(c(climate_vars, input_vars))) |>
    dplyr::distinct() |>
    tidyr::pivot_longer(dplyr::all_of(input_vars), names_to="input", values_to="input_value") |>
    dplyr::filter(!is.na(input_value)) |>
    dplyr::group_by(Country, input) |>
    dplyr::group_modify(~{
      purrr::map_dfr(climate_vars, function(cl) {
        out <- safe_cor(.x[[cl]], .x$input_value)
        tibble::tibble(climate=cl, n=out[["n"]], tau=out[["tau"]], p_value=out[["p"]])
      })
    }) |>
    dplyr::ungroup() |>
    dplyr::arrange(p_value),
  file.path(RESULT_DIR, "CH4_climate_input_pesticide_kendall_screen.csv"))

# UK pollinator negative-control screen
readr::write_csv(
  crop_panel |>
    dplyr::filter(Country == "UK") |>
    dplyr::group_by(Crop, Crop_group) |>
    dplyr::group_modify(~{
      purrr::map_dfr(responses, function(r) {
        if (!r %in% names(.x)) return(NULL)
        out <- safe_cor(.x$UK_pollinator_index, .x[[r]])
        tibble::tibble(response=r, predictor="UK_pollinator_index",
                       n=out[["n"]], tau=out[["tau"]], p_value=out[["p"]])
      })
    }) |>
    dplyr::ungroup() |>
    dplyr::arrange(p_value),
  file.path(RESULT_DIR, "CH4_UK_pollinator_crop_response_screen.csv"))

# Plotting function
plot_gam_ombre <- function(data, country, crop, response, predictor, filename, title=NULL) {
  d <- data |>
    dplyr::filter(Country==country, Crop==crop) |>
    dplyr::select(Year, dplyr::all_of(c(response, predictor))) |>
    dplyr::filter(stats::complete.cases(data[data$Country==country & data$Crop==crop, c(response,predictor)])) |>
    dplyr::arrange(Year)
  if (nrow(d) < 10 || length(unique(d[[predictor]])) < 5) return(NULL)
  k_use <- min(5, max(3, floor(nrow(d)/4)))
  m <- tryCatch(
    mgcv::gam(as.formula(paste0(response," ~ s(",predictor,", k=",k_use,")")),
              data=d, method="REML"), error=function(e) NULL)
  if (is.null(m)) return(NULL)
  pred_df <- tibble::tibble(!!predictor := seq(min(d[[predictor]],na.rm=TRUE),
                                               max(d[[predictor]],na.rm=TRUE), length.out=220))
  pr      <- stats::predict(m, newdata=pred_df, se.fit=TRUE)
  pred_df <- dplyr::mutate(pred_df, fit=as.numeric(pr$fit),
                           lower=fit-1.96*as.numeric(pr$se.fit), upper=fit+1.96*as.numeric(pr$se.fit))
  sm <- summary(m)
  if (is.null(title)) title <- paste(country, crop, response, "vs", predictor)
  p <- ggplot2::ggplot(d, ggplot2::aes(x=.data[[predictor]], y=.data[[response]])) +
    ggplot2::geom_ribbon(data=pred_df,
      ggplot2::aes(x=.data[[predictor]], ymin=lower, ymax=upper),
      inherit.aes=FALSE, alpha=0.18, fill="grey55") +
    ggplot2::geom_line(data=pred_df,
      ggplot2::aes(x=.data[[predictor]], y=fit),
      inherit.aes=FALSE, linewidth=1.05, colour="grey20") +
    ggplot2::geom_point(ggplot2::aes(colour=Year), size=3.0, alpha=0.88) +
    ggplot2::scale_colour_viridis_c(option="plasma", direction=-1, name="Year") +
    ggplot2::labs(title=title,
      subtitle=paste0("Exploratory GAM; deviance explained = ",
                      round(100*sm$dev.expl,1),"%, n = ",nrow(d)),
      x=predictor, y=response) +
    theme_ch4(base_size=9)
  save_plot(p, filename, 9.6, 6.4)
}

plot_gam_ombre(crop_panel,"Spain","Wheat","Yield_crop_kg_ha","bio1",                      "01_spain_wheat_yield_temperature.png",        "Spain wheat: yield and temperature")
plot_gam_ombre(crop_panel,"Spain","Wheat","Yield_crop_kg_ha","N_kg_ha",                   "02_spain_wheat_yield_nitrogen.png",           "Spain wheat: yield and nitrogen input")
plot_gam_ombre(crop_panel,"Spain","Wheat","N_eff_crop",      "N_kg_ha",                   "03_spain_wheat_n_efficiency_ceiling.png",     "Spain wheat: nitrogen efficiency and input")
plot_gam_ombre(crop_panel,"Spain","Wheat","Pesticide_eff_crop","Pesticide_kg_ha",          "04_spain_wheat_pesticide_efficiency.png",     "Spain wheat: pesticide efficiency")
plot_gam_ombre(crop_panel,"Spain","Wheat","Yield_crop_kg_ha","BII_loss_footprint_total_km2","05_spain_wheat_yield_bii_footprint.png",   "Spain wheat: yield and biodiversity loss footprint")
plot_gam_ombre(crop_panel,"UK",   "Wheat","Yield_crop_kg_ha","bio1",                      "06_uk_wheat_yield_temperature.png",           "UK wheat: yield and temperature")
plot_gam_ombre(crop_panel,"UK",   "Wheat","Yield_crop_kg_ha","UK_pollinator_index",        "07_uk_wheat_yield_pollinators.png",           "UK wheat: yield and pollinator occupancy")
plot_gam_ombre(crop_panel,"UK",   "Potatoes","Yield_crop_kg_ha","UK_pollinator_index",     "08_uk_potato_yield_pollinators.png",          "UK potatoes: yield and pollinator occupancy")
plot_gam_ombre(crop_panel,"UK",   "Barley","Pesticide_eff_crop","UK_pollinator_index",     "09_uk_barley_pesticide_eff_pollinators.png",  "UK barley: pesticide efficiency and pollinators")
plot_gam_ombre(crop_panel,"UK",   "Wheat","Pesticide_eff_crop","Pesticide_kg_ha",          "10_uk_wheat_pesticide_efficiency.png",        "UK wheat: pesticide efficiency")

# Pollinator heatmap
poll_screen <- readr::read_csv(file.path(RESULT_DIR,"CH4_UK_pollinator_crop_response_screen.csv"), show_col_types=FALSE)
p_poll <- poll_screen |>
  dplyr::filter(!is.na(tau), n >= 8) |>
  ggplot2::ggplot(ggplot2::aes(x=response, y=Crop, fill=tau)) +
  ggplot2::geom_tile(colour="white", linewidth=0.5) +
  ggplot2::scale_fill_gradient2(low="#2166AC", mid="white", high="#B2182B",
    midpoint=0, name="Kendall tau") +
  ggplot2::labs(title="UK pollinator association screen",
    subtitle="Crop yield, area and efficiency associations with pollinator occupancy index",
    x=NULL, y=NULL) +
  theme_ch4(base_size=8) +
  ggplot2::theme(axis.text.x=ggplot2::element_text(angle=40, hjust=1), legend.position="right")
save_plot(p_poll, "11_uk_pollinator_crop_screen.png", 11, 6.5)
