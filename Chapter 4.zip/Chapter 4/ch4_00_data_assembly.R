# Chapter 4: Master data assembly — Spain and United Kingdom
# Assembles the core panel dataset used across all Chapter 4 analyses.
# Extracts historical BII from long_data.rds, area-weighted staple yields from
# FAOSTAT StapleCrops.csv, N/P/K fertiliser inputs, and pesticide intensity.
# Adds derived metrics (input efficiency, normalised inputs) and differenced series.
#
# Inputs:
#   Biodiversity/long_data.rds  (historical BII by area_code)
#   CH4_newData/StapleCrops.csv
#   CH4_newData/input.csv
#   CH4_newData/pesticide.csv
#   CH4_Clim/ES_CH4_Clim_annual_bioclim_1961_2010.csv
#   CH4_Clim/UK_CH4_Clim_annual_bioclim_1961_2010.csv (or GB_ / GBR_ variant)
#
# Outputs (in CH4_Results/):
#   CH4_Spain_merged_patched_1970_2024.csv
#   CH4_UK_merged_patched_1970_2024.csv
#   CH4_Combined_Spain_UK_patched_1970_2024.csv

rm(list = ls())
gc()

OUTPUT_DIR <- "~/Documents/FoodSecurityV2/CH4_Results"
DATA_DIR   <- "~/Documents/FoodSecurityV2/CH4_newData"
CLIM_DIR   <- "~/Documents/FoodSecurityV2/CH4_Clim"
BIODIV_DIR <- "~/Documents/FoodSecurityV2/Biodiversity"
dir.create(OUTPUT_DIR, showWarnings = FALSE, recursive = TRUE)

START_YEAR <- 1970
END_YEAR   <- 2024

# Helpers
safe_read_csv <- function(path) {
  if (!file.exists(path)) stop(paste("File not found:", path))
  read.csv(path, stringsAsFactors = FALSE)
}

find_existing_file <- function(paths) {
  hit <- paths[file.exists(paths)]
  if (length(hit) == 0) return(NA_character_)
  hit[1]
}

# BII scale guard: values expected in 0–1 range from long_data.rds.
# If found on 0–100 scale warns rather than silently rescaling.
rescale_if_needed <- function(x, lower = NULL, upper = NULL) {
  if (all(is.na(x))) return(list(value = x, lower = lower, upper = upper, scale = "unknown"))
  x_max <- suppressWarnings(max(x, na.rm = TRUE))
  l_max <- if (!is.null(lower)) suppressWarnings(max(lower, na.rm = TRUE)) else NA_real_
  u_max <- if (!is.null(upper)) suppressWarnings(max(upper, na.rm = TRUE)) else NA_real_
  if (is.finite(x_max) && x_max <= 1.5)
    return(list(value = x, lower = lower, upper = upper, scale = "0_to_1"))
  if (is.finite(x_max) && x_max > 1.5 && x_max <= 100 &&
      !is.null(lower) && !is.null(upper) &&
      is.finite(l_max) && is.finite(u_max) && l_max <= 1.5 && u_max <= 1.5) {
    warning("BII appears to be on a different scale than uncertainty bounds. Check extraction.")
    return(list(value = x, lower = lower, upper = upper, scale = "mismatched"))
  }
  if (is.finite(x_max) && x_max > 100)
    warning("BII values exceed 100; extraction likely incorrect.")
  list(value = x, lower = lower, upper = upper, scale = "other")
}

weighted_mean <- function(x, w) {
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (!any(ok)) return(NA_real_)
  sum(x[ok] * w[ok], na.rm = TRUE) / sum(w[ok], na.rm = TRUE)
}

minmax01 <- function(x) {
  if (all(is.na(x))) return(rep(NA_real_, length(x)))
  rng <- range(x, na.rm = TRUE)
  if (!is.finite(rng[1]) || !is.finite(rng[2]) || rng[1] == rng[2]) return(rep(0, length(x)))
  (x - rng[1]) / (rng[2] - rng[1])
}

# Load core files
long_data       <- readRDS(file.path(BIODIV_DIR, "long_data.rds"))
long_data$year  <- as.numeric(long_data$year)
staples         <- safe_read_csv(file.path(DATA_DIR, "StapleCrops.csv"))
inputs          <- safe_read_csv(file.path(DATA_DIR, "input.csv"))
pesticides      <- safe_read_csv(file.path(DATA_DIR, "pesticide.csv"))
spain_clim      <- safe_read_csv(file.path(CLIM_DIR, "ES_CH4_Clim_annual_bioclim_1961_2010.csv"))
uk_clim_file    <- find_existing_file(c(
  file.path(CLIM_DIR, "UK_CH4_Clim_annual_bioclim_1961_2010.csv"),
  file.path(CLIM_DIR, "GB_CH4_Clim_annual_bioclim_1961_2010.csv"),
  file.path(CLIM_DIR, "GBR_CH4_Clim_annual_bioclim_1961_2010.csv")))
if (is.na(uk_clim_file)) stop("Could not find UK climate file. Check filename in CH4_Clim.")
uk_clim <- safe_read_csv(uk_clim_file)

# Identify BII country codes
all_codes <- sort(unique(long_data$area_code))
spain_code <- c("ESP","724","001-150-724","ES")[c("ESP","724","001-150-724","ES") %in% all_codes][1]
uk_code    <- c("GBR","826","001-150-826","UK","GB")[c("GBR","826","001-150-826","UK","GB") %in% all_codes][1]
if (is.na(spain_code) || is.na(uk_code)) {
  cat("Candidate area codes found:\n"); print(sort(unique(long_data$area_code)))
  stop("Country area_code not identified. Set spain_code / uk_code manually from list above.")
}

# Extract historical BII
extract_bii <- function(df, area_code_value, country_label) {
  sub <- df[df$area_code == area_code_value &
            df$scenario  == "historical" &
            df$variable  == "bii",
            c("year","value","lower_uncertainty","upper_uncertainty")]
  if (nrow(sub) == 0)
    stop(paste("No historical BII rows for", country_label, "area_code", area_code_value))
  agg <- stats::aggregate(
    cbind(value, lower_uncertainty, upper_uncertainty) ~ year,
    data = sub, FUN = function(x) mean(x, na.rm = TRUE))
  names(agg) <- c("Year","BII","Lower","Upper")
  agg <- agg[agg$Year >= START_YEAR & agg$Year <= END_YEAR, ]
  agg <- agg[order(agg$Year), ]
  sc  <- rescale_if_needed(agg$BII, agg$Lower, agg$Upper)
  agg$BII <- sc$value; agg$Lower <- sc$lower; agg$Upper <- sc$upper
  agg$Source <- "Observed"
  agg
}

spain_bii <- extract_bii(long_data, spain_code, "Spain")
uk_bii    <- extract_bii(long_data, uk_code,    "UK")

if (identical(round(spain_bii$BII, 8), round(uk_bii$BII, 8)))
  warning("Spain and UK BII series are identical — recheck area_code mapping.")

# Extract climate (bio1 = mean annual temperature, bio12 = annual precipitation,
# bio15 = precipitation seasonality)
extract_climate <- function(df, country_label) {
  needed <- c("year","bio1","bio12","bio15")
  missing_cols <- setdiff(needed, names(df))
  if (length(missing_cols) > 0)
    stop(paste(country_label, "climate file missing:", paste(missing_cols, collapse=", ")))
  out <- df[, needed]
  names(out) <- c("Year","Temp_C","Precip_mm","Precip_Seasonality")
  out <- out[out$Year >= START_YEAR & out$Year <= END_YEAR, ]
  out[order(out$Year), ]
}

spain_clim_sub <- extract_climate(spain_clim, "Spain")
uk_clim_sub    <- extract_climate(uk_clim,    "UK")

# Extract area-weighted staple yields
staple_crops <- c("Wheat","Barley","Oats","Rye","Rice","Maize","Mixed grain","Cereals n.e.c.",
                  "Potatoes","Edible roots and tubers with high starch or inulin content",
                  "Beans","Broad beans and horse beans","Other beans","Lentils","Peas")

extract_weighted_yield <- function(df, area_pattern, country_label) {
  sub <- df[grepl(area_pattern, df$Area, ignore.case=TRUE) &
            df$Item %in% staple_crops &
            df$Year >= START_YEAR & df$Year <= END_YEAR,
            c("Area","Item","Year","Element","Value")]
  yld  <- sub[grepl("^Yield$",          sub$Element, ignore.case=TRUE), ]
  area <- sub[grepl("^Area harvested$", sub$Element, ignore.case=TRUE), ]
  names(yld)[names(yld)   == "Value"] <- "Yield_kg_ha"
  names(area)[names(area) == "Value"] <- "Area_ha"
  merged <- merge(yld[, c("Item","Year","Yield_kg_ha")],
                  area[, c("Item","Year","Area_ha")],
                  by = c("Item","Year"), all = FALSE)
  yrs <- sort(unique(merged$Year))
  data.frame(
    Year        = yrs,
    Yield_kg_ha = sapply(yrs, function(y) {
      d <- merged[merged$Year == y, ]
      weighted_mean(d$Yield_kg_ha, d$Area_ha)
    }))
}

spain_yields <- extract_weighted_yield(staples, "^Spain$",       "Spain")
uk_yields    <- extract_weighted_yield(staples, "United Kingdom", "UK")

# Extract N, P, K inputs (kg/ha from cropland use)
extract_nutrient <- function(df, area_pattern, item_pattern, out_name) {
  sub <- df[grepl(area_pattern,  df$Area, ignore.case=TRUE) &
            grepl(item_pattern,  df$Item, ignore.case=TRUE) &
            df$Element == "Use per area of cropland" &
            grepl("kg/ha", df$Unit, ignore.case=TRUE) &
            df$Year >= START_YEAR & df$Year <= END_YEAR,
            c("Year","Value")]
  if (nrow(sub) == 0) {
    warning(paste("No rows for", out_name, "matching", area_pattern))
    return(data.frame(Year=integer(0)))
  }
  agg <- stats::aggregate(Value ~ Year, data=sub, FUN=function(x) mean(x, na.rm=TRUE))
  names(agg)[2] <- out_name
  agg[order(agg$Year), ]
}

spain_n <- extract_nutrient(inputs, "^Spain$",       "nitrogen",         "N_kg_ha")
spain_p <- extract_nutrient(inputs, "^Spain$",       "phosphate|phosphat","P_kg_ha")
spain_k <- extract_nutrient(inputs, "^Spain$",       "potash|potassium",  "K_kg_ha")
uk_n    <- extract_nutrient(inputs, "United Kingdom","nitrogen",          "N_kg_ha")
uk_p    <- extract_nutrient(inputs, "United Kingdom","phosphate|phosphat","P_kg_ha")
uk_k    <- extract_nutrient(inputs, "United Kingdom","potash|potassium",  "K_kg_ha")

# Extract pesticide intensity (kg/ha)
extract_pesticide <- function(df, area_pattern) {
  sub <- df[grepl(area_pattern, df$Area, ignore.case=TRUE) &
            df$Item    == "Pesticides (total)" &
            df$Element == "Use per area of cropland" &
            grepl("kg/ha", df$Unit, ignore.case=TRUE) &
            df$Year >= START_YEAR & df$Year <= END_YEAR,
            c("Year","Value")]
  if (nrow(sub) == 0) {
    warning(paste("No pesticide rows for area pattern:", area_pattern))
    return(data.frame(Year=integer(0), Pesticide_kg_ha=numeric(0)))
  }
  agg <- stats::aggregate(Value ~ Year, data=sub, FUN=function(x) mean(x, na.rm=TRUE))
  names(agg)[2] <- "Pesticide_kg_ha"
  agg[order(agg$Year), ]
}

spain_pest <- extract_pesticide(pesticides, "^Spain$")
uk_pest    <- extract_pesticide(pesticides, "United Kingdom")

# Merge all data streams per country
merge_country <- function(bii, yields, clim, n_df, p_df, k_df, pest_df, country_label) {
  out <- Reduce(function(a, b) merge(a, b, by="Year", all.x=TRUE),
                list(bii, yields, clim, n_df, p_df, k_df, pest_df))
  out$Country <- country_label
  out[order(out$Year), ]
}

spain_merged <- merge_country(spain_bii, spain_yields, spain_clim_sub,
                               spain_n, spain_p, spain_k, spain_pest, "Spain")
uk_merged    <- merge_country(uk_bii,    uk_yields,    uk_clim_sub,
                               uk_n,    uk_p,    uk_k,    uk_pest,    "UK")

# Derived metrics: input efficiency and normalised input index
add_input_metrics <- function(df) {
  needed <- c("N_kg_ha","P_kg_ha","K_kg_ha","Pesticide_kg_ha")
  ok <- stats::complete.cases(df[, needed]) & is.finite(df$Yield_kg_ha)
  df$Total_Input_raw <- NA_real_
  df$Efficiency_raw  <- NA_real_
  df$Total_Input_raw[ok] <- rowSums(df[ok, needed])
  df$Efficiency_raw[ok]  <- df$Yield_kg_ha[ok] / df$Total_Input_raw[ok]
  df$N_norm         <- minmax01(df$N_kg_ha)
  df$P_norm         <- minmax01(df$P_kg_ha)
  df$K_norm         <- minmax01(df$K_kg_ha)
  df$Pesticide_norm <- minmax01(df$Pesticide_kg_ha)
  ok2 <- stats::complete.cases(df[, c("N_norm","P_norm","K_norm","Pesticide_norm")])
  df$Total_Input_norm <- NA_real_
  df$Total_Input_norm[ok2] <- rowSums(df[ok2, c("N_norm","P_norm","K_norm","Pesticide_norm")])
  df
}

spain_merged <- add_input_metrics(spain_merged)
uk_merged    <- add_input_metrics(uk_merged)

# First-difference series for detrended screens
add_differences <- function(df) {
  diff_vars <- c("BII","Yield_kg_ha","Temp_C","Precip_mm","Precip_Seasonality",
                 "N_kg_ha","P_kg_ha","K_kg_ha","Pesticide_kg_ha")
  for (v in intersect(diff_vars, names(df)))
    df[[paste0("d", v)]] <- c(NA, diff(df[[v]]))
  df
}

spain_merged <- add_differences(spain_merged)
uk_merged    <- add_differences(uk_merged)

combined <- rbind(spain_merged, uk_merged)
combined  <- combined[order(combined$Country, combined$Year), ]

utils::write.csv(spain_merged, file.path(OUTPUT_DIR, "CH4_Spain_merged_patched_1970_2024.csv"), row.names=FALSE)
utils::write.csv(uk_merged,    file.path(OUTPUT_DIR, "CH4_UK_merged_patched_1970_2024.csv"),    row.names=FALSE)
utils::write.csv(combined,     file.path(OUTPUT_DIR, "CH4_Combined_Spain_UK_patched_1970_2024.csv"), row.names=FALSE)
