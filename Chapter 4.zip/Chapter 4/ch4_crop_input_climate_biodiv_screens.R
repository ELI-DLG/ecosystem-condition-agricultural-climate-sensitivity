# Chapter 4: Crop-level input, climate and biodiversity association screens
# Kendall rank correlations, nonlinear GAM screens, input ceiling detection,
# and climate x input x biodiversity interaction screens across crops.
# Produces the crop-level statistical tables underpinning Chapter 4 results.
#
# Inputs:
#   CH4_Results/CH4_Combined_Spain_UK_panel_1970_2024_with_biodiv_extras.csv
#   CH4_newData/StapleCrops.csv
#
# Outputs (in CH4_Results/):
#   CH4_crop_panel_with_biodiv_inputs.csv
#   CH4_crop_sample_audit.csv
#   CH4_crop_pairwise_kendall_screen.csv
#   CH4_crop_gam_screen.csv
#   CH4_crop_input_ceiling_screen.csv
#   CH4_crop_climate_input_biodiv_interaction_screen.csv
#   Figures in Figures_CH4_crop_input_climate_biodiv/

suppressPackageStartupMessages({
  library(dplyr); library(readr); library(tidyr); library(stringr)
  library(purrr); library(ggplot2); library(mgcv); library(zoo); library(viridis)
})

ROOT       <- "~/Documents/FoodSecurityV2"
RESULT_DIR <- file.path(ROOT, "CH4_Results")
FIG_DIR    <- file.path(RESULT_DIR, "Figures_CH4_crop_input_climate_biodiv")
dir.create(FIG_DIR, recursive = TRUE, showWarnings = FALSE)

df      <- readr::read_csv(file.path(RESULT_DIR,
             "CH4_Combined_Spain_UK_panel_1970_2024_with_biodiv_extras.csv"),
             show_col_types = FALSE)
staples <- readr::read_csv(file.path(ROOT, "CH4_newData", "StapleCrops.csv"),
             show_col_types = FALSE)

theme_ch4 <- function(base_size = 10) {
  ggplot2::theme_classic(base_size = base_size) +
    ggplot2::theme(
      plot.title        = ggplot2::element_text(face = "bold", size = base_size + 3),
      plot.subtitle     = ggplot2::element_text(size = base_size, margin = ggplot2::margin(b = 6)),
      axis.title        = ggplot2::element_text(face = "bold", size = base_size),
      axis.text         = ggplot2::element_text(size = base_size - 1),
      strip.text        = ggplot2::element_text(face = "bold", size = base_size - 1),
      legend.position   = "bottom",
      panel.grid.major.y = ggplot2::element_line(colour = "grey90", linewidth = 0.25),
      panel.grid.major.x = ggplot2::element_blank(),
      panel.grid.minor   = ggplot2::element_blank(),
      plot.margin        = ggplot2::margin(10, 12, 10, 10)
    )
}

save_plot <- function(p, filename, width = 11, height = 7) {
  ggplot2::ggsave(file.path(FIG_DIR, filename), p, width = width,
                  height = height, dpi = 320, bg = "white")
}

safe_cor <- function(x, y) {
  ok <- stats::complete.cases(x, y)
  if (sum(ok) < 8) return(c(n = sum(ok), tau = NA_real_, p = NA_real_))
  kt <- suppressWarnings(stats::cor.test(x[ok], y[ok], method = "kendall", exact = FALSE))
  c(n = sum(ok), tau = unname(kt$estimate), p = kt$p.value)
}

# Build crop panel
wanted_crops <- c("Wheat", "Barley", "Oats", "Rye", "Rice", "Potatoes",
                  "Beans, dry", "Broad beans and horse beans, dry",
                  "Lentils, dry", "Peas, dry")

crop_panel <- staples |>
  dplyr::filter(
    Area %in% c("Spain", "United Kingdom of Great Britain and Northern Ireland"),
    Item %in% wanted_crops,
    Element %in% c("Yield", "Area harvested"),
    Year >= 1970, Year <= 2024
  ) |>
  dplyr::mutate(
    Country    = dplyr::if_else(Area == "Spain", "Spain", "UK"),
    Crop       = Item,
    Crop_group = dplyr::case_when(
      Crop %in% c("Wheat","Barley","Oats","Rye","Rice") ~ "Cereal",
      Crop == "Potatoes" ~ "Tuber",
      TRUE ~ "Legume")
  ) |>
  dplyr::select(Country, Year, Crop, Crop_group, Element, Value) |>
  tidyr::pivot_wider(names_from = Element, values_from = Value) |>
  dplyr::rename(Yield_crop_kg_ha = Yield, HarvestedArea_crop_ha = `Area harvested`) |>
  dplyr::left_join(df, by = c("Country", "Year")) |>
  dplyr::group_by(Country) |>
  dplyr::arrange(Year, .by_group = TRUE) |>
  dplyr::mutate(
    BII_interp   = stats::approx(Year[!is.na(BII)], BII[!is.na(BII)], xout = Year, rule = 2)$y,
    BIIFP_interp = stats::approx(
      Year[!is.na(BII_loss_footprint_total_km2)],
      BII_loss_footprint_total_km2[!is.na(BII_loss_footprint_total_km2)],
      xout = Year, rule = 2)$y
  ) |>
  dplyr::ungroup() |>
  dplyr::group_by(Country, Crop) |>
  dplyr::arrange(Year, .by_group = TRUE) |>
  dplyr::mutate(
    Yield_yoy_pct    = 100 * (Yield_crop_kg_ha - dplyr::lag(Yield_crop_kg_ha)) / dplyr::lag(Yield_crop_kg_ha),
    Yield_rollcv_5yr = 100 * zoo::rollapply(Yield_crop_kg_ha, 5, sd,   fill = NA, align = "right", na.rm = TRUE) /
                             zoo::rollapply(Yield_crop_kg_ha, 5, mean, fill = NA, align = "right", na.rm = TRUE),
    N_eff_crop           = Yield_crop_kg_ha / N_kg_ha,
    P_eff_crop           = Yield_crop_kg_ha / P_kg_ha,
    K_eff_crop           = Yield_crop_kg_ha / K_kg_ha,
    Pesticide_eff_crop   = Yield_crop_kg_ha / Pesticide_kg_ha,
    Total_input_kg_ha    = N_kg_ha + P_kg_ha + K_kg_ha + Pesticide_kg_ha,
    Total_input_eff_crop = Yield_crop_kg_ha / Total_input_kg_ha
  ) |>
  dplyr::ungroup()

readr::write_csv(crop_panel, file.path(RESULT_DIR, "CH4_crop_panel_with_biodiv_inputs.csv"))

# Variable sets (filtered to available columns)
climate_vars <- intersect(
  c("bio1","bio2","bio4","bio5","bio6","bio7","bio12","bio13","bio14","bio15",
    "aet_annual_sum_mm","def_annual_sum_mm","soil_annual_mean_mm","pdsi_annual_mean",
    "tmean_mean_DJF","tmean_mean_MAM","tmean_mean_JJA","tmean_mean_SON",
    "tmax_mean_DJF","tmax_mean_MAM","tmax_mean_JJA","tmax_mean_SON",
    "ppt_sum_DJF","ppt_sum_MAM","ppt_sum_JJA","ppt_sum_SON",
    "def_sum_DJF","def_sum_MAM","def_sum_JJA","def_sum_SON",
    "soil_mean_DJF","soil_mean_MAM","soil_mean_JJA","soil_mean_SON",
    "pdsi_mean_DJF","pdsi_mean_MAM","pdsi_mean_JJA","pdsi_mean_SON"),
  names(crop_panel))

input_vars <- intersect(
  c("N_kg_ha","P_kg_ha","K_kg_ha","Pesticide_kg_ha","Pesticide_tonnes",
    "Herbicides_tonnes","Insecticides_tonnes","Fungicides_Bactericides_tonnes",
    "PlantGrowthRegulators_tonnes","OtherPesticides_tonnes","Rodenticides_tonnes"),
  names(crop_panel))

biodiv_vars <- intersect(
  c("BII","BII_interp","BII_loss_footprint_total_km2","BIIFP_interp","UK_pollinator_index"),
  names(crop_panel))

responses <- intersect(
  c("Yield_crop_kg_ha","HarvestedArea_crop_ha","Yield_yoy_pct","Yield_rollcv_5yr",
    "N_eff_crop","P_eff_crop","K_eff_crop","Pesticide_eff_crop","Total_input_eff_crop"),
  names(crop_panel))

predictors <- c(climate_vars, biodiv_vars, input_vars)

# Sample size audit
readr::write_csv(
  crop_panel |>
    tidyr::pivot_longer(dplyr::all_of(c(responses, predictors)),
                        names_to = "Variable", values_to = "Value") |>
    dplyr::group_by(Country, Crop, Crop_group, Variable) |>
    dplyr::summarise(
      n_non_missing = sum(!is.na(Value)),
      first_year    = ifelse(any(!is.na(Value)), min(Year[!is.na(Value)]), NA),
      last_year     = ifelse(any(!is.na(Value)), max(Year[!is.na(Value)]), NA),
      .groups = "drop"),
  file.path(RESULT_DIR, "CH4_crop_sample_audit.csv"))

# Kendall screen
kendall_screen <- tidyr::expand_grid(response = responses, predictor = predictors) |>
  tidyr::crossing(dplyr::distinct(crop_panel, Country, Crop, Crop_group)) |>
  purrr::pmap_dfr(function(response, predictor, Country, Crop, Crop_group) {
    d   <- dplyr::filter(crop_panel, .data$Country == Country, .data$Crop == Crop)
    out <- safe_cor(d[[predictor]], d[[response]])
    tibble::tibble(Country = Country, Crop = Crop, Crop_group = Crop_group,
                   response = response, predictor = predictor,
                   n = out["n"], tau = out["tau"], p_value = out["p"])
  })

readr::write_csv(kendall_screen, file.path(RESULT_DIR, "CH4_crop_pairwise_kendall_screen.csv"))

# GAM screen with ceiling detection
fit_gam_one <- function(data, response, predictor) {
  d <- dplyr::select(data, Year, dplyr::all_of(c(response, predictor))) |>
    dplyr::filter(!is.na(.data[[response]]), !is.na(.data[[predictor]]))
  if (nrow(d) < 10 || length(unique(d[[predictor]])) < 5)
    return(tibble::tibble(n=nrow(d), r_sq=NA_real_, dev_explained=NA_real_,
                          edf=NA_real_, p_value_smooth=NA_real_))
  k_use <- min(5, max(3, floor(nrow(d)/4)))
  m <- tryCatch(
    mgcv::gam(as.formula(paste0(response," ~ s(",predictor,", k=",k_use,")")),
              data = d, method = "REML"),
    error = function(e) NULL)
  if (is.null(m))
    return(tibble::tibble(n=nrow(d), r_sq=NA_real_, dev_explained=NA_real_,
                          edf=NA_real_, p_value_smooth=NA_real_))
  sm <- summary(m)
  tibble::tibble(n=nrow(d), r_sq=sm$r.sq, dev_explained=sm$dev.expl,
                 edf=sm$s.table[1,"edf"], p_value_smooth=sm$s.table[1,"p-value"])
}

gam_screen <- tidyr::expand_grid(response=responses, predictor=predictors) |>
  tidyr::crossing(dplyr::distinct(crop_panel, Country, Crop, Crop_group)) |>
  purrr::pmap_dfr(function(response, predictor, Country, Crop, Crop_group) {
    d <- dplyr::filter(crop_panel, .data$Country==Country, .data$Crop==Crop)
    fit_gam_one(d, response, predictor) |>
      dplyr::mutate(Country=Country, Crop=Crop, Crop_group=Crop_group,
                    response=response, predictor=predictor, .before=1)
  }) |>
  dplyr::arrange(dplyr::desc(dev_explained))

readr::write_csv(gam_screen, file.path(RESULT_DIR, "CH4_crop_gam_screen.csv"))

# Input ceiling screen
ceiling_one <- function(data, country, crop, input_var) {
  d <- data |>
    dplyr::filter(Country==country, Crop==crop) |>
    dplyr::select(Year, Yield_crop_kg_ha, dplyr::all_of(input_var)) |>
    dplyr::filter(!is.na(Yield_crop_kg_ha), !is.na(.data[[input_var]]))
  if (nrow(d) < 12 || length(unique(d[[input_var]])) < 6)
    return(tibble::tibble(Country=country, Crop=crop, input=input_var,
                          n=nrow(d), possible_ceiling=NA, slope_low=NA_real_, slope_high=NA_real_))
  d <- dplyr::mutate(d, input_quantile = dplyr::ntile(.data[[input_var]], 3))
  low  <- dplyr::filter(d, input_quantile == 1)
  high <- dplyr::filter(d, input_quantile == 3)
  sl <- tryCatch(stats::coef(stats::lm(Yield_crop_kg_ha ~ .data[[input_var]], data=low))[2],  error=function(e) NA_real_)
  sh <- tryCatch(stats::coef(stats::lm(Yield_crop_kg_ha ~ .data[[input_var]], data=high))[2], error=function(e) NA_real_)
  tibble::tibble(
    Country=country, Crop=crop, input=input_var, n=nrow(d),
    slope_low=sl, slope_high=sh,
    possible_ceiling = dplyr::case_when(
      is.na(sl)|is.na(sh)           ~ NA_character_,
      sl>0 & sh<=0                  ~ "possible plateau or diminishing return",
      sl>0 & sh>0 & sh<sl           ~ "weaker high-input response",
      sh>sl                         ~ "stronger high-input response",
      TRUE                          ~ "no clear ceiling pattern"))
}

ceiling_screen <- tidyr::crossing(dplyr::distinct(crop_panel, Country, Crop), input=input_vars) |>
  purrr::pmap_dfr(function(Country, Crop, input) ceiling_one(crop_panel, Country, Crop, input))

readr::write_csv(ceiling_screen, file.path(RESULT_DIR, "CH4_crop_input_ceiling_screen.csv"))

# Climate x input x biodiversity interaction screen
interaction_one <- function(data, response, climate, modifier) {
  d <- dplyr::select(data, Year, dplyr::all_of(c(response, climate, modifier))) |>
    dplyr::filter(!is.na(.data[[response]]), !is.na(.data[[climate]]), !is.na(.data[[modifier]]))
  if (nrow(d) < 14 || length(unique(d[[climate]])) < 5 || length(unique(d[[modifier]])) < 5)
    return(tibble::tibble(n=nrow(d), adj_r_sq=NA_real_, interaction_estimate=NA_real_, interaction_p=NA_real_))
  d <- dplyr::mutate(d, climate_z=as.numeric(scale(.data[[climate]])),
                        modifier_z=as.numeric(scale(.data[[modifier]])))
  m <- tryCatch(stats::lm(as.formula(paste0(response," ~ climate_z * modifier_z")), data=d),
                error=function(e) NULL)
  if (is.null(m))
    return(tibble::tibble(n=nrow(d), adj_r_sq=NA_real_, interaction_estimate=NA_real_, interaction_p=NA_real_))
  sm <- summary(m); co <- stats::coef(sm)
  tibble::tibble(n=nrow(d), adj_r_sq=sm$adj.r.squared,
                 interaction_estimate=co["climate_z:modifier_z","Estimate"],
                 interaction_p=co["climate_z:modifier_z","Pr(>|t|)"])
}

interaction_screen <- tidyr::crossing(
  dplyr::distinct(crop_panel, Country, Crop, Crop_group),
  response=responses, climate=climate_vars,
  modifier=c(input_vars, biodiv_vars)) |>
  purrr::pmap_dfr(function(Country, Crop, Crop_group, response, climate, modifier) {
    d <- dplyr::filter(crop_panel, .data$Country==Country, .data$Crop==Crop)
    interaction_one(d, response, climate, modifier) |>
      dplyr::mutate(Country=Country, Crop=Crop, Crop_group=Crop_group,
                    response=response, climate=climate, modifier=modifier, .before=1)
  }) |>
  dplyr::mutate(interaction_direction = dplyr::case_when(
    is.na(interaction_estimate) ~ NA_character_,
    interaction_estimate > 0    ~ "positive moderation",
    interaction_estimate < 0    ~ "negative moderation",
    TRUE ~ "flat")) |>
  dplyr::arrange(dplyr::desc(abs(interaction_estimate)))

readr::write_csv(interaction_screen,
  file.path(RESULT_DIR, "CH4_crop_climate_input_biodiv_interaction_screen.csv"))

# Figures
plot_gam_ombre <- function(data, country, crop, response, predictor, xlab, ylab, title) {
  d <- data |>
    dplyr::filter(Country==country, Crop==crop) |>
    dplyr::select(Year, dplyr::all_of(c(response, predictor))) |>
    dplyr::filter(!is.na(.data[[response]]), !is.na(.data[[predictor]])) |>
    dplyr::arrange(Year)
  if (nrow(d) < 10) return(NULL)
  k_use <- min(5, max(3, floor(nrow(d)/4)))
  m <- tryCatch(
    mgcv::gam(as.formula(paste0(response," ~ s(",predictor,", k=",k_use,")")),
              data=d, method="REML"), error=function(e) NULL)
  if (is.null(m)) return(NULL)
  pred <- tibble::tibble(!!predictor := seq(min(d[[predictor]], na.rm=TRUE),
                                            max(d[[predictor]], na.rm=TRUE), length.out=200))
  pr   <- stats::predict(m, newdata=pred, se.fit=TRUE)
  pred <- dplyr::mutate(pred, fit=pr$fit,
                        lower=fit-1.96*pr$se.fit, upper=fit+1.96*pr$se.fit)
  ggplot2::ggplot(d, ggplot2::aes(x=.data[[predictor]], y=.data[[response]])) +
    ggplot2::geom_ribbon(data=pred,
      ggplot2::aes(x=.data[[predictor]], ymin=lower, ymax=upper),
      inherit.aes=FALSE, fill="grey60", alpha=0.18) +
    ggplot2::geom_line(data=pred,
      ggplot2::aes(x=.data[[predictor]], y=fit),
      inherit.aes=FALSE, colour="grey20", linewidth=1) +
    ggplot2::geom_point(ggplot2::aes(colour=Year), size=3, alpha=0.88) +
    ggplot2::scale_colour_viridis_c(option="plasma", direction=-1, name="Year") +
    ggplot2::labs(title=title,
      subtitle=paste(country, crop, "exploratory GAM; indirect association"),
      x=xlab, y=ylab) +
    theme_ch4(base_size=10)
}

example_plots <- tibble::tribble(
  ~country, ~crop,      ~response,            ~predictor,                  ~xlab,                          ~ylab,                    ~filename,                                    ~title,
  "Spain",  "Wheat",    "Yield_crop_kg_ha",   "bio1",                      "Mean annual temperature (C)",  "Wheat yield (kg/ha)",    "01_spain_wheat_yield_temperature.png",       "Spain wheat: yield and temperature",
  "Spain",  "Wheat",    "N_eff_crop",         "N_kg_ha",                   "Nitrogen use (kg/ha)",         "Yield per kg N",         "02_spain_wheat_n_eff_n_input.png",           "Spain wheat: nitrogen efficiency",
  "Spain",  "Wheat",    "Pesticide_eff_crop", "Pesticide_kg_ha",           "Pesticide use (kg/ha)",        "Yield per kg pesticide", "03_spain_wheat_pesticide_efficiency.png",    "Spain wheat: pesticide efficiency",
  "UK",     "Wheat",    "Yield_crop_kg_ha",   "bio1",                      "Mean annual temperature (C)",  "Wheat yield (kg/ha)",    "04_uk_wheat_yield_temperature.png",          "UK wheat: yield and temperature",
  "UK",     "Wheat",    "Yield_crop_kg_ha",   "UK_pollinator_index",       "UK pollinator occupancy",      "Wheat yield (kg/ha)",    "05_uk_wheat_yield_pollinators.png",          "UK wheat: yield and pollinators",
  "UK",     "Potatoes", "Pesticide_eff_crop", "UK_pollinator_index",       "UK pollinator occupancy",      "Yield per kg pesticide", "06_uk_potato_pesticide_eff_pollinators.png", "UK potatoes: pesticide efficiency and pollinators",
  "Spain",  "Barley",   "Yield_crop_kg_ha",   "def_sum_JJA",               "Summer climatic water deficit","Barley yield (kg/ha)",   "07_spain_barley_yield_summer_deficit.png",   "Spain barley: yield and summer deficit"
)

purrr::walk(seq_len(nrow(example_plots)), function(i) {
  p <- plot_gam_ombre(crop_panel,
    example_plots$country[i], example_plots$crop[i],
    example_plots$response[i], example_plots$predictor[i],
    example_plots$xlab[i], example_plots$ylab[i], example_plots$title[i])
  if (!is.null(p)) save_plot(p, example_plots$filename[i], 9.5, 6.4)
})

# Summary heatmaps
top_gam <- gam_screen |>
  dplyr::filter(!is.na(dev_explained), n >= 10) |>
  dplyr::group_by(response, predictor) |>
  dplyr::summarise(mean_dev_explained = mean(dev_explained, na.rm=TRUE), .groups="drop")

p_gam_heat <- top_gam |>
  ggplot2::ggplot(ggplot2::aes(x=predictor, y=response, fill=mean_dev_explained)) +
  ggplot2::geom_tile(colour="white", linewidth=0.5) +
  ggplot2::scale_fill_viridis_c(option="magma", direction=-1, name="Mean dev.
explained") +
  ggplot2::labs(title="Crop-level nonlinear association screen",
    subtitle="Mean GAM deviance explained across country-crop combinations",
    x=NULL, y=NULL) +
  theme_ch4(base_size=8) +
  ggplot2::theme(axis.text.x=ggplot2::element_text(angle=45, hjust=1),
                 legend.position="right")

save_plot(p_gam_heat, "08_crop_gam_screen_heatmap.png", 15, 8)

p_ceiling <- ceiling_screen |>
  dplyr::filter(!is.na(possible_ceiling)) |>
  ggplot2::ggplot(ggplot2::aes(x=input, y=Crop, fill=slope_high - slope_low)) +
  ggplot2::geom_tile(colour="white", linewidth=0.5) +
  ggplot2::facet_wrap(~Country) +
  ggplot2::scale_fill_gradient2(low="#2166AC", mid="white", high="#B2182B",
    midpoint=0, name="High minus
low input slope") +
  ggplot2::labs(title="Input ceiling and diminishing return screen",
    subtitle="Negative values suggest weaker yield response at high input levels",
    x=NULL, y=NULL) +
  theme_ch4(base_size=8) +
  ggplot2::theme(axis.text.x=ggplot2::element_text(angle=45, hjust=1),
                 legend.position="right")

save_plot(p_ceiling, "09_input_ceiling_screen_heatmap.png", 13, 7)
