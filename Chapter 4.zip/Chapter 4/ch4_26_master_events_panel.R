# Chapter 4 — Figure 26: Master country-specific events panel
# Four-panel figure: crop volatility, fertiliser/pesticide inputs,
# output-per-input efficiency, biodiversity and UK pollinators.
# Includes country-specific climate event shading and policy markers.
# Descriptive only.
#
# Inputs (in CH4_Results/):
#   CH4_21_group_panel_with_lagged_events.csv
#
# Outputs (in CH4_Results/Figures_CH4_26_master_country_specific_events/):
#   CH4_26_master_country_specific_events.png
#   CH4_26_master_clean_no_events.png

suppressPackageStartupMessages({
  library(dplyr); library(readr); library(tidyr); library(stringr)
  library(forcats); library(ggplot2); library(scales); library(patchwork)
  library(tibble); library(grid)
})

ROOT       <- "~/Documents/FoodSecurityV2"
RESULT_DIR <- file.path(ROOT, "CH4_Results")
FIG_DIR    <- file.path(RESULT_DIR, "Figures_CH4_26_master_country_specific_events")
dir.create(FIG_DIR, recursive = TRUE, showWarnings = FALSE)

country_cols <- c("Spain" = "#D55E00", "UK" = "#0072B2")
event_cols   <- c("Drought" = "#E8B45B", "Heat" = "#D96C75",
                  "Drought-heat" = "#B45AA0", "Flood" = "#6BAED6")
policy_cols  <- c("CAP reform" = "#4DAF4A", "UK pesticide policy" = "#984EA3",
                  "Brexit" = "#FF7F00")
policy_ltys  <- c("CAP reform" = "dashed", "UK pesticide policy" = "dotted",
                  "Brexit" = "longdash")

climate_events <- tibble::tribble(
  ~Country, ~event_start, ~event_end, ~event_label,        ~event_type,
  "Spain",  1991, 1995, "1991-95 drought",     "Drought",
  "Spain",  2003, 2003, "2003 heatwave",       "Heat",
  "Spain",  2004, 2007, "2004-07 drought",     "Drought",
  "Spain",  2017, 2017, "2017 heat",           "Heat",
  "Spain",  2022, 2022, "2022 heat",           "Heat",
  "UK",     1975, 1976, "1975-76 drought",     "Drought",
  "UK",     1989, 1992, "1989-92 drought",     "Drought",
  "UK",     2003, 2003, "2003 heatwave",       "Heat",
  "UK",     2007, 2007, "2007 floods",         "Flood",
  "UK",     2018, 2018, "2018 drought-heat",   "Drought-heat",
  "UK",     2022, 2023, "2022-23 drought-heat","Drought-heat"
) |> dplyr::mutate(xmin = event_start - 0.5, xmax = event_end + 0.5)

policy_events <- tibble::tribble(
  ~Country, ~event_year, ~event_label,            ~policy_type,
  "Spain",  1992, "CAP MacSharry",         "CAP reform",
  "Spain",  2003, "CAP Fischler",          "CAP reform",
  "Spain",  2013, "CAP 2013",              "CAP reform",
  "UK",     1992, "CAP MacSharry",         "CAP reform",
  "UK",     2003, "CAP Fischler",          "CAP reform",
  "UK",     2013, "CAP 2013",              "CAP reform",
  "UK",     2020, "Brexit",                "Brexit",
  "UK",     2016, "Neonics ban (UK)",      "UK pesticide policy",
  "UK",     2022, "Further restrictions",  "UK pesticide policy"
)

theme_master <- function(base_size = 9) {
  ggplot2::theme_minimal(base_size = base_size) +
    ggplot2::theme(
      panel.grid.major  = ggplot2::element_line(colour = "grey93", linewidth = 0.22),
      panel.grid.minor  = ggplot2::element_blank(),
      plot.title        = ggplot2::element_text(face = "bold", size = base_size + 3),
      plot.subtitle     = ggplot2::element_text(colour = "grey25", size = base_size - 0.5),
      axis.title        = ggplot2::element_text(face = "bold"),
      strip.text        = ggplot2::element_text(face = "bold"),
      strip.background  = ggplot2::element_blank(),
      legend.position   = "bottom",
      plot.margin       = ggplot2::margin(8, 10, 8, 8)
    )
}

save_plot <- function(p, filename, width = 20, height = 24) {
  ggplot2::ggsave(file.path(FIG_DIR, filename), p,
                  width = width, height = height, dpi = 330,
                  bg = "white", limitsize = FALSE)
}

shared_event_layers <- function() {
  list(
    ggplot2::geom_rect(data = climate_events,
      ggplot2::aes(xmin = xmin, xmax = xmax, ymin = -Inf, ymax = Inf, fill = event_type),
      inherit.aes = FALSE, alpha = 0.07),
    ggplot2::geom_vline(data = policy_events,
      ggplot2::aes(xintercept = event_year, colour = policy_type, linetype = policy_type),
      linewidth = 0.38, alpha = 0.65, inherit.aes = FALSE)
  )
}

country_event_layers <- function() {
  list(
    ggplot2::geom_rect(data = climate_events,
      ggplot2::aes(xmin = xmin, xmax = xmax, ymin = -Inf, ymax = Inf, fill = event_type),
      inherit.aes = FALSE, alpha = 0.13),
    ggplot2::geom_vline(data = policy_events,
      ggplot2::aes(xintercept = event_year, colour = policy_type, linetype = policy_type),
      linewidth = 0.42, alpha = 0.72, inherit.aes = FALSE)
  )
}

panel_file <- file.path(RESULT_DIR, "CH4_21_group_panel_with_lagged_events.csv")
if (!file.exists(panel_file)) stop("Missing group panel: ", panel_file)
group_panel <- readr::read_csv(panel_file, show_col_types = FALSE)

vol_long <- group_panel |>
  dplyr::select(Country, crop_group, Year,
                dplyr::any_of(c("yield_volatility_w","production_volatility_w",
                                "output_per_input_volatility_w"))) |>
  tidyr::pivot_longer(-c(Country, crop_group, Year),
                      names_to = "volatility_metric", values_to = "value") |>
  dplyr::filter(is.finite(value)) |>
  dplyr::mutate(volatility_metric = dplyr::recode(volatility_metric,
    "yield_volatility_w"            = "Yield CV",
    "production_volatility_w"       = "Production CV",
    "output_per_input_volatility_w" = "Output-per-input CV"))

input_panel <- group_panel |>
  dplyr::select(Country, Year,
                dplyr::any_of(c("N_kg_ha","P_kg_ha","K_kg_ha","Pesticide_kg_ha"))) |>
  dplyr::distinct() |>
  tidyr::pivot_longer(-c(Country, Year),
                      names_to = "input_metric", values_to = "value") |>
  dplyr::filter(is.finite(value)) |>
  dplyr::mutate(input_metric = dplyr::recode(input_metric,
    "N_kg_ha" = "Nitrogen kg/ha", "P_kg_ha" = "Phosphate kg/ha",
    "K_kg_ha" = "Potash kg/ha",   "Pesticide_kg_ha" = "Pesticide kg/ha"))

eff_long <- group_panel |>
  dplyr::select(Country, crop_group, Year,
                dplyr::any_of(c("output_per_NPK_index","output_per_NPK_volatility"))) |>
  tidyr::pivot_longer(-c(Country, crop_group, Year),
                      names_to = "eff_metric", values_to = "value") |>
  dplyr::filter(is.finite(value)) |>
  dplyr::mutate(eff_metric = dplyr::recode(eff_metric,
    "output_per_NPK_index"      = "Output per kg NPK, indexed",
    "output_per_NPK_volatility" = "Output-per-NPK volatility"))

biodiv_panel <- group_panel |>
  dplyr::select(Country, Year,
                dplyr::any_of(c("BII_pct","BIIFP_1000km2","UK_pollinator_index"))) |>
  dplyr::distinct() |>
  tidyr::pivot_longer(-c(Country, Year),
                      names_to = "metric", values_to = "value") |>
  dplyr::filter(is.finite(value)) |>
  dplyr::mutate(metric = dplyr::recode(metric,
    "BII_pct"             = "BII, %",
    "BIIFP_1000km2"       = "BII loss footprint, 1000 km2",
    "UK_pollinator_index" = "UK pollinator index"))

p_vol <- ggplot2::ggplot(vol_long, ggplot2::aes(Year, value, colour = Country)) +
  shared_event_layers() +
  ggplot2::geom_line(linewidth = 0.65, alpha = 0.92) +
  ggplot2::facet_grid(volatility_metric ~ crop_group, scales = "free_y") +
  ggplot2::scale_colour_manual(values = c(country_cols, policy_cols), name = NULL) +
  ggplot2::scale_fill_manual(values = event_cols, name = "Weather event") +
  ggplot2::scale_linetype_manual(values = policy_ltys, name = "Policy marker") +
  ggplot2::labs(title = "A. Crop volatility by production group", x = NULL, y = "CV %") +
  theme_master(7.5) +
  ggplot2::theme(axis.text.x = ggplot2::element_text(size = 6.2, angle = 30, hjust = 1))

p_inputs <- ggplot2::ggplot(input_panel, ggplot2::aes(Year, value, colour = Country)) +
  country_event_layers() +
  ggplot2::geom_line(linewidth = 0.75, alpha = 0.94) +
  ggplot2::facet_grid(input_metric ~ Country, scales = "free_y") +
  ggplot2::scale_colour_manual(values = c(country_cols, policy_cols), guide = "none") +
  ggplot2::scale_fill_manual(values = event_cols, name = "Weather event") +
  ggplot2::scale_linetype_manual(values = policy_ltys, name = "Policy marker") +
  ggplot2::labs(title = "B. Fertiliser and pesticide inputs", x = NULL, y = "kg/ha") +
  theme_master(7.8) +
  ggplot2::theme(axis.text.x = ggplot2::element_text(size = 6.2, angle = 30, hjust = 1))

p_eff <- ggplot2::ggplot(eff_long, ggplot2::aes(Year, value, colour = Country)) +
  shared_event_layers() +
  ggplot2::geom_hline(
    data = dplyr::filter(eff_long, eff_metric == "Output per kg NPK, indexed"),
    ggplot2::aes(yintercept = 100), inherit.aes = FALSE,
    colour = "grey70", linewidth = 0.25) +
  ggplot2::geom_line(linewidth = 0.65, alpha = 0.92) +
  ggplot2::facet_grid(eff_metric ~ crop_group, scales = "free_y") +
  ggplot2::scale_colour_manual(values = c(country_cols, policy_cols), name = NULL) +
  ggplot2::scale_fill_manual(values = event_cols, name = "Weather event") +
  ggplot2::scale_linetype_manual(values = policy_ltys, name = "Policy marker") +
  ggplot2::labs(title = "C. Output-per-input patterns",
                subtitle = "Yield per kg NPK indexed within crop. Productivity proxy only.",
                x = NULL, y = NULL) +
  theme_master(7.5) +
  ggplot2::theme(axis.text.x = ggplot2::element_text(size = 6.2, angle = 30, hjust = 1))

p_biodiv <- ggplot2::ggplot(biodiv_panel, ggplot2::aes(Year, value, colour = Country)) +
  country_event_layers() +
  ggplot2::geom_line(linewidth = 0.82, alpha = 0.94) +
  ggplot2::geom_point(size = 1.1, alpha = 0.75) +
  ggplot2::facet_grid(metric ~ Country, scales = "free_y") +
  ggplot2::scale_colour_manual(values = c(country_cols, policy_cols), name = NULL) +
  ggplot2::scale_fill_manual(values = event_cols, name = "Weather event") +
  ggplot2::scale_linetype_manual(values = policy_ltys, name = "Policy marker") +
  ggplot2::labs(title = "D. Biodiversity state, footprint and UK pollinator occupancy",
                subtitle = "UK pollinator series shown for UK only.", x = NULL, y = NULL) +
  theme_master(7.8) +
  ggplot2::theme(axis.text.x = ggplot2::element_text(size = 6.2, angle = 30, hjust = 1))

master <- (p_vol / p_inputs / p_eff / p_biodiv) +
  patchwork::plot_layout(heights = c(1.35, 1.1, 1.05, 0.95), guides = "collect") +
  patchwork::plot_annotation(
    title    = "Crop volatility, input use and biodiversity context in Spain and the UK",
    subtitle = "Climate events, CAP reforms, UK pesticide policy and Brexit provide temporal context.",
    caption  = "Descriptive figure. Output-per-input is a productivity proxy.",
    theme = ggplot2::theme(
      plot.title    = ggplot2::element_text(face = "bold", size = 18),
      plot.subtitle = ggplot2::element_text(colour = "grey25", size = 11),
      plot.caption  = ggplot2::element_text(colour = "grey35", size = 8)))

save_plot(master, "CH4_26_master_country_specific_events.png")

readr::write_csv(
  tibble::tibble(file = list.files(FIG_DIR, pattern = "\\.png$")),
  file.path(FIG_DIR, "CH4_26_figure_index.csv"))
