# Chapter 4: BII, inputs, climate and crop stability — master figures script
# Descriptive and correlative only. No causal claims.
# Produces 5 figures and 4 summary tables.
#
# Inputs (in CH4_Results/):
#   CH4_Combined_Spain_UK_panel_1970_2024_with_biodiv_extras.csv
#   CH4_crop_panel_clean_submission.csv (or equivalent)
#   CH4_pettitt_breakpoints_fixed.csv (optional)
#
# Outputs (in CH4_Results/Figures_CH4_MASTER_supervisor_cleaned/):
#   Fig01: BII + footprint dual-axis trajectories 2000-2020
#   Fig02: Yield per kg NPK across climate and biodiversity gradients
#   Fig03: Four-part supervisor panel (BII, inputs, stability, pollinators)
#   Fig04: Standardised system trajectories
#   Fig05: BII and NPK association with crop volatility heatmap

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(tidyr)
  library(stringr)
  library(purrr)
  library(ggplot2)
  library(zoo)
  library(scales)
  library(viridis)
  library(patchwork)
  library(tibble)
  library(broom)
})

ROOT       <- "~/Documents/FoodSecurityV2"
RESULT_DIR <- file.path(ROOT, "CH4_Results")
FIG_DIR    <- file.path(RESULT_DIR, "Figures_CH4_MASTER_supervisor_cleaned")
dir.create(FIG_DIR, recursive = TRUE, showWarnings = FALSE)

national_file <- file.path(RESULT_DIR,
  "CH4_Combined_Spain_UK_panel_1970_2024_with_biodiv_extras.csv")

crop_file <- c(
  file.path(RESULT_DIR, "CH4_crop_panel_clean_submission.csv"),
  file.path(RESULT_DIR, "CH4_crop_panel_with_biodiv_inputs.csv"),
  file.path(RESULT_DIR, "CH4_crop_panel_with_pollination.csv")
)[file.exists(c(
  file.path(RESULT_DIR, "CH4_crop_panel_clean_submission.csv"),
  file.path(RESULT_DIR, "CH4_crop_panel_with_biodiv_inputs.csv"),
  file.path(RESULT_DIR, "CH4_crop_panel_with_pollination.csv")
))][1]

break_file <- file.path(RESULT_DIR, "CH4_pettitt_breakpoints_fixed.csv")

if (!file.exists(national_file)) stop("Missing national panel: ", national_file)
if (is.na(crop_file) || !file.exists(crop_file)) stop("Missing crop panel.")

national_raw <- readr::read_csv(national_file, show_col_types = FALSE)
crop_raw     <- readr::read_csv(crop_file, show_col_types = FALSE)

clean_country <- function(x) {
  dplyr::case_when(
    x %in% c("United Kingdom",
             "United Kingdom of Great Britain and Northern Ireland",
             "GBR") ~ "UK",
    x %in% c("Spain", "ESP") ~ "Spain",
    TRUE ~ as.character(x)
  )
}

clean_crop <- function(x) {
  x |> as.character() |>
    stringr::str_replace_all("_", " ") |>
    stringr::str_squish() |>
    stringr::str_to_title()
}

get_numeric_col <- function(data, candidates, multiplier = 1) {
  found <- candidates[candidates %in% names(data)]
  if (length(found) == 0) return(rep(NA_real_, nrow(data)))
  suppressWarnings(as.numeric(data[[found[1]]]) * multiplier)
}

safe_divide <- function(a, b) {
  ifelse(!is.na(a) & !is.na(b) & is.finite(a) & is.finite(b) & b > 0, a / b, NA_real_)
}

roll_cv <- function(x, width = 5, min_mean = 1e-6) {
  r_sd   <- zoo::rollapply(x, width, sd,   fill = NA, align = "right", na.rm = TRUE)
  r_mean <- zoo::rollapply(x, width, mean, fill = NA, align = "right", na.rm = TRUE)
  ifelse(abs(r_mean) < min_mean, NA_real_, 100 * r_sd / r_mean)
}

index_first <- function(x) {
  fv <- x[is.finite(x)][1]
  if (length(fv) == 0 || !is.finite(fv) || fv == 0) return(rep(NA_real_, length(x)))
  100 * x / fv
}

zscore <- function(x) {
  if (sum(is.finite(x)) < 2 || sd(x, na.rm = TRUE) == 0) return(rep(NA_real_, length(x)))
  as.numeric(scale(x))
}

theme_ch4 <- function(base_size = 10) {
  ggplot2::theme_minimal(base_size = base_size) +
    ggplot2::theme(
      panel.grid.major  = ggplot2::element_blank(),
      panel.grid.minor  = ggplot2::element_blank(),
      plot.title        = ggplot2::element_text(face = "bold", size = base_size + 3),
      plot.subtitle     = ggplot2::element_text(colour = "grey25", size = base_size),
      axis.title        = ggplot2::element_text(face = "bold"),
      axis.text         = ggplot2::element_text(colour = "grey20"),
      strip.text        = ggplot2::element_text(face = "bold"),
      legend.position   = "bottom",
      plot.margin       = ggplot2::margin(9, 11, 9, 9)
    )
}

save_plot <- function(p, filename, width = 11, height = 7.5) {
  ggplot2::ggsave(file.path(FIG_DIR, filename), p,
                  width = width, height = height, dpi = 330, bg = "white")
}

country_cols <- c("Spain" = "#D55E00", "UK" = "#0072B2")
group_cols   <- c("Staples" = "#4D4D4D", "Non-staples" = "#999999")

uk_events <- tibble::tribble(
  ~event_start, ~event_end, ~event_type,
  1975, 1976, "Drought",
  1989, 1992, "Drought",
  2003, 2003, "Heat",
  2018, 2018, "Drought-heat",
  2022, 2023, "Drought-heat"
) |> dplyr::mutate(xmin = event_start - 0.5, xmax = event_end + 0.5)

event_cols <- c("Drought" = "#E8B45B", "Heat" = "#D96C75", "Drought-heat" = "#B45AA0")

uk_event_layer <- function() {
  list(
    ggplot2::geom_rect(
      data = uk_events,
      ggplot2::aes(xmin = xmin, xmax = xmax, ymin = -Inf, ymax = Inf, fill = event_type),
      inherit.aes = FALSE, alpha = 0.12
    ),
    ggplot2::scale_fill_manual(values = event_cols, name = "UK climate event")
  )
}

# Search for BII CSVs across known directories and prefer SSP/RCP2.6 scenario
bii_search_dirs <- c(file.path(ROOT, "Biodiversity"), file.path(ROOT, "WorkingData"),
                     file.path(ROOT, "CH4_Results"), ROOT)

bii_candidate_files <- unique(unlist(lapply(
  bii_search_dirs[file.exists(bii_search_dirs)],
  function(d) list.files(d, pattern = "\\.csv$", full.names = TRUE, recursive = TRUE)
)))
bii_candidate_files <- bii_candidate_files[
  stringr::str_detect(stringr::str_to_lower(basename(bii_candidate_files)),
                      "bii|biodiversity|intact")]

readr::write_csv(tibble::tibble(file = bii_candidate_files),
                 file.path(RESULT_DIR, "CH4_MASTER_BII_candidate_files_audit.csv"))

load_possible_bii <- function(path) {
  x <- tryCatch(readr::read_csv(path, show_col_types = FALSE), error = function(e) NULL)
  if (is.null(x) || nrow(x) == 0) return(NULL)
  nms <- names(x); low <- stringr::str_to_lower(nms)
  year_col    <- nms[stringr::str_detect(low, "year")][1]
  country_col <- nms[stringr::str_detect(low, "country|iso|adm0|nation")][1]
  bii_col     <- nms[stringr::str_detect(low, "^bii$|bii_|biodiversity.*intact|intactness")][1]
  scenario_col <- nms[stringr::str_detect(low, "scenario|rcp|ssp|pathway")]
  scenario_col <- if (length(scenario_col) > 0) scenario_col[1] else NA_character_
  if (anyNA(c(year_col, country_col, bii_col))) return(NULL)
  out <- tibble::tibble(
    Country_raw = as.character(x[[country_col]]),
    Year        = suppressWarnings(as.integer(x[[year_col]])),
    BII_raw     = suppressWarnings(as.numeric(x[[bii_col]])),
    Scenario    = if (!is.na(scenario_col)) as.character(x[[scenario_col]]) else NA_character_,
    source_file = path
  ) |>
    dplyr::mutate(Country     = clean_country(Country_raw),
                  Scenario_low = stringr::str_to_lower(dplyr::coalesce(Scenario, ""))) |>
    dplyr::filter(Country %in% c("Spain", "UK"), Year >= 1970, Year <= 2024, is.finite(BII_raw))
  if (nrow(out) == 0) return(NULL)
  out
}

bii_loaded <- purrr::keep(purrr::map(bii_candidate_files, load_possible_bii), ~!is.null(.x))

if (length(bii_loaded) > 0) {
  bii_26 <- dplyr::bind_rows(bii_loaded) |>
    dplyr::mutate(
      scenario_rank = dplyr::case_when(
        stringr::str_detect(Scenario_low,
          "rcp\\s*2\\.?6|rcp26|ssp1\\s*-?\\s*2\\.?6|ssp126|ssp\\s*2\\.?6|2\\.6") ~ 1L,
        Scenario_low == "" | is.na(Scenario_low) ~ 2L,
        TRUE ~ 3L),
      BII_26_pct = ifelse(BII_raw <= 1.5, BII_raw * 100, BII_raw)
    ) |>
    dplyr::arrange(Country, Year, scenario_rank) |>
    dplyr::group_by(Country, Year) |> dplyr::slice(1) |> dplyr::ungroup() |>
    dplyr::select(Country, Year, BII_26_pct, Scenario, source_file, scenario_rank)
} else {
  bii_26 <- tibble::tibble(Country = character(), Year = integer(),
                            BII_26_pct = numeric(), Scenario = character(),
                            source_file = character(), scenario_rank = integer())
}

readr::write_csv(bii_26,
  file.path(RESULT_DIR, "CH4_MASTER_BII_SSP_RCP26_selected_1970_2024.csv"))

national <- national_raw |>
  dplyr::mutate(
    Country = clean_country(.data$Country),
    Year    = as.integer(.data$Year),
    BII_panel_pct = if ("BII_pct" %in% names(.))
        suppressWarnings(as.numeric(.data[["BII_pct"]]))
      else if ("BII" %in% names(.))
        suppressWarnings(as.numeric(.data[["BII"]]) * 100)
      else NA_real_,
    Footprint_1000km2 = if ("BIIFP_total_1000km2" %in% names(.))
        suppressWarnings(as.numeric(.data[["BIIFP_total_1000km2"]]))
      else if ("BII_loss_footprint_total_km2" %in% names(.))
        suppressWarnings(as.numeric(.data[["BII_loss_footprint_total_km2"]]) / 1000)
      else NA_real_,
    Footprint_crop_1000km2 = if ("BIIFP_crop_1000km2" %in% names(.))
        suppressWarnings(as.numeric(.data[["BIIFP_crop_1000km2"]]))
      else if ("BII_loss_footprint_crop_km2" %in% names(.))
        suppressWarnings(as.numeric(.data[["BII_loss_footprint_crop_km2"]]) / 1000)
      else NA_real_
  ) |>
  dplyr::left_join(
    bii_26 |> dplyr::select(Country, Year, BII_26_pct,
                              BII_26_source_file = source_file,
                              BII_26_scenario    = Scenario),
    by = c("Country", "Year")
  ) |>
  dplyr::mutate(
    BII_pct    = dplyr::coalesce(BII_26_pct, BII_panel_pct),
    BII_source = dplyr::case_when(
      is.finite(BII_26_pct)    ~ "SSP/RCP2.6 BII long series",
      is.finite(BII_panel_pct) ~ "merged panel BII fallback",
      TRUE ~ "missing"),
    total_fertiliser_kg_ha =
      get_numeric_col(., "N_kg_ha") +
      get_numeric_col(., "P_kg_ha") +
      get_numeric_col(., "K_kg_ha"),
    total_input_kg_ha = total_fertiliser_kg_ha + get_numeric_col(., "Pesticide_kg_ha"),
    NPK_output_per_input = safe_divide(get_numeric_col(., "Yield_kg_ha"),
                                       total_fertiliser_kg_ha)
  ) |>
  dplyr::group_by(Country) |>
  dplyr::arrange(Year, .by_group = TRUE) |>
  dplyr::mutate(
    yield_volatility_5yr = roll_cv(get_numeric_col(dplyr::cur_data_all(), "Yield_kg_ha"), 5),
    area_volatility_5yr  = roll_cv(get_numeric_col(dplyr::cur_data_all(), "HarvestedArea_ha"), 5),
    input_volatility_5yr = roll_cv(total_input_kg_ha, 5)
  ) |>
  dplyr::ungroup()

readr::write_csv(
  dplyr::select(national, Country, Year, BII_pct, BII_panel_pct, BII_26_pct,
                BII_source, BII_26_scenario, BII_26_source_file),
  file.path(RESULT_DIR, "CH4_MASTER_BII_source_used_audit.csv"))

crop <- crop_raw |>
  dplyr::mutate(
    Country  = clean_country(.data$Country),
    Crop     = clean_crop(.data$Crop),
    Year     = as.integer(.data$Year),
    Crop_lower = stringr::str_to_lower(.data$Crop),
    crop_group = dplyr::case_when(
      stringr::str_detect(Crop_lower,
        "wheat|barley|oats|rye|maize|potato|potatoes") ~ "Staples",
      TRUE ~ "Non-staples"),
    total_fertiliser_kg_ha =
      get_numeric_col(., "N_kg_ha") +
      get_numeric_col(., "P_kg_ha") +
      get_numeric_col(., "K_kg_ha")
  ) |>
  dplyr::left_join(dplyr::select(national, Country, Year, BII_pct),
                   by = c("Country", "Year"))

crop_stability <- crop |>
  dplyr::group_by(Country, crop_group, Year) |>
  dplyr::summarise(
    mean_yield             = mean(get_numeric_col(dplyr::cur_data_all(), "Yield_crop_kg_ha"), na.rm = TRUE),
    harvested_area         = sum(get_numeric_col(dplyr::cur_data_all(), "HarvestedArea_crop_ha"), na.rm = TRUE),
    BII_pct                = mean(BII_pct, na.rm = TRUE),
    total_fertiliser_kg_ha = mean(total_fertiliser_kg_ha, na.rm = TRUE),
    n_crops                = dplyr::n_distinct(Crop),
    .groups = "drop"
  ) |>
  dplyr::mutate(
    mean_yield             = ifelse(is.nan(mean_yield), NA_real_, mean_yield),
    harvested_area         = ifelse(harvested_area == 0, NA_real_, harvested_area),
    BII_pct                = ifelse(is.nan(BII_pct), NA_real_, BII_pct),
    total_fertiliser_kg_ha = ifelse(is.nan(total_fertiliser_kg_ha), NA_real_, total_fertiliser_kg_ha)
  ) |>
  dplyr::group_by(Country, crop_group) |>
  dplyr::arrange(Year, .by_group = TRUE) |>
  dplyr::mutate(
    yield_volatility_5yr = roll_cv(mean_yield, 5),
    area_volatility_5yr  = roll_cv(harvested_area, 5)
  ) |>
  dplyr::ungroup()

readr::write_csv(dplyr::distinct(crop, Country, Crop, crop_group),
                 file.path(RESULT_DIR, "CH4_MASTER_crop_group_classification_audit.csv"))
readr::write_csv(crop_stability,
                 file.path(RESULT_DIR, "CH4_MASTER_crop_stability_panel.csv"))

# Figure 1: BII + footprint dual axis 2000-2020
fig1_df <- national |>
  dplyr::filter(Country %in% c("Spain", "UK"), Year >= 2000, Year <= 2020) |>
  dplyr::select(Country, Year, BII_pct, Footprint_1000km2) |>
  dplyr::filter(is.finite(BII_pct) | is.finite(Footprint_1000km2)) |>
  dplyr::arrange(Country, Year)

bii_rng <- range(fig1_df$BII_pct, na.rm = TRUE)
fp_rng  <- range(fig1_df$Footprint_1000km2, na.rm = TRUE)
scale_fp_to_bii  <- function(x) (x - fp_rng[1])  / diff(fp_rng)  * diff(bii_rng) + bii_rng[1]
scale_bii_to_fp  <- function(x) (x - bii_rng[1]) / diff(bii_rng) * diff(fp_rng)  + fp_rng[1]

fig1_df <- dplyr::mutate(fig1_df, Footprint_scaled = scale_fp_to_bii(Footprint_1000km2))

breaks_use <- tibble::tribble(
  ~Country, ~break_year, ~break_type,
  "Spain", 2004, "BII break",
  "Spain", 2008, "Footprint break",
  "Spain", 2009, "Footprint break"
)

if (file.exists(break_file)) {
  br_raw <- readr::read_csv(break_file, show_col_types = FALSE)
  if ("Country" %in% names(br_raw)) {
    year_vec <- suppressWarnings(as.integer(
      br_raw[[c("break_year","year","estimate_year")[
        c("break_year","year","estimate_year") %in% names(br_raw)][1]]]))
    br <- br_raw |>
      dplyr::mutate(
        Country    = clean_country(.data$Country),
        break_year = year_vec,
        break_type = dplyr::case_when(
          stringr::str_detect(stringr::str_to_lower(
            paste(dplyr::across(dplyr::any_of(c("variable","series","metric")),
                                as.character), collapse = " ")),
            "footprint|biifp|loss") ~ "Footprint break",
          stringr::str_detect(stringr::str_to_lower(
            paste(dplyr::across(dplyr::any_of(c("variable","series","metric")),
                                as.character), collapse = " ")),
            "bii") ~ "BII break",
          TRUE ~ "Pettitt break")
      ) |>
      dplyr::filter(Country == "Spain", break_year >= 2000, break_year <= 2020,
                    break_type %in% c("BII break", "Footprint break")) |>
      dplyr::distinct(Country, break_year, break_type)
    if (nrow(br) > 0)
      breaks_use <- dplyr::distinct(dplyr::bind_rows(br, breaks_use),
                                    Country, break_year, break_type)
  }
}

p_fig1 <- ggplot2::ggplot(fig1_df, ggplot2::aes(x = Year)) +
  ggplot2::geom_vline(data = breaks_use,
    ggplot2::aes(xintercept = break_year, linetype = break_type),
    colour = "grey35", linewidth = 0.45, alpha = 0.75, inherit.aes = FALSE) +
  ggplot2::geom_line(ggplot2::aes(y = BII_pct, colour = Country), linewidth = 1.05) +
  ggplot2::geom_point(ggplot2::aes(y = BII_pct, colour = Country), size = 2.0) +
  ggplot2::geom_line(ggplot2::aes(y = Footprint_scaled, colour = Country),
                     linewidth = 1.05, linetype = "dashed") +
  ggplot2::geom_point(ggplot2::aes(y = Footprint_scaled, colour = Country),
                      size = 2.0, shape = 17) +
  ggplot2::scale_colour_manual(values = country_cols, name = NULL) +
  ggplot2::scale_linetype_manual(
    values = c("BII break" = "solid", "Footprint break" = "dashed"), name = NULL) +
  ggplot2::scale_x_continuous(breaks = seq(2000, 2020, 5)) +
  ggplot2::scale_y_continuous(
    name = "Biodiversity Intactness Index, %",
    sec.axis = ggplot2::sec_axis(~ scale_bii_to_fp(.),
                                  name = "Total biodiversity loss footprint, 1000 km2")) +
  ggplot2::labs(
    title    = "Biodiversity intactness and biodiversity loss footprint trajectories",
    subtitle = "Solid lines show national BII; dashed lines show total biodiversity loss footprint.",
    x = NULL) +
  theme_ch4(10) +
  ggplot2::theme(axis.title.y.left  = ggplot2::element_text(face = "bold"),
                 axis.title.y.right = ggplot2::element_text(face = "bold"))

ggplot2::ggsave(file.path(FIG_DIR, "CH4_fig1_bii_footprint_trajectories.png"),
                p_fig1, width = 10.5, height = 6.4, dpi = 330, bg = "white")
readr::write_csv(fig1_df, file.path(RESULT_DIR, "CH4_fig1_bii_footprint_trajectories_data_used.csv"))
readr::write_csv(breaks_use, file.path(RESULT_DIR, "CH4_fig1_bii_footprint_breaks_used.csv"))

# Figure 2: Efficiency panel
eff_panel <- national |>
  dplyr::select(Country, Year, NPK_output_per_input, pdsi_annual_mean,
                bio1, BII_pct, Footprint_1000km2) |>
  tidyr::pivot_longer(cols = c(pdsi_annual_mean, bio1, BII_pct, Footprint_1000km2),
                      names_to = "driver", values_to = "driver_value") |>
  dplyr::mutate(driver = dplyr::recode(driver,
    "pdsi_annual_mean" = "Drought stress (PDSI)",
    "bio1"             = "Mean annual temperature",
    "BII_pct"          = "BII",
    "Footprint_1000km2" = "BII loss footprint")) |>
  dplyr::filter(is.finite(driver_value), is.finite(NPK_output_per_input))

p_eff <- ggplot2::ggplot(eff_panel, ggplot2::aes(driver_value, NPK_output_per_input)) +
  ggplot2::geom_point(ggplot2::aes(colour = Country), size = 2.3, alpha = 0.78) +
  ggplot2::geom_smooth(method = "lm", se = TRUE, colour = "grey25",
                       fill = "grey82", linewidth = 0.65, alpha = 0.35) +
  ggplot2::facet_grid(Country ~ driver, scales = "free_x") +
  ggplot2::scale_colour_manual(values = country_cols, guide = "none") +
  ggplot2::labs(title    = "Output per unit fertiliser across climate and biodiversity gradients",
                subtitle = "Yield per kg NPK. Linear guides are descriptive only.",
                x = NULL, y = "Yield per kg NPK fertiliser") +
  theme_ch4(9)

save_plot(p_eff, "CH4_MASTER_Fig02_clean_efficiency_panel.png", 12, 6.8)

# Figure 3: Four-part supervisor panel
input_time <- national |>
  dplyr::select(Country, Year, BII_pct, total_fertiliser_kg_ha,
                total_input_kg_ha, Pesticide_kg_ha) |>
  dplyr::group_by(Country) |>
  dplyr::mutate(BII          = index_first(BII_pct),
                `Combined NPK` = index_first(total_fertiliser_kg_ha),
                `Total input`  = index_first(total_input_kg_ha),
                Pesticides     = index_first(Pesticide_kg_ha)) |>
  dplyr::ungroup() |>
  dplyr::select(Country, Year, BII, `Combined NPK`, `Total input`, Pesticides) |>
  tidyr::pivot_longer(-c(Country, Year), names_to = "Metric", values_to = "Index") |>
  dplyr::filter(is.finite(Index))

p_A <- ggplot2::ggplot(input_time, ggplot2::aes(Year, Index)) +
  ggplot2::geom_hline(yintercept = 100, colour = "grey70", linewidth = 0.3) +
  ggplot2::geom_line(ggplot2::aes(colour = Metric), linewidth = 0.78, alpha = 0.9) +
  ggplot2::facet_wrap(~Country, ncol = 1, scales = "free_y") +
  ggplot2::labs(title = "A. BII and input use",
                subtitle = "Indexed to first available value = 100",
                x = NULL, y = "Index", colour = NULL) +
  theme_ch4(8.8)

stability_time <- crop_stability |>
  dplyr::select(Country, crop_group, Year, yield_volatility_5yr, area_volatility_5yr) |>
  tidyr::pivot_longer(c(yield_volatility_5yr, area_volatility_5yr),
                      names_to = "Metric", values_to = "Volatility") |>
  dplyr::mutate(Metric = dplyr::recode(Metric,
    "yield_volatility_5yr" = "Yield",
    "area_volatility_5yr"  = "Harvested area")) |>
  dplyr::filter(is.finite(Volatility))

p_B <- ggplot2::ggplot(stability_time, ggplot2::aes(Year, Volatility)) +
  ggplot2::geom_line(ggplot2::aes(colour = crop_group), linewidth = 0.82, alpha = 0.9) +
  ggplot2::geom_point(ggplot2::aes(colour = crop_group), size = 1.6, alpha = 0.75) +
  ggplot2::facet_grid(Metric ~ Country, scales = "free_y") +
  ggplot2::scale_colour_manual(values = group_cols) +
  ggplot2::labs(title = "B. Crop stability",
                subtitle = "Five-year rolling coefficient of variation",
                x = NULL, y = "Rolling CV, %", colour = NULL) +
  theme_ch4(8.8)

joint_df <- crop_stability |>
  dplyr::select(Country, crop_group, Year, BII_pct,
                total_fertiliser_kg_ha, yield_volatility_5yr) |>
  dplyr::filter(is.finite(BII_pct), is.finite(total_fertiliser_kg_ha),
                is.finite(yield_volatility_5yr))

p_C <- ggplot2::ggplot(joint_df, ggplot2::aes(BII_pct, yield_volatility_5yr)) +
  ggplot2::geom_point(ggplot2::aes(size = total_fertiliser_kg_ha, colour = crop_group),
                      alpha = 0.72) +
  ggplot2::geom_smooth(method = "lm", se = TRUE, colour = "grey25",
                       fill = "grey85", linewidth = 0.6, alpha = 0.28) +
  ggplot2::facet_wrap(~Country, scales = "free_x") +
  ggplot2::scale_colour_manual(values = group_cols) +
  ggplot2::scale_size_continuous(range = c(1.4, 4.6), name = "NPK kg/ha") +
  ggplot2::labs(title = "C. BII, inputs and yield stability",
                subtitle = "Point size shows combined NPK input",
                x = "BII, %", y = "Yield rolling CV, %", colour = NULL) +
  theme_ch4(8.8)

uk_biodiv <- national |>
  dplyr::filter(Country == "UK") |>
  dplyr::select(Year, BII_pct, UK_pollinator_index) |>
  dplyr::arrange(Year) |>
  dplyr::mutate(BII                  = index_first(BII_pct),
                `UK pollinator index` = index_first(UK_pollinator_index)) |>
  dplyr::select(Year, BII, `UK pollinator index`) |>
  tidyr::pivot_longer(-Year, names_to = "Metric", values_to = "Index") |>
  dplyr::filter(is.finite(Index))

p_D <- ggplot2::ggplot(uk_biodiv, ggplot2::aes(Year, Index)) +
  uk_event_layer() +
  ggplot2::geom_hline(yintercept = 100, colour = "grey70", linewidth = 0.3) +
  ggplot2::geom_line(ggplot2::aes(colour = Metric, linetype = Metric),
                     linewidth = 0.95, alpha = 0.9) +
  ggplot2::geom_point(ggplot2::aes(colour = Metric), size = 2.0, alpha = 0.85) +
  ggplot2::labs(title = "D. UK BII and pollinator index",
                subtitle = "Indexed trajectories with drought/heat context",
                x = "Year", y = "Index", colour = NULL, linetype = NULL) +
  theme_ch4(8.8)

four_panel <- (p_A | p_B) / (p_C | p_D) +
  patchwork::plot_annotation(
    title    = "Biodiversity, input use and crop stability",
    subtitle = "Descriptive four-part panel using SSP/RCP2.6 BII where available through 2024.")

save_plot(four_panel, "CH4_MASTER_Fig03_four_part_BII_inputs_stability_panel.png", 17, 13)

# Figure 4: Standardised system trajectories
system_panel <- national |>
  dplyr::select(Country, Year, BII_pct, Footprint_1000km2, total_fertiliser_kg_ha,
                Yield_kg_ha, NPK_output_per_input, yield_volatility_5yr,
                area_volatility_5yr) |>
  dplyr::group_by(Country) |>
  dplyr::mutate(
    BII                = zscore(BII_pct),
    `BII loss footprint` = zscore(Footprint_1000km2),
    `Combined NPK`     = zscore(total_fertiliser_kg_ha),
    Yield              = zscore(Yield_kg_ha),
    `Yield per kg NPK` = zscore(NPK_output_per_input),
    `Yield volatility` = zscore(yield_volatility_5yr),
    `Area volatility`  = zscore(area_volatility_5yr)
  ) |>
  dplyr::ungroup() |>
  dplyr::select(Country, Year, BII, `BII loss footprint`, `Combined NPK`,
                Yield, `Yield per kg NPK`, `Yield volatility`, `Area volatility`) |>
  tidyr::pivot_longer(-c(Country, Year), names_to = "Metric", values_to = "Value") |>
  dplyr::filter(is.finite(Value))

p_big <- ggplot2::ggplot(system_panel, ggplot2::aes(Year, Value)) +
  ggplot2::geom_hline(yintercept = 0, colour = "grey75", linewidth = 0.25) +
  ggplot2::geom_line(ggplot2::aes(colour = Metric), linewidth = 0.78, alpha = 0.88) +
  ggplot2::facet_wrap(~Country, ncol = 1) +
  ggplot2::labs(
    title    = "System trajectories: biodiversity, inputs, output and stability",
    subtitle = "Series standardised within country to compare trajectory shape.",
    x = "Year", y = "Within-country standardised value", colour = NULL) +
  theme_ch4(9)

save_plot(p_big, "CH4_MASTER_Fig04_clean_big_panel_standardised_system_trajectories.png",
          12.5, 8)

# Statistical summary: BII and NPK association with crop volatility
fit_lm_safe <- function(data, formula, model_label, response_label) {
  d <- data |> dplyr::filter(dplyr::if_all(dplyr::all_of(all.vars(formula)), is.finite))
  if (nrow(d) < 8) return(tibble::tibble(response = response_label, model = model_label,
    term = NA_character_, estimate = NA_real_, p_value = NA_real_,
    n = nrow(d), r_squared = NA_real_, status = "insufficient data"))
  m <- tryCatch(stats::lm(formula, data = d), error = function(e) NULL)
  if (is.null(m)) return(tibble::tibble(response = response_label, model = model_label,
    term = NA_character_, estimate = NA_real_, p_value = NA_real_,
    n = nrow(d), r_squared = NA_real_, status = "model failed"))
  broom::tidy(m) |>
    dplyr::filter(term != "(Intercept)") |>
    dplyr::transmute(response = response_label, model = model_label, term = term,
                     estimate = estimate, p_value = p.value, n = stats::nobs(m),
                     r_squared = broom::glance(m)$r.squared, status = "estimated")
}

analysis_df <- crop_stability |>
  dplyr::select(Country, crop_group, Year, BII_pct, total_fertiliser_kg_ha,
                yield_volatility_5yr, area_volatility_5yr) |>
  dplyr::filter(is.finite(BII_pct), is.finite(total_fertiliser_kg_ha))

stats_table <- dplyr::bind_rows(
  analysis_df |> dplyr::group_by(Country, crop_group) |>
    dplyr::group_modify(~ fit_lm_safe(.x,
      yield_volatility_5yr ~ BII_pct + total_fertiliser_kg_ha,
      "raw_level_lm", "yield_volatility_5yr")) |> dplyr::ungroup(),
  analysis_df |> dplyr::group_by(Country, crop_group) |>
    dplyr::group_modify(~ fit_lm_safe(.x,
      area_volatility_5yr ~ BII_pct + total_fertiliser_kg_ha,
      "raw_level_lm", "area_volatility_5yr")) |> dplyr::ungroup()
) |>
  dplyr::mutate(significance = dplyr::case_when(
    is.na(p_value)  ~ "not estimated",
    p_value < 0.001 ~ "***",
    p_value < 0.01  ~ "**",
    p_value < 0.05  ~ "*",
    p_value < 0.1   ~ ".",
    TRUE ~ "ns"))

readr::write_csv(stats_table,
  file.path(RESULT_DIR, "CH4_MASTER_BII_input_stability_lm_summary.csv"))

# Figure 5: Heatmap of associations
heat_df <- stats_table |>
  dplyr::filter(status == "estimated") |>
  dplyr::mutate(
    group      = paste(Country, crop_group, response, sep = " / "),
    term_clean = dplyr::recode(term, "BII_pct" = "BII",
                               "total_fertiliser_kg_ha" = "NPK"))

if (nrow(heat_df) > 0) {
  p_heat <- ggplot2::ggplot(heat_df, ggplot2::aes(term_clean, group, fill = estimate)) +
    ggplot2::geom_tile(colour = "white", linewidth = 0.5) +
    ggplot2::geom_text(ggplot2::aes(label = significance), size = 4) +
    ggplot2::scale_fill_gradient2(low = "#2166AC", mid = "white", high = "#B2182B",
                                   midpoint = 0) +
    ggplot2::labs(
      title    = "Association of BII and fertiliser input with crop volatility",
      subtitle = "Cell colour shows coefficient sign and size; symbols show nominal p-values.",
      x = NULL, y = NULL, fill = "Estimate") +
    theme_ch4(9) + ggplot2::theme(legend.position = "right")
  save_plot(p_heat, "CH4_MASTER_Fig05_BII_NPK_stability_statistical_heatmap.png", 12, 7.5)
}

readr::write_csv(
  tibble::tibble(file = list.files(FIG_DIR, pattern = "\\.png$", full.names = FALSE)),
  file.path(FIG_DIR, "CH4_MASTER_figure_index.csv"))
