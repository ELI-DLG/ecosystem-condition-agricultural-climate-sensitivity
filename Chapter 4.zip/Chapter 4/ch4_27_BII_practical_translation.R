# Chapter 4 — Figure 27: Practical translation of the BII staged decomposition
# Translates model prediction error changes into interpretable units.
# Answers: after controlling for policy and climate, how much does adding BII
# change prediction error, expressed as % of observed mean and SD?
# Descriptive/diagnostic only.
#
# Inputs (in CH4_Results/):
#   CH4_21_group_panel_with_lagged_events.csv
#   CH4_21_staged_model_comparison.csv
#
# Outputs (in CH4_Results/Figures_CH4_27_BII_practical_translation/):
#   CH4_27_Fig01_BII_error_change_pct_mean.png
#   CH4_27_Fig02_BII_error_change_pct_sd.png
#   CH4_27_Fig03_BII_translation_lollipop.png
#   CH4_27_Fig04_reader_friendly_staged_error_units.png
#   CH4_27_Fig05_combined_BII_practical_translation_dashboard.png
#   CH4_27_interpretable_BII_RMSE_translation.csv
#   CH4_27_BII_translation_writing_summary.csv

suppressPackageStartupMessages({
  library(dplyr); library(readr); library(tidyr); library(stringr)
  library(forcats); library(ggplot2); library(scales); library(tibble)
  library(patchwork); library(grid)
})

ROOT       <- "~/Documents/FoodSecurityV2"
RESULT_DIR <- file.path(ROOT, "CH4_Results")
FIG_DIR    <- file.path(RESULT_DIR, "Figures_CH4_27_BII_practical_translation")
dir.create(FIG_DIR, recursive = TRUE, showWarnings = FALSE)

panel_file <- file.path(RESULT_DIR, "CH4_21_group_panel_with_lagged_events.csv")
stage_file <- file.path(RESULT_DIR, "CH4_21_staged_model_comparison.csv")
if (!file.exists(panel_file)) stop("Missing group panel: ", panel_file)
if (!file.exists(stage_file)) stop("Missing staged model table: ", stage_file)

group_panel   <- readr::read_csv(panel_file, show_col_types = FALSE)
staged_models <- readr::read_csv(stage_file, show_col_types = FALSE)

country_cols <- c("Spain" = "#D55E00", "UK" = "#0072B2")

response_labels <- c(
  "yield_index"                  = "Yield",
  "production_index"             = "Production",
  "area_index"                   = "Harvested area",
  "output_per_input_index_w"     = "Output per input",
  "yield_volatility_w"           = "Yield volatility",
  "production_volatility_w"      = "Production volatility",
  "output_per_input_volatility_w" = "Output-per-input volatility"
)

stage_labels <- c(
  "M0_time_only"           = "Time only",
  "M1_policy_lags"         = "Policy lags",
  "M2_policy_climate_lags" = "Policy + climate-event lags",
  "M3_add_climate_state"   = "Policy + climate + climate state",
  "M4_add_BII"             = "Add BII",
  "M5_add_inputs"          = "Add inputs"
)

clean_response <- function(x) dplyr::recode(x, !!!response_labels, .default = x)
clean_stage    <- function(x) dplyr::recode(x, !!!stage_labels,    .default = x)

theme_pretty <- function(base_size = 9.5) {
  ggplot2::theme_classic(base_size = base_size) +
    ggplot2::theme(
      plot.title       = ggplot2::element_text(face = "bold", size = base_size + 4),
      plot.subtitle    = ggplot2::element_text(colour = "grey25", size = base_size),
      plot.caption     = ggplot2::element_text(colour = "grey35", size = base_size - 1),
      axis.title       = ggplot2::element_text(face = "bold"),
      axis.text        = ggplot2::element_text(colour = "grey20"),
      strip.background = ggplot2::element_blank(),
      strip.text       = ggplot2::element_text(face = "bold", colour = "grey15"),
      legend.position  = "bottom",
      legend.title     = ggplot2::element_blank(),
      panel.spacing    = grid::unit(1.1, "lines"),
      plot.margin      = ggplot2::margin(10, 12, 10, 10)
    )
}

save_plot <- function(p, filename, width = 12, height = 8) {
  ggplot2::ggsave(file.path(FIG_DIR, filename), p,
                  width = width, height = height, dpi = 360,
                  bg = "white", limitsize = FALSE)
}

cap_extreme <- function(x, probs = c(0.02, 0.98)) {
  if (sum(is.finite(x)) < 5) return(x)
  lim <- stats::quantile(x, probs = probs, na.rm = TRUE)
  pmax(pmin(x, lim[2]), lim[1])
}

candidate_responses <- c("yield_index","production_index","area_index",
                         "output_per_input_index_w","yield_volatility_w",
                         "production_volatility_w","output_per_input_volatility_w")

available_responses <- intersect(candidate_responses, names(group_panel))
if (length(available_responses) == 0)
  stop("None of the expected response columns found in group_panel.")

readr::write_csv(
  tibble::tibble(
    response                  = candidate_responses,
    present_in_group_panel    = candidate_responses %in% names(group_panel),
    present_in_staged_models  = candidate_responses %in% unique(staged_models$response)
  ),
  file.path(RESULT_DIR, "CH4_27_response_audit.csv"))

observed_scale <- group_panel |>
  dplyr::select(Country, crop_group, Year, dplyr::all_of(available_responses)) |>
  tidyr::pivot_longer(dplyr::all_of(available_responses),
                      names_to = "response", values_to = "observed_value") |>
  dplyr::filter(is.finite(observed_value)) |>
  dplyr::group_by(Country, crop_group, response) |>
  dplyr::summarise(
    n_observed       = dplyr::n(),
    mean_observed    = mean(observed_value, na.rm = TRUE),
    sd_observed      = sd(observed_value, na.rm = TRUE),
    iqr_observed     = IQR(observed_value, na.rm = TRUE),
    .groups = "drop")

stage_wide <- staged_models |>
  dplyr::filter(status == "estimated", response %in% available_responses,
                is.finite(loo_rmse)) |>
  dplyr::select(Country, crop_group, response, stage, loo_rmse, r_squared, n) |>
  dplyr::mutate(stage_clean = clean_stage(stage)) |>
  dplyr::left_join(observed_scale, by = c("Country", "crop_group", "response")) |>
  dplyr::group_by(Country, crop_group, response) |>
  dplyr::mutate(
    rmse_time_only            = loo_rmse[stage == "M0_time_only"][1],
    rmse_policy_climate_state = loo_rmse[stage == "M3_add_climate_state"][1],
    rmse_with_BII             = loo_rmse[stage == "M4_add_BII"][1],
    BII_error_change          = rmse_policy_climate_state - rmse_with_BII,
    BII_error_change_pct_of_mean = 100 * BII_error_change / mean_observed,
    BII_error_change_pct_of_sd   = 100 * BII_error_change / sd_observed,
    interpretation = dplyr::case_when(
      is.na(BII_error_change)  ~ "Not estimated",
      BII_error_change > 0     ~ "Adding BII reduced prediction error",
      BII_error_change < 0     ~ "Adding BII increased prediction error",
      TRUE ~ "No change")
  ) |>
  dplyr::ungroup() |>
  dplyr::mutate(
    response_label                     = clean_response(response),
    stage_label                        = clean_stage(stage),
    BII_error_change_pct_of_mean_capped = cap_extreme(BII_error_change_pct_of_mean),
    BII_error_change_pct_of_sd_capped   = cap_extreme(BII_error_change_pct_of_sd))

readr::write_csv(stage_wide,
  file.path(RESULT_DIR, "CH4_27_interpretable_BII_RMSE_translation.csv"))

bii_translation <- stage_wide |>
  dplyr::filter(stage == "M4_add_BII", is.finite(BII_error_change)) |>
  dplyr::mutate(
    crop_group     = forcats::fct_reorder(crop_group, BII_error_change_pct_of_mean,
                                           .fun = median, na.rm = TRUE),
    response_label = factor(response_label,
      levels = c("Yield","Production","Harvested area","Output per input",
                 "Yield volatility","Production volatility","Output-per-input volatility")))

p_mean <- ggplot2::ggplot(bii_translation,
    ggplot2::aes(BII_error_change_pct_of_mean_capped, crop_group, fill = Country)) +
  ggplot2::geom_vline(xintercept = 0, colour = "grey45", linewidth = 0.35) +
  ggplot2::geom_col(position = ggplot2::position_dodge(0.72), width = 0.62, alpha = 0.92) +
  ggplot2::facet_wrap(~response_label, scales = "free_x", ncol = 2) +
  ggplot2::scale_fill_manual(values = country_cols) +
  ggplot2::labs(
    title    = "What does adding BII change in practical terms?",
    subtitle = "Change in leave-one-out prediction error after adding BII, as % of observed mean. Positive = BII reduced error.",
    x = "Change in prediction error, % of observed mean", y = NULL,
    caption  = "Values capped at 2nd/98th percentiles.") +
  theme_pretty(9)

save_plot(p_mean, "CH4_27_Fig01_BII_error_change_pct_mean.png", 13, 10)

p_sd <- ggplot2::ggplot(bii_translation,
    ggplot2::aes(BII_error_change_pct_of_sd_capped, crop_group, fill = Country)) +
  ggplot2::geom_vline(xintercept = 0, colour = "grey45", linewidth = 0.35) +
  ggplot2::geom_col(position = ggplot2::position_dodge(0.72), width = 0.62, alpha = 0.92) +
  ggplot2::facet_wrap(~response_label, scales = "free_x", ncol = 2) +
  ggplot2::scale_fill_manual(values = country_cols) +
  ggplot2::labs(
    title    = "BII contribution relative to observed variability",
    subtitle = "Change in prediction error after adding BII, as % of observed SD.",
    x = "Change in prediction error, % of observed SD", y = NULL,
    caption  = "Scale translation only, not a causal effect size.") +
  theme_pretty(9)

save_plot(p_sd, "CH4_27_Fig02_BII_error_change_pct_sd.png", 13, 10)

lollipop_df <- bii_translation |>
  dplyr::filter(response %in% c("yield_index","production_index",
                                 "output_per_input_index_w","yield_volatility_w")) |>
  dplyr::mutate(
    signed_label = dplyr::case_when(
      BII_error_change > 0 ~ "BII reduced error",
      BII_error_change < 0 ~ "BII increased error",
      TRUE ~ "No change"),
    display_row = forcats::fct_reorder(
      paste(Country, crop_group, sep = " | "),
      BII_error_change_pct_of_mean, .fun = median, na.rm = TRUE))

p_lollipop <- ggplot2::ggplot(lollipop_df,
    ggplot2::aes(BII_error_change_pct_of_mean_capped, display_row, colour = signed_label)) +
  ggplot2::geom_vline(xintercept = 0, colour = "grey50", linewidth = 0.35) +
  ggplot2::geom_segment(ggplot2::aes(x = 0, xend = BII_error_change_pct_of_mean_capped,
                                     yend = display_row),
                        linewidth = 0.65, alpha = 0.75) +
  ggplot2::geom_point(size = 2.5, alpha = 0.95) +
  ggplot2::facet_wrap(~response_label, scales = "free_x", ncol = 2) +
  ggplot2::scale_colour_manual(values = c("BII reduced error" = "#1B9E77",
                                          "BII increased error" = "#D95F02",
                                          "No change" = "grey60")) +
  ggplot2::labs(
    title    = "Reader-facing translation of the BII step",
    subtitle = "BII step shown as error change after policy timing, climate-event timing and climate state.",
    x = "BII step: change in prediction error, % of observed mean",
    y = NULL, colour = NULL) +
  theme_pretty(8.7) +
  ggplot2::theme(axis.text.y = ggplot2::element_text(size = 7))

save_plot(p_lollipop, "CH4_27_Fig03_BII_translation_lollipop.png", 13, 9.5)

stage_units <- stage_wide |>
  dplyr::filter(stage %in% c("M0_time_only","M3_add_climate_state",
                               "M4_add_BII","M5_add_inputs"),
                response %in% c("yield_index","production_index",
                                 "output_per_input_index_w","yield_volatility_w"),
                is.finite(loo_rmse)) |>
  dplyr::mutate(
    stage_label    = factor(clean_stage(stage),
      levels = c("Time only","Policy + climate + climate state","Add BII","Add inputs")),
    response_label = factor(response_label,
      levels = c("Yield","Production","Output per input","Yield volatility"))) |>
  dplyr::group_by(Country, response_label, stage_label) |>
  dplyr::summarise(
    median_rmse = median(loo_rmse, na.rm = TRUE),
    lo = stats::quantile(loo_rmse, 0.25, na.rm = TRUE),
    hi = stats::quantile(loo_rmse, 0.75, na.rm = TRUE),
    .groups = "drop")

p_units <- ggplot2::ggplot(stage_units,
    ggplot2::aes(stage_label, median_rmse, colour = Country, group = Country)) +
  ggplot2::geom_linerange(ggplot2::aes(ymin = lo, ymax = hi),
    position = ggplot2::position_dodge(0.35), alpha = 0.75, linewidth = 0.55) +
  ggplot2::geom_line(position = ggplot2::position_dodge(0.35),
                     linewidth = 0.7, alpha = 0.78) +
  ggplot2::geom_point(position = ggplot2::position_dodge(0.35), size = 2.4) +
  ggplot2::facet_wrap(~response_label, scales = "free_y", ncol = 2) +
  ggplot2::scale_colour_manual(values = country_cols) +
  ggplot2::labs(
    title    = "Model error in observed outcome units",
    subtitle = "Lower values mean lower leave-one-out prediction error.",
    x = NULL, y = "Leave-one-out RMSE", colour = NULL) +
  theme_pretty(9) +
  ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 25, hjust = 1))

save_plot(p_units, "CH4_27_Fig04_reader_friendly_staged_error_units.png", 12, 8)

summary_plot <- (p_lollipop / p_units) +
  patchwork::plot_layout(heights = c(1.1, 1)) +
  patchwork::plot_annotation(
    title    = "Practical translation of the biodiversity step",
    subtitle = "BII evaluated after policy timing, climate-event timing and climate state.",
    caption  = "Positive BII-step values mean adding BII reduced prediction error. Screening diagnostics, not causal estimates.",
    theme = ggplot2::theme(
      plot.title    = ggplot2::element_text(face = "bold", size = 16),
      plot.subtitle = ggplot2::element_text(colour = "grey25", size = 10),
      plot.caption  = ggplot2::element_text(colour = "grey35", size = 8)))

save_plot(summary_plot,
          "CH4_27_Fig05_combined_BII_practical_translation_dashboard.png", 14, 16)

readr::write_csv(
  bii_translation |>
    dplyr::group_by(Country, response_label) |>
    dplyr::summarise(
      n_crop_groups                    = dplyr::n_distinct(crop_group),
      median_BII_error_change          = median(BII_error_change, na.rm = TRUE),
      median_BII_error_change_pct_mean = median(BII_error_change_pct_of_mean, na.rm = TRUE),
      median_BII_error_change_pct_sd   = median(BII_error_change_pct_of_sd, na.rm = TRUE),
      dominant_direction = dplyr::case_when(
        median_BII_error_change > 0 ~ "BII generally reduced prediction error",
        median_BII_error_change < 0 ~ "BII generally increased prediction error",
        TRUE ~ "No median change"),
      .groups = "drop"),
  file.path(RESULT_DIR, "CH4_27_BII_translation_writing_summary.csv"))

readr::write_csv(
  tibble::tibble(file = list.files(FIG_DIR, pattern = "\\.png$")),
  file.path(FIG_DIR, "CH4_27_figure_index.csv"))
