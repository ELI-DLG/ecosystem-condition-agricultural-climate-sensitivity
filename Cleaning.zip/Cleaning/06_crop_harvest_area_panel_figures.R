# Data cleaning: harvested crop area panel figures
# Produces one multi-panel figure per country showing spatial distribution
# of harvested area for each crop. Uses viridis colour scale with sf outlines.
#
# Inputs:
#   HarvestedCropArea/ trimmed rasters (from 02_crop_area_calendar_yield_bioclim_BII_trim.R)
#   GADM shapefiles: basicshapes/gadm41_XXX_shp/
#
# Outputs:
#   output/crop_panel_figures/COUNTRY_crop_panel.png (one per country)

library(terra)
library(ggplot2)
library(glue)
library(patchwork)
library(stringr)
library(sf)
library(viridis)
library(dplyr)

base_dir    <- "~/Documents/FoodSecurityV2"
harvest_dir <- file.path(base_dir, "HarvestedCropArea")
fig_dir     <- file.path(base_dir, "output/crop_panel_figures")
dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)

shapefile_dir <- file.path(base_dir, "basicshapes")

usa <- vect(file.path(shapefile_dir, "gadm41_USA_shp/gadm41_USA_1.shp"))
usa <- usa[!usa$NAME_1 %in% c("Alaska", "Hawaii"), ] |> aggregate()

countries <- list(
  usa       = usa,
  brazil    = vect(file.path(shapefile_dir, "gadm41_BRA_shp/gadm41_BRA_0.shp")),
  kenya     = vect(file.path(shapefile_dir, "gadm41_KEN_shp/gadm41_KEN_0.shp")),
  uk        = vect(file.path(shapefile_dir, "gadm41_GBR_shp/gadm41_GBR_0.shp")),
  spain     = vect(file.path(shapefile_dir, "TrimmedShapes/spain_mainland_mallorca.shp")),
  mexico    = vect(file.path(shapefile_dir, "gadm41_MEX_shp/gadm41_MEX_0.shp")),
  indonesia = vect(file.path(shapefile_dir, "gadm41_IDN_shp/gadm41_IDN_0.shp"))
)

crop_country_map <- list(
  maize       = c("usa","brazil","kenya","uk","spain","mexico","indonesia"),
  rice        = c("usa","brazil","kenya","spain","mexico","indonesia"),
  wheat       = c("usa","brazil","kenya","uk","spain","mexico"),
  soybean     = c("usa","brazil","kenya","mexico"),
  rye         = c("uk","usa","spain"),
  cassava     = c("brazil","kenya","indonesia"),
  potato      = c("usa","brazil","kenya","uk","spain","mexico","indonesia"),
  sweetpotato = c("usa","brazil","kenya","indonesia"),
  millet      = c("brazil","kenya"),
  bean        = c("usa","brazil","kenya","mexico"),
  barley      = c("usa","uk","spain","mexico"),
  oats        = c("usa","uk","spain"),
  sorghum     = c("usa","brazil","kenya"),
  pulses      = c("usa","brazil","kenya","spain","mexico"),
  lentil      = c("usa","spain","mexico"),
  chickpea    = c("usa","spain","mexico")
)

breaks <- c(0, 0.1, 1, 5, 10, 50, 100, 500, 1000, 5000, 10000, Inf)
labels <- paste0(head(breaks, -1), "-", tail(breaks, -1))
colors_named <- c("none" = "grey90",
                  setNames(viridis(length(labels), option = "mako"), labels))

for (country in names(countries)) {
  country_shape  <- countries[[country]]
  shape_sf       <- st_as_sf(country_shape)
  country_crops  <- names(crop_country_map)[
    sapply(crop_country_map, function(x) country %in% x)]

  plot_list <- list()

  for (crop in country_crops) {
    r_path <- file.path(harvest_dir, glue("{country}_{crop}_harvested.tif"))
    if (!file.exists(r_path)) next

    r  <- rast(r_path)
    df <- as.data.frame(r, xy = TRUE, na.rm = TRUE)
    colnames(df)[3] <- "value"
    df$bin <- as.character(cut(df$value, breaks = breaks,
                               labels = labels, include.lowest = TRUE))
    df$bin[df$value == 0] <- "none"
    df$bin <- factor(df$bin, levels = c("none", labels))

    plot_list[[crop]] <- ggplot(df) +
      geom_tile(aes(x = x, y = y, fill = bin)) +
      geom_sf(data = shape_sf, fill = NA, color = "black", linewidth = 0.2) +
      coord_sf(expand = FALSE) +
      scale_fill_manual(values = colors_named, drop = FALSE,
                        na.translate = FALSE, name = "Harvested area (ha)") +
      labs(title = str_to_title(crop)) +
      theme_minimal(base_size = 10) +
      theme(legend.position    = "right",
            legend.key.height  = unit(0.35, "cm"),
            legend.text        = element_text(size = 6),
            legend.title       = element_text(size = 7),
            panel.grid         = element_line(color = "grey90", linewidth = 0.2),
            axis.text          = element_blank(),
            axis.title         = element_blank()) +
      guides(fill = guide_legend(ncol = 1))
  }

  if (length(plot_list) == 0) next

  panel <- wrap_plots(plot_list, ncol = 3) +
    plot_annotation(title = glue("Harvested crop areas: {toupper(country)}"))

  ggsave(file.path(fig_dir, glue("{country}_crop_panel.png")),
         plot = panel, width = 12, height = 8, dpi = 300)
}
