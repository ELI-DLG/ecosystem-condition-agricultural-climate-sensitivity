# Data cleaning: spatial data trimming for all countries and crops
# Trims CROPGRIDS harvest area, crop calendars, GlobalCropYield yield rasters,
# WorldClim bioclim (SSP scenarios), BII, and VHI to country boundaries.
#
# Countries: Spain (mainland + Balearics), UK, USA (contiguous),
#            Brazil, Kenya, Mexico, Indonesia
# Crops: wheat, barley, maize, rice, potato, pulses, soybean, rye,
#        cassava, yam, millet, bean, oats, sorghum, and others per country
#
# Inputs:
#   CROPGRIDS: FoodSecurity/CROPGRIDSv1.08_NC_maps/
#   Crop calendars: FoodSecurity/GlobalCropYield5min1982_2015_V4/Crop Calendar/
#   Yield rasters: FoodSecurity/GlobalCropYield5min1982_2015_V4/GlobalCropYield5min/
#   Bioclim SSP: Bioclim/2021-2040/370/ and /585/
#   BII: biodiversity/Biodiversity_Intact_Index.tiff
#   VHI: biodiversity/Vegetation_Health_Index.tiff
#   GADM shapefiles: basicshapes/gadm41_XXX_shp/
#
# Outputs:
#   HarvestedCropArea/   country_crop_harvested.tif
#   CropCalendarTrimmed/ country_crop_plant/harvest_month.tif
#   YieldTrimmed/crop/   country_crop_year.tif
#   BioclimTrimmed/ssp/  country_bio_N.tif
#   BII_trim/            country_bii_index.tif
#   VHI_trim/            country_vhi.tif

library(terra)
library(sf)
library(glue)
library(dplyr)

base_dir      <- "~/Documents/FoodSecurityV2"
cropgrid_dir  <- file.path(base_dir, "FoodSecurity/CROPGRIDSv1.08_NC_maps")
yield_dir     <- file.path(base_dir, "YieldTrimmed")
calendar_dir  <- file.path(base_dir, "FoodSecurity/GlobalCropYield5min1982_2015_V4/Crop Calendar")
shapefile_dir <- file.path(base_dir, "basicshapes")

harvest_out      <- file.path(base_dir, "HarvestedCropArea")
calendar_out     <- file.path(base_dir, "CropCalendarTrimmed")
bioclim_out      <- file.path(base_dir, "BioclimTrimmed")
biodiversity_out <- file.path(base_dir, "BII_trim")
vhi_out          <- file.path(base_dir, "VHI_trim")

for (d in c(harvest_out, calendar_out, yield_dir, bioclim_out, biodiversity_out, vhi_out))
  dir.create(d, recursive = TRUE, showWarnings = FALSE)

# Country shapes
# Spain: mainland + Balearics north of Gibraltar (centroid lat > 36.14)
tmp_sp0 <- vect(file.path(shapefile_dir, "gadm41_ESP_shp/gadm41_ESP_0.shp"))
tmp_sf  <- st_cast(st_as_sf(tmp_sp0), "POLYGON")
tmp_sf$lat <- st_coordinates(st_centroid(tmp_sf$geometry))[, 2]
spain   <- vect(st_union(tmp_sf[tmp_sf$lat > 36.14, ]$geometry))
crs(spain) <- crs(tmp_sp0)

# USA: contiguous states only
usa <- vect(file.path(shapefile_dir, "gadm41_USA_shp/gadm41_USA_1.shp"))
usa <- usa[!usa$NAME_1 %in% c("Alaska", "Hawaii"), ] |> aggregate()

countries <- list(
  spain     = spain,
  uk        = vect(file.path(shapefile_dir, "gadm41_GBR_shp/gadm41_GBR_0.shp")),
  usa       = usa,
  brazil    = vect(file.path(shapefile_dir, "gadm41_BRA_shp/gadm41_BRA_0.shp")),
  kenya     = vect(file.path(shapefile_dir, "gadm41_KEN_shp/gadm41_KEN_0.shp")),
  mexico    = vect(file.path(shapefile_dir, "gadm41_MEX_shp/gadm41_MEX_0.shp")),
  indonesia = vect(file.path(shapefile_dir, "gadm41_IDN_shp/gadm41_IDN_0.shp"))
)

crop_country_map <- list(
  maize       = c("usa","brazil","kenya","uk","spain","mexico","indonesia"),
  rice        = c("usa","brazil","kenya","spain","mexico","indonesia"),
  wheat       = c("usa","brazil","kenya","uk","spain","mexico"),
  soybean     = c("usa","brazil","kenya","mexico"),
  rye         = c("uk","usa","spain"),
  cassava     = c("brazil","kenya","indonesia"),
  potato      = c("usa","brazil","kenya","uk","spain","mexico","indonesia"),
  sweetpotato = c("usa","brazil","kenya","indonesia"),
  millet      = c("brazil","kenya"),
  bean        = c("usa","brazil","kenya","mexico"),
  barley      = c("usa","uk","spain","mexico"),
  oats        = c("usa","uk","spain"),
  sorghum     = c("usa","brazil","kenya"),
  pulses      = c("usa","brazil","kenya","spain","mexico"),
  lentil      = c("usa","spain","mexico"),
  chickpea    = c("usa","spain","mexico")
)

clean_crop_rast <- function(r) { r[r == -1] <- NA; r }

trim_crop_area <- function(crop, country, shape) {
  f <- file.path(cropgrid_dir, glue("CROPGRIDSv1.08_{crop}.nc"))
  if (!file.exists(f)) return(NULL)
  r <- clean_crop_rast(rast(f)$harvarea)
  crs(r) <- "EPSG:4326"
  shape  <- project(shape, crs(r))
  writeRaster(mask(crop(r, shape), shape),
              file.path(harvest_out, glue("{country}_{crop}_harvested.tif")),
              overwrite = TRUE)
}

trim_crop_calendar <- function(crop, country, shape) {
  plant   <- file.path(calendar_dir, tools::toTitleCase(crop), glue("{crop}_plant.tif"))
  harvest <- file.path(calendar_dir, tools::toTitleCase(crop), glue("{crop}_harvest.tif"))
  if (!file.exists(plant) || !file.exists(harvest)) return(NULL)
  rp <- rast(plant); rh <- rast(harvest)
  shape <- project(shape, crs(rp))
  writeRaster(mask(crop(rp, shape), shape),
              file.path(calendar_out, glue("{country}_{crop}_plant_month.tif")),  overwrite = TRUE)
  writeRaster(mask(crop(rh, shape), shape),
              file.path(calendar_out, glue("{country}_{crop}_harvest_month.tif")), overwrite = TRUE)
}

trim_yield <- function(crop, country, years, shape) {
  crop_dir <- file.path(base_dir, "FoodSecurity/GlobalCropYield5min1982_2015_V4/GlobalCropYield5min",
                        tools::toTitleCase(crop))
  out_dir  <- file.path(yield_dir, crop)
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  for (yr in years) {
    f <- list.files(crop_dir, pattern = glue("^{tools::toTitleCase(crop)}{yr}\.tif$"),
                   full.names = TRUE)
    if (!length(f)) next
    r <- rast(f); shape_p <- project(shape, crs(r))
    if (!relate(ext(r), ext(shape_p), "intersects")) next
    writeRaster(mask(crop(r, shape_p), shape_p),
                file.path(out_dir, glue("{country}_{crop}_{yr}.tif")), overwrite = TRUE)
  }
}

years_yield <- 2010:2015
for (crop in names(crop_country_map)) {
  for (country in crop_country_map[[crop]]) {
    shape <- countries[[country]]
    trim_crop_area(crop, country, shape)
    trim_crop_calendar(crop, country, shape)
    trim_yield(crop, country, years_yield, shape)
  }
}

# Bioclim SSP scenario trimming (with safe crop+mask for border polygons)
safe_crop_mask <- function(r, shp) {
  shp <- makeValid(shp)
  shp <- project(shp, crs(r))
  if (!relate(ext(r), ext(shp), "intersects")) return(NULL)
  rc <- suppressWarnings(crop(r, shp))
  if (is.null(rc)) return(NULL)
  rm <- suppressWarnings(mask(rc, shp, touches = TRUE))
  if (!is.null(rm) && !all(is.na(values(rm)))) return(rm)
  suppressWarnings(mask(rc, buffer(shp, 0.02), touches = TRUE))
}

for (scen in c("370", "585")) {
  in_dir <- file.path(base_dir, "Bioclim/2021-2040", scen)
  files  <- list.files(in_dir, pattern = "\.tif$", full.names = TRUE)
  if (!length(files)) next
  rstack  <- rast(files)
  out_dir <- file.path(bioclim_out, scen)
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  for (ct in names(countries)) {
    for (i in 1:nlyr(rstack)) {
      trimmed <- safe_crop_mask(rstack[[i]], countries[[ct]])
      if (is.null(trimmed) || all(is.na(values(trimmed)))) next
      writeRaster(trimmed, file.path(out_dir, glue("{ct}_bio_{i}.tif")), overwrite = TRUE)
    }
  }
}

# BII and VHI trimming
bii <- rast(file.path(base_dir, "biodiversity/Biodiversity_Intact_Index.tiff"))
vhi <- rast(file.path(base_dir, "biodiversity/Vegetation_Health_Index.tiff"))

for (ct in names(countries)) {
  shape_bii <- project(countries[[ct]], crs(bii))
  writeRaster(mask(crop(bii, shape_bii), shape_bii),
              file.path(biodiversity_out, glue("{ct}_bii_index.tif")), overwrite = TRUE)
  shape_vhi <- project(countries[[ct]], crs(vhi))
  writeRaster(mask(crop(vhi, shape_vhi), shape_vhi),
              file.path(vhi_out, glue("{ct}_vhi.tif")), overwrite = TRUE)
}