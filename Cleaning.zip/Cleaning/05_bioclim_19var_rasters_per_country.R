# Data cleaning: calculate all 19 WorldClim-style bioclim variables
# from TerraClimate monthly NetCDFs at global extent, then save per country.
# Covers BIO1-BIO19 including diurnal range (BIO2), isothermality (BIO3),
# and all quarterly variables.
#
# This is complementary to 01_bioclim_from_terraclimate.R which extracts
# regional (GADM polygon) averages. This script saves full rasters per country.
#
# Inputs:
#   TerraClimate NetCDFs: Bioclimate/THREDDS/TerraClimate_tmin_YYYY.nc etc.
#
# Outputs (in Bioclimate/TerraClimate_bioclim_annual/COUNTRY/):
#   bio1_YYYY_COUNTRY.tif through bio19_YYYY_COUNTRY.tif

library(terra)
library(dplyr)

terraOptions(progress = 0, memfrac = 0.6)

terraclimate_dir <- "~/Documents/FoodSecurityV2/Bioclimate/THREDDS"
output_dir       <- "~/Documents/FoodSecurityV2/Bioclimate/TerraClimate_bioclim_annual"
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)

years     <- 2000:2024
countries <- c("spain", "uk", "usa", "brazil", "indonesia", "kenya", "mexico")

# Compute all 19 bioclim variables from 12-month stacks.
# Quarter windows use rolling 3-month periods with December wrap-around.
# BIO8/9 are approximated as warmest/coldest quarter mean temperature.
# BIO18/19 are approximated as wettest/driest quarter precipitation.
calculate_bioclim_from_monthly <- function(tmin_stack, tmax_stack, ppt_stack) {
  tmean_stack    <- (tmin_stack + tmax_stack) / 2
  monthly_range  <- tmax_stack - tmin_stack

  bio1  <- mean(tmean_stack);       names(bio1)  <- "bio1"
  bio2  <- mean(monthly_range);     names(bio2)  <- "bio2"
  bio5  <- max(tmax_stack);         names(bio5)  <- "bio5"
  bio6  <- min(tmin_stack);         names(bio6)  <- "bio6"
  bio7  <- bio5 - bio6;             names(bio7)  <- "bio7"
  bio3  <- (bio2 / bio7) * 100;    names(bio3)  <- "bio3"
  bio4  <- stdev(tmean_stack) * 100; names(bio4) <- "bio4"
  bio12 <- sum(ppt_stack);          names(bio12) <- "bio12"
  bio13 <- max(ppt_stack);          names(bio13) <- "bio13"
  bio14 <- min(ppt_stack);          names(bio14) <- "bio14"
  bio15 <- (stdev(ppt_stack) / mean(ppt_stack)) * 100; names(bio15) <- "bio15"

  # Rolling 3-month quarters
  tmean_quarters <- ppt_quarters <- vector("list", 12)
  for (i in 1:12) {
    m1 <- i
    m2 <- if (i == 12) 1L else i + 1L
    m3 <- if (i >= 11) i - 10L else i + 2L
    tmean_quarters[[i]] <- mean(rast(c(tmean_stack[[m1]], tmean_stack[[m2]], tmean_stack[[m3]])))
    ppt_quarters[[i]]   <- sum( rast(c(ppt_stack[[m1]],   ppt_stack[[m2]],   ppt_stack[[m3]])))
  }

  tq_stack <- rast(tmean_quarters)
  pq_stack <- rast(ppt_quarters)

  bio10 <- max(tq_stack);  names(bio10) <- "bio10"
  bio11 <- min(tq_stack);  names(bio11) <- "bio11"
  bio8  <- bio10;          names(bio8)  <- "bio8"
  bio9  <- bio11;          names(bio9)  <- "bio9"
  bio16 <- max(pq_stack);  names(bio16) <- "bio16"
  bio17 <- min(pq_stack);  names(bio17) <- "bio17"
  bio18 <- bio16;          names(bio18) <- "bio18"
  bio19 <- bio17;          names(bio19) <- "bio19"

  c(bio1, bio2, bio3, bio4, bio5, bio6, bio7,
    bio8, bio9, bio10, bio11, bio12, bio13, bio14,
    bio15, bio16, bio17, bio18, bio19)
}

for (yr in years) {
  tmin_f <- file.path(terraclimate_dir, paste0("TerraClimate_tmin_", yr, ".nc"))
  tmax_f <- file.path(terraclimate_dir, paste0("TerraClimate_tmax_", yr, ".nc"))
  ppt_f  <- file.path(terraclimate_dir, paste0("TerraClimate_ppt_",  yr, ".nc"))

  if (!all(file.exists(c(tmin_f, tmax_f, ppt_f)))) next

  tmin_stack <- rast(tmin_f)
  tmax_stack <- rast(tmax_f)
  ppt_stack  <- rast(ppt_f)

  if (any(c(nlyr(tmin_stack), nlyr(tmax_stack), nlyr(ppt_stack)) != 12)) next

  bioclim_global <- tryCatch(
    calculate_bioclim_from_monthly(tmin_stack, tmax_stack, ppt_stack),
    error = function(e) { warning("Year ", yr, " failed: ", e$message); NULL }
  )
  if (is.null(bioclim_global)) next

  for (country in countries) {
    country_dir <- file.path(output_dir, country)
    dir.create(country_dir, showWarnings = FALSE, recursive = TRUE)
    for (i in 1:19) {
      writeRaster(bioclim_global[[i]],
                  file.path(country_dir, paste0("bio", i, "_", yr, "_", country, ".tif")),
                  overwrite = TRUE, gdal = c("COMPRESS=LZW"))
    }
  }
}
