# SCRIPT 1
# FOOD SECURITY MODELS + FUTURE PROJECTIONS + CHANGE / CLASS MAPS
# UK + SPAIN ONLY
# Uses:
#   - BioclimModels historical + future climate rasters
#   - GAEZ2015_Trimmed yields + harvest area
#   - AGB 2015 + AGB change
#   - non-NHM BII only
#   - Shannon + absolute crop diversity built from ALL available HarvestArea Total rasters
#   - UK custom subregions via GADM 1 + 2
#   - Spain regions via GADM 1
#
# Main outputs:
#   FINAL_RUN_SCRIPT1/
#     tables/
#     figures/
#     rasters/
#     models/

# 0. PACKAGES
pkgs <- c("terra", "sf", "dplyr", "ggplot2", "ranger", "pROC", "patchwork")
to_install <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
if (length(to_install) > 0) install.packages(to_install)

library(terra)
library(sf)
library(dplyr)
library(ggplot2)
library(ranger)
library(pROC)
library(patchwork)

theme_set(theme_minimal())

# 1. PATHS
base_dir <- "~/Documents/FoodSecurityV2"

bioclim_dir   <- file.path(base_dir, "BioclimModels")
gaez_dir      <- file.path(base_dir, "GAEZ2015_Trimmed")
agb_dir       <- file.path(base_dir, "Biodiversity", "AGB_Spatial")
bii_dir       <- file.path(base_dir, "Biodiversity", "BII_Spatial")
shapes_dir    <- file.path(base_dir, "basicshapes")
canvas_dir    <- file.path(base_dir, "WorkingData", "Canvas01_RealRasterAlignment_CropYields")
terraclim_dir <- file.path(base_dir, "Bioclimate", "TerraClimate_TIFFS")

out_root   <- file.path(base_dir, "FINAL_RUN_SCRIPT1")
dir_tables <- file.path(out_root, "tables")
dir_figs   <- file.path(out_root, "figures")
dir_rast   <- file.path(out_root, "rasters")
dir_mods   <- file.path(out_root, "models")

dir.create(out_root, recursive = TRUE, showWarnings = FALSE)
dir.create(dir_tables, recursive = TRUE, showWarnings = FALSE)
dir.create(dir_figs, recursive = TRUE, showWarnings = FALSE)
dir.create(dir_rast, recursive = TRUE, showWarnings = FALSE)
dir.create(dir_mods, recursive = TRUE, showWarnings = FALSE)

# 2. SETTINGS
countries <- c("GBR", "ESP")

future_scenarios <- c(
  "245_2021-2040",
  "245_2041-2060",
  "370_2021-2040",
  "370_2041-2060"
)

present_scenario <- "historical"

# Focus crops
focus_crops <- list(
  GBR = c("Wheat", "Barley", "PotatoAndSweetpotato"),
  ESP = c("Wheat", "Barley", "PotatoAndSweetpotato", "Maize", "Pulses", "Rice")
)

# Outcomes
outcomes <- c("harvestable", "high_yield")

# Ecosystem scenarios
ecoscen <- list(
  depleted = list(agb = 0.75, shannon = 0.75, richness = 0.85, bii = 0.75),
  status_quo = list(agb = 1.00, shannon = 1.00, richness = 1.00, bii = 1.00),
  increased_agb_shannon = list(agb = 1.25, shannon = 1.25, richness = 1.15, bii = 1.00),
  restoration_focused = list(agb = 1.25, shannon = 1.25, richness = 1.15, bii = 1.15)
)

# Climate vars to use where available in ALL folders
candidate_clim_vars <- c(
  "bio1", "bio4", "bio5", "bio6", "bio7",
  "bio12", "bio15", "bio18", "bio19",
  "pr", "tn", "tx"
)

# Crop-specific extreme heat thresholds for post-model physiological penalty
# soft = start penalising, hard = no-go
heat_limits <- list(
  Wheat = c(soft = 32, hard = 38),
  Barley = c(soft = 30, hard = 36),
  PotatoAndSweetpotato = c(soft = 28, hard = 34),
  Maize = c(soft = 35, hard = 41),
  Pulses = c(soft = 32, hard = 38),
  Rice = c(soft = 35, hard = 40)
)

pretty_var <- c(
  bio1 = "Annual mean temperature (bio1)",
  bio4 = "Temperature seasonality (bio4)",
  bio5 = "Warmest month temperature (bio5)",
  bio6 = "Coldest month temperature (bio6)",
  bio7 = "Annual temperature range (bio7)",
  bio12 = "Annual precipitation (bio12)",
  bio15 = "Precipitation seasonality (bio15)",
  bio18 = "Warmest quarter precipitation (bio18)",
  bio19 = "Coldest quarter precipitation (bio19)",
  pr = "Projected precipitation (pr)",
  tn = "Projected minimum temperature (tn)",
  tx = "Projected maximum temperature (tx)",
  agb = "Aboveground biomass (AGB)",
  agb_neigh = "Neighbourhood AGB",
  agb_delta = "AGB change 2010-2015",
  bii = "Biodiversity intactness (BII)",
  shannon = "Shannon crop diversity",
  richness = "Absolute crop diversity"
)

crop_labels <- c(
  Wheat = "Wheat",
  Barley = "Barley",
  PotatoAndSweetpotato = "Potatoes",
  Maize = "Maize",
  Pulses = "Pulses",
  Rice = "Rice"
)

# 3. HELPERS
safe_scale01 <- function(r) {
  r <- rast(r)
  mm <- global(r, c("min", "max"), na.rm = TRUE)
  minv <- mm[1, 1]
  maxv <- mm[2, 1]
  if (!is.finite(minv) || !is.finite(maxv) || abs(maxv - minv) < 1e-12) {
    out <- r
    values(out) <- 0
    return(out)
  }
  (r - minv) / (maxv - minv)
}

align_to_template <- function(x, template, method = "bilinear") {
  if (inherits(x, "SpatRaster")) {
    r <- x
  } else {
    r <- rast(x)
  }
  
  if (!same.crs(r, template)) {
    r <- project(r, template, method = method)
  }
  
  if (!compareGeom(r, template, stopOnError = FALSE, crs = TRUE, ext = TRUE, rowcol = TRUE, res = TRUE)) {
    r <- resample(r, template, method = method)
  }
  
  r <- crop(r, template, snap = "out")
  r
}

rast_to_df <- function(r, value_name = "value", na_rm = TRUE) {
  df <- as.data.frame(r, xy = TRUE, na.rm = na_rm)
  if (nrow(df) == 0) return(data.frame())
  val_col <- setdiff(names(df), c("x", "y"))[1]
  names(df)[names(df) == val_col] <- value_name
  df
}

mask_to_region <- function(r, region_sf) {
  region_v <- vect(region_sf)
  rr <- crop(r, region_v)
  rr <- mask(rr, region_v)
  rr
}

extract_region_mean <- function(r, region_sf) {
  rr <- mask_to_region(r, region_sf)
  val <- global(rr, "mean", na.rm = TRUE)[1, 1]
  as.numeric(val)
}

extract_region_sd <- function(r, region_sf) {
  vals <- values(mask_to_region(r, region_sf))
  vals <- vals[is.finite(vals)]
  if (length(vals) == 0) return(NA_real_)
  sd(vals)
}

predict_ranger_prob <- function(model, data) {
  p <- predict(model, data = data)$predictions
  if (is.matrix(p)) {
    if ("1" %in% colnames(p)) return(p[, "1"])
    return(p[, ncol(p)])
  }
  as.numeric(p)
}

terra_predict_ranger <- function(pred_stack, model) {
  terra::predict(
    pred_stack,
    model,
    fun = function(mod, dat) predict_ranger_prob(mod, dat),
    na.rm = TRUE
  )
}

infer_temp_multiplier <- function(r) {
  m <- global(abs(r), "mean", na.rm = TRUE)[1, 1]
  if (is.na(m)) return(1)
  if (m > 80) return(10) else return(1)
}

make_heat_penalty <- function(tx_r, bio5_r, agb_neigh_r, crop_name) {
  lim <- heat_limits[[crop_name]]
  mult_tx <- infer_temp_multiplier(tx_r)
  mult_b5 <- infer_temp_multiplier(bio5_r)
  
  tx_adj <- tx_r - (1.5 * mult_tx * safe_scale01(agb_neigh_r))
  b5_adj <- bio5_r - (1.5 * mult_b5 * safe_scale01(agb_neigh_r))
  
  penalty_fun <- function(r, soft, hard) {
    out <- r
    values(out) <- 1
    out[r >= soft & r < hard] <- 1 - ((r[r >= soft & r < hard] - soft) / (hard - soft))
    out[r >= hard] <- 0
    out
  }
  
  p_tx <- penalty_fun(tx_adj, lim["soft"] * mult_tx, lim["hard"] * mult_tx)
  p_b5 <- penalty_fun(b5_adj, lim["soft"] * mult_b5, lim["hard"] * mult_b5)
  
  pmin(p_tx, p_b5)
}

build_class_map <- function(dP_low, dP_high) {
  mod <- dP_high - dP_low
  cls <- dP_low
  vals <- rep(NA_integer_, ncell(cls))
  
  low_vals <- values(dP_low)
  mod_vals <- values(mod)
  
  ok <- is.finite(low_vals) & is.finite(mod_vals)
  
  vals[ok & low_vals < 0 & mod_vals > 0]  <- 1L  # reduces loss
  vals[ok & low_vals < 0 & mod_vals <= 0] <- 2L  # increases loss
  vals[ok & low_vals >= 0 & mod_vals > 0] <- 3L  # increases gains
  vals[ok & low_vals >= 0 & mod_vals <= 0] <- 4L # reduces gains
  
  values(cls) <- vals
  cls
}

save_single_raster_plot <- function(r, outfile, title, midpoint = NULL) {
  df <- rast_to_df(r, value_name = "value", na_rm = FALSE)
  if (nrow(df) == 0) return(invisible(NULL))
  
  p <- ggplot(df, aes(x = x, y = y, fill = value)) +
    geom_raster() +
    coord_equal() +
    theme_void() +
    labs(title = title, fill = NULL)
  
  if (is.null(midpoint)) {
    p <- p + scale_fill_viridis_c(na.value = "grey92")
  } else {
    p <- p + scale_fill_gradient2(
      low = "#B2182B",
      mid = "white",
      high = "#2166AC",
      midpoint = midpoint,
      na.value = "grey92"
    )
  }
  
  ggsave(outfile, p, width = 7, height = 5.5, dpi = 300)
}

save_class_raster_plot <- function(r, outfile, title) {
  df <- rast_to_df(r, value_name = "class_id", na_rm = TRUE)
  if (nrow(df) == 0) return(invisible(NULL))
  
  df$class <- factor(
    df$class_id,
    levels = c(1, 2, 3, 4),
    labels = c(
      "High ecosystem reduces loss",
      "High ecosystem increases loss",
      "High ecosystem increases gains",
      "High ecosystem reduces gains"
    )
  )
  
  p <- ggplot(df, aes(x = x, y = y, fill = class)) +
    geom_raster() +
    coord_equal() +
    theme_void() +
    labs(title = title, fill = NULL)
  
  ggsave(outfile, p, width = 7, height = 5.5, dpi = 300)
}

# 4. LOAD SHAPES + BUILD REGIONS
gbr0 <- st_read(file.path(shapes_dir, "gadm41_GBR_shp", "gadm41_GBR_0.shp"), quiet = TRUE)
gbr1 <- st_read(file.path(shapes_dir, "gadm41_GBR_shp", "gadm41_GBR_1.shp"), quiet = TRUE)
gbr2 <- st_read(file.path(shapes_dir, "gadm41_GBR_shp", "gadm41_GBR_2.shp"), quiet = TRUE)

esp0 <- st_read(file.path(shapes_dir, "gadm41_ESP_shp", "gadm41_ESP_0.shp"), quiet = TRUE)
esp1 <- st_read(file.path(shapes_dir, "gadm41_ESP_shp", "gadm41_ESP_1.shp"), quiet = TRUE)

# Templates from your aligned stacks
template_gbr <- rast(file.path(canvas_dir, "uk_aligned_stack_21layers.tif"))[[1]]
template_esp <- rast(file.path(canvas_dir, "spain_aligned_stack_23layers.tif"))[[1]]

# Transform shapes to template CRS
gbr0 <- st_transform(gbr0, crs(template_gbr))
gbr1 <- st_transform(gbr1, crs(template_gbr))
gbr2 <- st_transform(gbr2, crs(template_gbr))

esp0 <- st_transform(esp0, crs(template_esp))
esp1 <- st_transform(esp1, crs(template_esp))

# National masks constrained to the mainland template extent
gbr_extent_poly <- st_as_sf(as.polygons(ext(template_gbr), crs = crs(template_gbr)))
esp_extent_poly <- st_as_sf(as.polygons(ext(template_esp), crs = crs(template_esp)))

gbr_national <- suppressWarnings(st_intersection(gbr0, gbr_extent_poly))
gbr_national$region <- "national"

# Spain mainland only, no Canarias / Ceuta / Melilla
esp1_main <- esp1 %>%
  filter(!NAME_1 %in% c("Canarias", "Ceuta", "Melilla", "Ceuta y Melilla"))
esp_national <- suppressWarnings(st_intersection(st_union(esp1_main), esp_extent_poly)) %>%
  st_as_sf()
esp_national$region <- "national"

# UK custom regions
make_gbr_regions <- function(gbr1, gbr2) {
  nm1 <- tolower(gbr1$NAME_1)
  nm2 <- tolower(gbr2$NAME_2)
  
  scotland <- gbr1[grepl("scotland", nm1), ]
  
  if (any(grepl("yorkshire", nm1))) {
    yorks <- gbr1[grepl("yorkshire", nm1), ]
  } else {
    yorks <- gbr2[
      grepl("north yorkshire|west yorkshire|south yorkshire|east riding|hull|humber", nm2),
    ]
    yorks <- st_as_sf(st_union(yorks))
  }
  
  sussex <- gbr2[
    grepl("east sussex|west sussex|brighton", nm2),
  ]
  sussex <- st_as_sf(st_union(sussex))
  
  east_anglia <- gbr2[
    grepl("norfolk|suffolk|cambridgeshire", nm2),
  ]
  east_anglia <- st_as_sf(st_union(east_anglia))
  
  out <- bind_rows(
    yorks %>% st_as_sf() %>% mutate(region = "Yorkshire and Humberside"),
    sussex %>% st_as_sf() %>% mutate(region = "Sussex"),
    east_anglia %>% st_as_sf() %>% mutate(region = "East Anglia"),
    scotland %>% st_as_sf() %>% mutate(region = "Scotland")
  ) %>%
    select(region)
  
  out
}

make_esp_regions <- function(esp1) {
  wanted <- c(
    "Castilla-La Mancha",
    "Castilla y León",
    "Extremadura",
    "Cataluña",
    "Andalucía"
  )
  
  out <- esp1 %>%
    filter(NAME_1 %in% wanted) %>%
    mutate(region = NAME_1) %>%
    select(region)
  
  out
}

regions_gbr <- bind_rows(gbr_national, make_gbr_regions(gbr1, gbr2))
regions_esp <- bind_rows(esp_national, make_esp_regions(esp1_main))

# 5. BUILD SHANNON + ABSOLUTE CROP DIVERSITY FROM ALL AVAILABLE GAEZ HARVESTAREA
build_diversity_layers <- function(country, template) {
  harvest_path <- file.path(
    gaez_dir,
    ifelse(country == "GBR", "UK", "Spain"),
    "HarvestArea"
  )
  
  total_files <- list.files(harvest_path, pattern = "_Total\\.tif$", full.names = TRUE)
  if (length(total_files) == 0) stop("No HarvestArea *_Total.tif files found for ", country)
  
  total_stack <- rast(lapply(total_files, function(f) align_to_template(f, template, method = "bilinear")))
  names(total_stack) <- tools::file_path_sans_ext(basename(total_files))
  
  total_sum <- app(total_stack, sum, na.rm = TRUE)
  
  shannon <- lapp(c(total_stack, total_sum), fun = function(...) {
    x <- c(...)
    total <- x[length(x)]
    vals <- x[-length(x)]
    vals[is.na(vals)] <- 0
    if (!is.finite(total) || total <= 0) return(NA)
    p <- vals / total
    p <- p[p > 0]
    -sum(p * log(p))
  })
  
  richness <- app(total_stack, fun = function(x) sum(x > 0, na.rm = TRUE))
  
  list(
    shannon = safe_scale01(shannon),
    richness = safe_scale01(richness)
  )
}

# 6. LOAD STATIC ECOSYSTEM LAYERS
load_static_layers <- function(country, template) {
  ckey <- ifelse(country == "GBR", "uk", "spain")
  
  # AGB
  agb_2015_file <- list.files(
    file.path(agb_dir, ckey),
    pattern = "AGB_2015_.*ALIGNED_TO_CANVAS01\\.tif$",
    full.names = TRUE
  )[1]
  
  agb_delta_file <- list.files(
    file.path(agb_dir, ckey),
    pattern = "AGB_2015minus2010_.*ALIGNED_TO_CANVAS01\\.tif$",
    full.names = TRUE
  )[1]
  
  if (!file.exists(agb_2015_file)) stop("Missing AGB 2015 aligned file for ", country)
  if (!file.exists(agb_delta_file)) stop("Missing AGB delta aligned file for ", country)
  
  agb <- align_to_template(agb_2015_file, template, method = "bilinear")
  agb_delta <- align_to_template(agb_delta_file, template, method = "bilinear")
  agb_neigh <- focal(agb, w = matrix(1, 7, 7), fun = mean, na.rm = TRUE, fillvalue = NA)
  
  # BII non-NHM only
  bii_file <- file.path(bii_dir, ckey, paste0("bii_", ckey, "_2015.tif"))
  if (!file.exists(bii_file)) stop("Missing non-NHM BII 2015 file for ", country)
  bii <- align_to_template(bii_file, template, method = "bilinear")
  
  # Diversity from ALL available crops
  divs <- build_diversity_layers(country, template)
  
  list(
    agb = safe_scale01(agb),
    agb_delta = safe_scale01(agb_delta),
    agb_neigh = safe_scale01(agb_neigh),
    bii = safe_scale01(bii),
    shannon = divs$shannon,
    richness = divs$richness
  )
}

# 7. CLIMATE LOADERS
get_available_climate_vars <- function(country) {
  scen_dirs <- c(present_scenario, future_scenarios)
  
  avail_list <- lapply(scen_dirs, function(sc) {
    sdir <- file.path(bioclim_dir, country, sc)
    files <- list.files(sdir, pattern = "\\.tif$", full.names = FALSE)
    vars <- tools::file_path_sans_ext(files)
    vars <- vars[vars %in% candidate_clim_vars]
    vars
  })
  
  Reduce(intersect, avail_list)
}

load_climate_stack <- function(country, scenario, template, vars_to_use) {
  sdir <- file.path(bioclim_dir, country, scenario)
  
  rasters <- lapply(vars_to_use, function(v) {
    f <- file.path(sdir, paste0(v, ".tif"))
    if (!file.exists(f)) stop("Missing climate raster: ", f)
    align_to_template(f, template, method = "bilinear")
  })
  
  out <- rast(rasters)
  names(out) <- vars_to_use
  out
}

# 8. STATIC SCENARIO SCALING
make_static_predictors <- function(static_layers, eco_name) {
  s <- ecoscen[[eco_name]]
  
  agb <- static_layers$agb * s$agb
  agb[agb > 1] <- 1
  
  agb_neigh <- static_layers$agb_neigh * s$agb
  agb_neigh[agb_neigh > 1] <- 1
  
  agb_delta <- static_layers$agb_delta * s$agb
  agb_delta[agb_delta > 1] <- 1
  
  shannon <- static_layers$shannon * s$shannon
  shannon[shannon > 1] <- 1
  
  richness <- static_layers$richness * s$richness
  richness[richness > 1] <- 1
  
  bii <- static_layers$bii * s$bii
  bii[bii > 1] <- 1
  
  out <- c(agb, agb_neigh, agb_delta, bii, shannon, richness)
  names(out) <- c("agb", "agb_neigh", "agb_delta", "bii", "shannon", "richness")
  out
}

# 9. YIELD LOADERS + RESPONSES
yield_file_for <- function(country, crop, system) {
  ydir <- file.path(
    gaez_dir,
    ifelse(country == "GBR", "UK", "Spain"),
    "Yields"
  )
  suffix <- ifelse(system == "irr", "Irrigated", "Rainfed")
  file.path(ydir, paste0(crop, "_", suffix, ".tif"))
}

available_systems_for_crop <- function(country, crop) {
  out <- c()
  if (file.exists(yield_file_for(country, crop, "irr"))) out <- c(out, "irr")
  if (file.exists(yield_file_for(country, crop, "rf"))) out <- c(out, "rf")
  out
}

load_yield_raster <- function(country, crop, system, template) {
  f <- yield_file_for(country, crop, system)
  if (!file.exists(f)) return(NULL)
  align_to_template(f, template, method = "bilinear")
}

make_binary_response <- function(yield_r, outcome) {
  vals <- values(yield_r)
  vals[!is.finite(vals)] <- NA
  
  resp <- yield_r
  
  if (outcome == "harvestable") {
    values(resp) <- ifelse(is.na(vals), NA, ifelse(vals > 0, 1, 0))
  }
  
  if (outcome == "high_yield") {
    pos <- vals[is.finite(vals) & vals > 0]
    if (length(pos) < 50) {
      values(resp) <- NA
    } else {
      thr <- as.numeric(quantile(pos, 0.75, na.rm = TRUE))
      values(resp) <- ifelse(is.na(vals), NA, ifelse(vals >= thr, 1, 0))
    }
  }
  
  resp
}

# 10. MODEL FITTING
fit_one_model <- function(country, crop, system, outcome, template, regions_sf) {
  
  clim_vars <- get_available_climate_vars(country)
  if (length(clim_vars) < 5) stop("Too few common climate vars for ", country)
  
  static_layers <- load_static_layers(country, template)
  clim_present <- load_climate_stack(country, present_scenario, template, clim_vars)
  static_present <- make_static_predictors(static_layers, "status_quo")
  
  pred_stack <- c(clim_present, static_present)
  
  yld <- load_yield_raster(country, crop, system, template)
  if (is.null(yld)) return(NULL)
  
  resp_r <- make_binary_response(yld, outcome)
  df <- as.data.frame(c(pred_stack, resp_r), na.rm = FALSE)
  names(df)[ncol(df)] <- "resp"
  
  df <- df %>%
    filter(complete.cases(.)) %>%
    filter(resp %in% c(0, 1))
  
  if (nrow(df) < 1000) {
    return(NULL)
  }
  
  if (length(unique(df$resp)) < 2) {
    return(NULL)
  }
  
  set.seed(42)
  if (nrow(df) > 60000) df <- df[sample(seq_len(nrow(df)), 60000), , drop = FALSE]
  
  idx <- sample(seq_len(nrow(df)), size = floor(0.7 * nrow(df)))
  train <- df[idx, , drop = FALSE]
  test  <- df[-idx, , drop = FALSE]
  
  mod <- ranger(
    resp ~ .,
    data = train,
    probability = TRUE,
    num.trees = 500,
    importance = "permutation",
    seed = 42
  )
  
  p_test <- predict_ranger_prob(mod, test)
  auc_val <- tryCatch(
    as.numeric(pROC::auc(test$resp, p_test)),
    error = function(e) NA_real_
  )
  
  imp <- sort(mod$variable.importance, decreasing = TRUE)
  imp_df <- data.frame(
    variable = names(imp),
    importance = as.numeric(imp),
    country = country,
    crop = crop,
    system = system,
    outcome = outcome,
    stringsAsFactors = FALSE
  )
  
  saveRDS(
    mod,
    file.path(dir_mods, paste0("model_", country, "_", crop, "_", system, "_", outcome, ".rds"))
  )
  
  write.csv(
    imp_df,
    file.path(dir_tables, paste0("importance_", country, "_", crop, "_", system, "_", outcome, ".csv")),
    row.names = FALSE
  )
  
  # Current prediction under status quo
  present_pred <- terra_predict_ranger(pred_stack, mod)
  names(present_pred) <- "prob"
  
  list(
    model = mod,
    present_pred = present_pred,
    clim_vars = clim_vars,
    static_layers = static_layers,
    auc = auc_val,
    importance = imp_df
  )
}

# 11. PDP / RESPONSE CURVES
make_pdp_df <- function(model, train_like_df, varname, n = 60) {
  x <- train_like_df[[varname]]
  x <- x[is.finite(x)]
  if (length(x) < 10) return(NULL)
  
  grid <- seq(quantile(x, 0.02), quantile(x, 0.98), length.out = n)
  
  others <- train_like_df[, setdiff(names(train_like_df), c("resp", varname)), drop = FALSE]
  base_row <- as.data.frame(lapply(others, function(v) median(v, na.rm = TRUE)))
  newdat <- base_row[rep(1, n), , drop = FALSE]
  newdat[[varname]] <- grid
  
  # reorder
  target_names <- setdiff(names(train_like_df), "resp")
  newdat <- newdat[, target_names, drop = FALSE]
  
  preds <- predict_ranger_prob(model, newdat)
  
  data.frame(
    x = grid,
    y = preds,
    variable = varname,
    stringsAsFactors = FALSE
  )
}

save_response_curves <- function(country, crop, system, outcome, model_obj, template) {
  clim_present <- load_climate_stack(country, present_scenario, template, model_obj$clim_vars)
  static_present <- make_static_predictors(model_obj$static_layers, "status_quo")
  pred_stack <- c(clim_present, static_present)
  
  df <- as.data.frame(pred_stack, na.rm = TRUE)
  if (nrow(df) > 20000) df <- df[sample(seq_len(nrow(df)), 20000), , drop = FALSE]
  
  imp_top <- model_obj$importance %>%
    arrange(desc(importance)) %>%
    slice_head(n = 6) %>%
    pull(variable)
  
  pdp_list <- lapply(imp_top, function(v) make_pdp_df(model_obj$model, cbind(df, resp = 0), v))
  pdp_list <- pdp_list[!vapply(pdp_list, is.null, logical(1))]
  if (length(pdp_list) == 0) return(invisible(NULL))
  
  pdp_df <- bind_rows(pdp_list)
  pdp_df$pretty <- ifelse(pdp_df$variable %in% names(pretty_var), pretty_var[pdp_df$variable], pdp_df$variable)
  
  p <- ggplot(pdp_df, aes(x = x, y = y)) +
    geom_line(linewidth = 0.8) +
    facet_wrap(~ pretty, scales = "free_x") +
    labs(
      title = paste(country, crop_labels[[crop]], system, outcome, "- response curves"),
      x = NULL,
      y = "Predicted probability"
    ) +
    theme_minimal()
  
  ggsave(
    file.path(dir_figs, paste0("response_curves_", country, "_", crop, "_", system, "_", outcome, ".png")),
    p,
    width = 12,
    height = 8,
    dpi = 300
  )
}

# 12. FIT ALL MODELS
fitted <- list()
auc_rows <- list()
auc_i <- 1

for (country in countries) {
  template <- if (country == "GBR") template_gbr else template_esp
  
  for (crop in focus_crops[[country]]) {
    systems_here <- available_systems_for_crop(country, crop)
    if (length(systems_here) == 0) next
    
    for (system in systems_here) {
      for (outcome in outcomes) {
        fit_obj <- fit_one_model(
          country = country,
          crop = crop,
          system = system,
          outcome = outcome,
          template = template,
          regions_sf = if (country == "GBR") regions_gbr else regions_esp
        )
        
        if (is.null(fit_obj)) next
        
        key <- paste(country, crop, system, outcome, sep = "__")
        fitted[[key]] <- fit_obj
        
        auc_rows[[auc_i]] <- data.frame(
          country = country,
          crop = crop,
          system = system,
          outcome = outcome,
          auc = fit_obj$auc,
          stringsAsFactors = FALSE
        )
        auc_i <- auc_i + 1
        
        save_response_curves(country, crop, system, outcome, fit_obj, template)
      }
    }
  }
}

auc_table <- bind_rows(auc_rows)
write.csv(auc_table, file.path(dir_tables, "model_auc_summary.csv"), row.names = FALSE)

# 13. PRESENT + FUTURE PREDICTIONS
summary_rows <- list()
sr_i <- 1

predict_for_case <- function(country, crop, system, outcome, fit_obj, scenario, eco_name, template, national_sf) {
  clim <- load_climate_stack(country, scenario, template, fit_obj$clim_vars)
  static_scaled <- make_static_predictors(fit_obj$static_layers, eco_name)
  
  pred_stack <- c(clim, static_scaled)
  names(pred_stack) <- c(names(clim), names(static_scaled))
  
  pr <- terra_predict_ranger(pred_stack, fit_obj$model)
  names(pr) <- "prob_raw"
  
  # physiological heat penalty
  if (all(c("tx", "bio5") %in% names(clim))) {
    pen <- make_heat_penalty(clim[["tx"]], clim[["bio5"]], static_scaled[["agb_neigh"]], crop)
    pr <- pr * pen
  }
  
  pr <- mask_to_region(pr, national_sf)
  names(pr) <- "prob"
  pr
}

for (country in countries) {
  
  template <- if (country == "GBR") template_gbr else template_esp
  regions_sf <- if (country == "GBR") regions_gbr else regions_esp
  national_sf <- regions_sf %>% filter(region == "national")
  
  keys_country <- names(fitted)[grepl(paste0("^", country, "__"), names(fitted))]
  
  for (key in keys_country) {
    parts <- strsplit(key, "__", fixed = TRUE)[[1]]
    crop <- parts[2]
    system <- parts[3]
    outcome <- parts[4]
    
    fit_obj <- fitted[[key]]
    
    # present predictions under all ecosystem scenarios
    present_preds <- list()
    for (eco_name in names(ecoscen)) {
      pr_present <- predict_for_case(
        country = country,
        crop = crop,
        system = system,
        outcome = outcome,
        fit_obj = fit_obj,
        scenario = present_scenario,
        eco_name = eco_name,
        template = template,
        national_sf = national_sf
      )
      
      present_preds[[eco_name]] <- pr_present
      
      writeRaster(
        pr_present,
        file.path(dir_rast, paste0("present_", country, "_", crop, "_", system, "_", outcome, "_", eco_name, ".tif")),
        overwrite = TRUE
      )
    }
    
    for (future_sc in future_scenarios) {
      
      future_preds <- list()
      
      for (eco_name in names(ecoscen)) {
        pr_future <- predict_for_case(
          country = country,
          crop = crop,
          system = system,
          outcome = outcome,
          fit_obj = fit_obj,
          scenario = future_sc,
          eco_name = eco_name,
          template = template,
          national_sf = national_sf
        )
        
        future_preds[[eco_name]] <- pr_future
        
        out_future <- file.path(
          dir_rast,
          paste0("future_", country, "_", crop, "_", system, "_", outcome, "_", future_sc, "_", eco_name, ".tif")
        )
        writeRaster(pr_future, out_future, overwrite = TRUE)
        
        delta <- pr_future - present_preds[[eco_name]]
        out_delta <- file.path(
          dir_rast,
          paste0("delta_from_present_", country, "_", crop, "_", system, "_", outcome, "_", future_sc, "_", eco_name, ".tif")
        )
        writeRaster(delta, out_delta, overwrite = TRUE)
        
        # summaries: national + subregions
        for (rr in seq_len(nrow(regions_sf))) {
          reg <- regions_sf[rr, ]
          reg_name <- reg$region[1]
          
          summary_rows[[sr_i]] <- data.frame(
            country = country,
            crop = crop,
            system = system,
            outcome = outcome,
            future = future_sc,
            ecosystem = eco_name,
            region = reg_name,
            present_mean = extract_region_mean(present_preds[[eco_name]], reg),
            future_mean = extract_region_mean(pr_future, reg),
            mean_delta = extract_region_mean(delta, reg),
            delta_sd = extract_region_sd(delta, reg),
            stringsAsFactors = FALSE
          )
          sr_i <- sr_i + 1
        }
      }
      
      # analogue of your old BII modulation maps, but now using full ecosystem contrast
      dP_low  <- future_preds[["depleted"]] - present_preds[["depleted"]]
      dP_high <- future_preds[["restoration_focused"]] - present_preds[["restoration_focused"]]
      
      modulation <- dP_high - dP_low
      names(modulation) <- "modulation"
      
      cls <- build_class_map(dP_low, dP_high)
      names(cls) <- "class_id"
      
      writeRaster(
        modulation,
        file.path(dir_rast, paste0("ecosystem_modulation_", country, "_", crop, "_", system, "_", outcome, "_", future_sc, ".tif")),
        overwrite = TRUE
      )
      
      writeRaster(
        cls,
        file.path(dir_rast, paste0("ecosystem_effect_class_", country, "_", crop, "_", system, "_", outcome, "_", future_sc, ".tif")),
        overwrite = TRUE
      )
      
      save_single_raster_plot(
        modulation,
        outfile = file.path(dir_figs, paste0("ecosystem_modulation_", country, "_", crop, "_", system, "_", outcome, "_", future_sc, ".png")),
        title = paste(country, crop_labels[[crop]], system, outcome, future_sc, "- ecosystem modulation"),
        midpoint = 0
      )
      
      save_class_raster_plot(
        cls,
        outfile = file.path(dir_figs, paste0("ecosystem_effect_class_", country, "_", crop, "_", system, "_", outcome, "_", future_sc, ".png")),
        title = paste(country, crop_labels[[crop]], system, outcome, future_sc, "- ecosystem effect class")
      )
    }
  }
}

summary_table <- bind_rows(summary_rows)
write.csv(summary_table, file.path(dir_tables, "future_suitability_summary.csv"), row.names = FALSE)

# 14. CHANGE-FOCUSED PANEL FIGURES
make_change_panel <- function(country, crop, system, outcome) {
  files <- list.files(
    dir_rast,
    pattern = paste0("^delta_from_present_", country, "_", crop, "_", system, "_", outcome, "_.*\\.tif$"),
    full.names = TRUE
  )
  if (length(files) == 0) return(invisible(NULL))
  
  dfs <- lapply(files, function(f) {
    nm <- tools::file_path_sans_ext(basename(f))
    bits <- strsplit(nm, "_", fixed = TRUE)[[1]]
    
    # delta_from_present COUNTRY CROP SYSTEM OUTCOME FUTURESCEN ECO...
    future_i <- paste(bits[8], bits[9], sep = "_")
    eco_i <- paste(bits[10:length(bits)], collapse = "_")
    
    rr <- rast(f)
    df <- rast_to_df(rr, value_name = "delta", na_rm = FALSE)
    if (nrow(df) == 0) return(NULL)
    df$future <- future_i
    df$ecosystem <- eco_i
    df
  })
  
  dfs <- dfs[!vapply(dfs, is.null, logical(1))]
  if (length(dfs) == 0) return(invisible(NULL))
  
  df <- bind_rows(dfs)
  
  p <- ggplot(df, aes(x = x, y = y, fill = delta)) +
    geom_raster() +
    coord_equal() +
    facet_grid(ecosystem ~ future) +
    theme_void() +
    labs(
      title = paste(country, crop_labels[[crop]], system, outcome, "- change from present"),
      fill = "Δ suitability"
    ) +
    scale_fill_gradient2(
      low = "#B2182B",
      mid = "white",
      high = "#2166AC",
      midpoint = 0,
      na.value = "grey92"
    )
  
  ggsave(
    file.path(dir_figs, paste0("panel_delta_", country, "_", crop, "_", system, "_", outcome, ".png")),
    p,
    width = 14,
    height = 10,
    dpi = 300
  )
}

make_class_panel <- function(country, crop, system, outcome) {
  files <- list.files(
    dir_rast,
    pattern = paste0("^ecosystem_effect_class_", country, "_", crop, "_", system, "_", outcome, "_.*\\.tif$"),
    full.names = TRUE
  )
  if (length(files) == 0) return(invisible(NULL))
  
  dfs <- lapply(files, function(f) {
    nm <- tools::file_path_sans_ext(basename(f))
    bits <- strsplit(nm, "_", fixed = TRUE)[[1]]
    
    # ecosystem_effect_class COUNTRY CROP SYSTEM OUTCOME FUTURESCEN
    future_i <- paste(bits[8], bits[9], sep = "_")
    
    rr <- rast(f)
    df <- rast_to_df(rr, value_name = "class_id", na_rm = TRUE)
    if (nrow(df) == 0) return(NULL)
    
    df$future <- future_i
    df$class <- factor(
      df$class_id,
      levels = c(1, 2, 3, 4),
      labels = c(
        "High ecosystem reduces loss",
        "High ecosystem increases loss",
        "High ecosystem increases gains",
        "High ecosystem reduces gains"
      )
    )
    df
  })
  
  dfs <- dfs[!vapply(dfs, is.null, logical(1))]
  if (length(dfs) == 0) return(invisible(NULL))
  
  df <- bind_rows(dfs)
  
  p <- ggplot(df, aes(x = x, y = y, fill = class)) +
    geom_raster() +
    coord_equal() +
    facet_wrap(~ future, ncol = 2) +
    theme_void() +
    labs(
      title = paste(country, crop_labels[[crop]], system, outcome, "- ecosystem effect classes"),
      fill = NULL
    )
  
  ggsave(
    file.path(dir_figs, paste0("panel_effect_classes_", country, "_", crop, "_", system, "_", outcome, ".png")),
    p,
    width = 14,
    height = 8,
    dpi = 300
  )
}

for (country in countries) {
  for (crop in focus_crops[[country]]) {
    systems_here <- available_systems_for_crop(country, crop)
    if (length(systems_here) == 0) next
    
    for (system in systems_here) {
      for (outcome in outcomes) {
        make_change_panel(country, crop, system, outcome)
        make_class_panel(country, crop, system, outcome)
      }
    }
  }
}

# 15. BAR / BOX PLOTS FROM SUMMARY TABLE
if (nrow(summary_table) > 0) {
  
  p_box <- ggplot(summary_table, aes(x = crop, y = mean_delta, fill = system)) +
    geom_boxplot(outlier.alpha = 0.15) +
    facet_grid(country ~ future) +
    labs(
      title = "Change in suitability by crop, irrigation system, country and future scenario",
      x = NULL,
      y = "Mean Δ suitability"
    )
  
  ggsave(
    file.path(dir_figs, "boxplot_mean_delta_by_crop_system_future.png"),
    p_box,
    width = 14,
    height = 8,
    dpi = 300
  )
  
  p_bar <- summary_table %>%
    group_by(country, crop, system, ecosystem, outcome) %>%
    summarise(mean_delta = mean(mean_delta, na.rm = TRUE), .groups = "drop") %>%
    ggplot(aes(x = crop, y = mean_delta, fill = system)) +
    geom_col(position = "dodge") +
    facet_grid(outcome + country ~ ecosystem) +
    labs(
      title = "Average change by country, crop, system, outcome and ecosystem scenario",
      x = NULL,
      y = "Mean Δ suitability"
    )
  
  ggsave(
    file.path(dir_figs, "barplot_mean_delta_country_crop_system_ecoscenario.png"),
    p_bar,
    width = 15,
    height = 9,
    dpi = 300
  )
}

# 16. RUN SUMMARY
writeLines(
  c(
    "SCRIPT 1 COMPLETE",
    paste("Output root:", out_root),
    "",
    "Key outputs:",
    "- tables/model_auc_summary.csv",
    "- tables/future_suitability_summary.csv",
    "- figures/response_curves_*.png",
    "- figures/panel_delta_*.png",
    "- figures/panel_effect_classes_*.png",
    "- rasters/future_*.tif",
    "- rasters/delta_from_present_*.tif",
    "- rasters/ecosystem_modulation_*.tif",
    "- rasters/ecosystem_effect_class_*.tif"
  ),
  con = file.path(out_root, "README_script1.txt")
)

