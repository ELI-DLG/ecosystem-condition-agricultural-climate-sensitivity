# Data cleaning: Bioclim variables from TerraClimate monthly NetCDFs
# Spain and UK, 2000-2024
# Computes BIO1, BIO4, BIO5, BIO6, BIO7, BIO12, BIO15, BIO18, BIO19
# per GADM L1 region per year, and national averages.
#
# Patched for list-columns from exact_extract, ragged months,
# and warm/cold quarter wrap-around indexing.
# Spain: Canary Islands excluded (centroid longitude > -10 only).
#
# Inputs:
#   TerraClimate NetCDFs: Bioclimate/THREDDS/TerraClimate_tmin_YYYY.nc etc.
#   GADM shapefiles: basicshapes/gadm41_ESP_shp/ and gadm41_GBR_shp/
#
# Outputs (in Bioclimate/Bioclim_TimeSeries/):
#   ESP_Bioclim_2000_2024.csv, ESP_Bioclim_National_2000_2024.csv
#   GBR_Bioclim_2000_2024.csv, GBR_Bioclim_National_2000_2024.csv
#   ESP_Bioclim_Trends.png,    GBR_Bioclim_Trends.png

library(terra)
library(sf)
library(dplyr)
library(tidyr)
library(ggplot2)
library(exactextractr)
library(stringr)

path_nc  <- "~/Documents/FoodSecurityV2/Bioclimate/THREDDS"
path_shp <- "~/Documents/FoodSecurityV2/basicshapes"
out_root <- "~/Documents/FoodSecurityV2/Bioclimate/Bioclim_TimeSeries"
dir.create(out_root, showWarnings = FALSE, recursive = TRUE)

years <- 2000:2024

countries <- list(
  ESP = list(name = "Spain",
             gadm = file.path(path_shp, "gadm41_ESP_shp/gadm41_ESP_1.shp")),
  GBR = list(name = "UK",
             gadm = file.path(path_shp, "gadm41_GBR_shp/gadm41_GBR_1.shp"))
)

load_year_data <- function(year, path_nc) {
  tmin <- rast(file.path(path_nc, sprintf("TerraClimate_tmin_%d.nc", year)))
  tmax <- rast(file.path(path_nc, sprintf("TerraClimate_tmax_%d.nc", year)))
  ppt  <- rast(file.path(path_nc, sprintf("TerraClimate_ppt_%d.nc",  year)))
  crs(tmin) <- crs(tmax) <- crs(ppt) <- "EPSG:4326"
  stopifnot(nlyr(tmin) == 12, nlyr(tmax) == 12, nlyr(ppt) == 12)
  list(tmin = tmin, tmax = tmax, ppt = ppt)
}

# Flatten exact_extract output (data.frame, matrix, or list) to 12-col numeric matrix
to_matrix <- function(x, target_len = 12) {
  if (is.data.frame(x)) {
    m <- as.matrix(x)
    if (ncol(m) >= target_len) return(m[, 1:target_len, drop = FALSE])
    return(cbind(m, matrix(NA_real_, nrow(m), target_len - ncol(m))))
  }
  if (is.matrix(x)) {
    if (ncol(x) >= target_len) return(x[, 1:target_len, drop = FALSE])
    return(cbind(x, matrix(NA_real_, nrow(x), target_len - ncol(x))))
  }
  if (is.list(x)) {
    return(t(vapply(x, function(v) {
      v <- as.numeric(unlist(v))
      if (length(v) == 0) rep(NA_real_, target_len)
      else if (length(v) >= target_len) v[1:target_len]
      else c(v, rep(NA_real_, target_len - length(v)))
    }, numeric(target_len))))
  }
  as.matrix(x)
}

# 12 rolling 3-month windows with December wrap-around
quarter_windows <- rbind(
  c(12,1,2), c(1,2,3), c(2,3,4),  c(3,4,5),  c(4,5,6),  c(5,6,7),
  c(6,7,8),  c(7,8,9), c(8,9,10), c(9,10,11), c(10,11,12), c(11,12,1)
)

quarter_idx <- function(temp_vec) {
  if (sum(!is.na(temp_vec)) < 3)
    return(list(warm = integer(0), cold = integer(0)))
  means <- apply(quarter_windows, 1, function(ix) mean(temp_vec[ix], na.rm = TRUE))
  list(warm = quarter_windows[which.max(means), ],
       cold = quarter_windows[which.min(means), ])
}

compute_bioclim <- function(tmin_r, tmax_r, ppt_r, region_sf) {
  region_sf <- region_sf |> st_make_valid() |> st_simplify(dTolerance = 0.001)
  suppressWarnings({
    v_tmin <- exact_extract(tmin_r, region_sf, "mean")
    v_tmax <- exact_extract(tmax_r, region_sf, "mean")
    v_ppt  <- exact_extract(ppt_r,  region_sf, "mean")
  })
  v_tmin  <- to_matrix(v_tmin,  12)
  v_tmax  <- to_matrix(v_tmax,  12)
  v_ppt   <- to_matrix(v_ppt,   12)
  v_tmean <- (v_tmin + v_tmax) / 2

  BIO1  <- rowMeans(v_tmean, na.rm = TRUE)
  BIO4  <- apply(v_tmean, 1, sd,  na.rm = TRUE) * 100
  BIO5  <- apply(v_tmax,  1, max, na.rm = TRUE)
  BIO6  <- apply(v_tmin,  1, min, na.rm = TRUE)
  BIO7  <- BIO5 - BIO6
  BIO12 <- apply(v_ppt,   1, sum, na.rm = TRUE)
  BIO15 <- 100 * apply(v_ppt, 1, sd,   na.rm = TRUE) /
                 apply(v_ppt, 1, mean, na.rm = TRUE)

  qc    <- lapply(seq_len(nrow(v_tmean)), function(i) quarter_idx(v_tmean[i, ]))
  BIO18 <- vapply(seq_len(nrow(v_ppt)), function(i) {
    if (length(qc[[i]]$warm) == 0) return(NA_real_)
    sum(v_ppt[i, qc[[i]]$warm], na.rm = TRUE)
  }, numeric(1))
  BIO19 <- vapply(seq_len(nrow(v_ppt)), function(i) {
    if (length(qc[[i]]$cold) == 0) return(NA_real_)
    sum(v_ppt[i, qc[[i]]$cold], na.rm = TRUE)
  }, numeric(1))

  tibble(NAME_1 = region_sf$NAME_1,
         BIO1, BIO4, BIO5, BIO6, BIO7, BIO12, BIO15, BIO18, BIO19)
}

for (iso3 in names(countries)) {
  info <- countries[[iso3]]

  shp <- st_read(info$gadm, quiet = TRUE) |> st_make_valid()
  if (iso3 == "ESP") {
    rep_pt <- st_point_on_surface(st_geometry(shp))
    lon    <- st_coordinates(rep_pt)[, 1]
    shp    <- shp[lon > -10, , drop = FALSE]
  }

  out_list <- vector("list", length(years))
  names(out_list) <- years

  for (yr in years) {
    dat <- load_year_data(yr, path_nc)
    bi  <- compute_bioclim(dat$tmin, dat$tmax, dat$ppt, shp)
    bi$year <- yr
    out_list[[as.character(yr)]] <- bi
  }

  all_bio <- bind_rows(out_list)
  write.csv(all_bio,
            file.path(out_root, paste0(iso3, "_Bioclim_2000_2024.csv")),
            row.names = FALSE)

  nat <- all_bio |>
    group_by(year) |>
    summarise(across(starts_with("BIO"), ~mean(.x, na.rm = TRUE)), .groups = "drop")
  write.csv(nat,
            file.path(out_root, paste0(iso3, "_Bioclim_National_2000_2024.csv")),
            row.names = FALSE)

  nat_long <- pivot_longer(nat, starts_with("BIO"), names_to = "variable", values_to = "val")
  p <- ggplot(nat_long, aes(year, val)) +
    geom_line(colour = "steelblue", linewidth = 1) +
    facet_wrap(~variable, scales = "free_y") +
    theme_minimal(base_size = 14) +
    labs(title = paste(info$name, "Bioclimatic Trends (2000-2024)"), x = NULL, y = NULL)
  ggsave(file.path(out_root, paste0(iso3, "_Bioclim_Trends.png")), p, width = 12, height = 8)
}
