# Data cleaning: Gridded wheat yield time series extraction
# Spain and UK, 1982-2015
# Source: GlobalCropYield5min1982_2015_V4
# Produces regional and national CSVs, trend summaries, and line plots.

library(terra)
library(sf)
library(dplyr)
library(tidyr)
library(ggplot2)
library(exactextractr)

path_tif <- "~/Documents/FoodSecurityV2/FoodSecurity/GlobalCropYield5min1982_2015_V4/GlobalCropYield5min/Wheat"
path_shp <- "~/Documents/FoodSecurityV2/basicshapes"
out_root <- "~/Documents/FoodSecurityV2/Yields/Wheat_TimeSeries"
dir.create(out_root, showWarnings = FALSE, recursive = TRUE)

years <- 1982:2015

countries <- list(
  ESP = list(name = "Spain", gadm = file.path(path_shp, "gadm41_ESP_shp/gadm41_ESP_1.shp")),
  GBR = list(name = "UK",    gadm = file.path(path_shp, "gadm41_GBR_shp/gadm41_GBR_1.shp"))
)

load_wheat_raster <- function(year, path_tif) {
  f <- file.path(path_tif, sprintf("Wheat%d.tif", year))
  if (!file.exists(f)) stop("File missing: ", f)
  r <- rast(f); crs(r) <- "EPSG:4326"; r
}

extract_region_means <- function(r, region_sf) {
  region_sf <- st_make_valid(region_sf) |> st_simplify(dTolerance = 0.001)
  vals <- exact_extract(r, region_sf, "mean")
  tibble(NAME_1 = region_sf$NAME_1, yield = unlist(vals))
}

for (iso3 in names(countries)) {
  info <- countries[[iso3]]
  shp  <- st_read(info$gadm, quiet = TRUE) |> st_make_valid()
  if (iso3 == "ESP") {
    rep_pt <- st_point_on_surface(st_geometry(shp))
    shp    <- shp[st_coordinates(rep_pt)[, 1] > -10, , drop = FALSE]
  }

  results <- lapply(years, function(yr) {
    df      <- extract_region_means(load_wheat_raster(yr, path_tif), shp)
    df$year <- yr; df
  })

  all_yield <- bind_rows(results)
  write.csv(all_yield,
            file.path(out_root, paste0(iso3, "_WheatYield_1982_2015.csv")),
            row.names = FALSE)

  nat <- all_yield |>
    group_by(year) |>
    summarise(mean_yield = mean(yield, na.rm = TRUE), .groups = "drop")
  write.csv(nat,
            file.path(out_root, paste0(iso3, "_WheatYield_National_1982_2015.csv")),
            row.names = FALSE)

  fit           <- lm(mean_yield ~ year, data = nat)
  slope_decade  <- coef(fit)[2] * 10
  pval          <- summary(fit)$coefficients[2, 4]
  message(sprintf("%s trend: %.3f t/ha per decade (p = %.4f)", info$name, slope_decade, pval))

  p_nat <- ggplot(nat, aes(year, mean_yield)) +
    geom_line(colour = "darkgreen", linewidth = 1) +
    geom_smooth(method = "lm", se = FALSE, colour = "red", linetype = 2) +
    theme_minimal(base_size = 14) +
    labs(title = paste(info$name, "National Wheat Yield (1982-2015)"),
         x = NULL, y = "Yield (t/ha)")
  ggsave(file.path(out_root, paste0(iso3, "_WheatYield_National_Trend.png")),
         p_nat, width = 10, height = 6)

  p_reg <- ggplot(all_yield, aes(year, yield, colour = NAME_1, group = NAME_1)) +
    geom_line(linewidth = 1, alpha = 0.8) +
    theme_minimal(base_size = 14) +
    theme(legend.position = "bottom") +
    labs(title = paste(info$name, "Regional Wheat Yield (1982-2015)"),
         x = NULL, y = "Yield (t/ha)", colour = "Region")
  ggsave(file.path(out_root, paste0(iso3, "_WheatYield_Regional_Trends.png")),
         p_reg, width = 12, height = 8)
}
