# CANVAS 3a (FINAL): Apply BII CSV Percent Change to Create 2050 Projections
# Purpose:
#   1. Load BII CSV with percent change projections for 2050
#   2. Calculate mean percent change for each scenario
#   3. Apply percent change to 2015 BII raster for all pixels
#   4. Create 2050 BII projections by scenario

library(terra)
library(tidyverse)
library(data.table)

# Paths
paths <- list(
  bii_csv = "~/Documents/FoodSecurityV2/Biodiversity/BII_longcsv",
  bii_spatial_spain = "~/Documents/FoodSecurityV2/Biodiversity/BII_Spatial/spain",
  bii_spatial_uk = "~/Documents/FoodSecurityV2/Biodiversity/BII_Spatial/uk",
  output = "~/Documents/FoodSecurityV2/WorkingData/Canvas3a_BII2050_Applied"
)

dir.create(paths$output, showWarnings = FALSE, recursive = TRUE)

# FUNCTION: Load and summarise BII CSV

load_and_summarize_csv <- function(country_code, csv_path) {
  
  country_label <- ifelse(country_code == "ESP", "Spain", "UK")
  
  csv_file <- file.path(csv_path, paste0("BII_", country_code, "_data.csv"))
  
  if (!file.exists(csv_file)) {
    return(NULL)
  }
  
  bii_df <- fread(csv_file)
  
  # Extract 2050 data
  bii_2050 <- bii_df %>%
    filter(year == 2050) %>%
    select(scenario, pct_change, value) %>%
    filter(!is.na(pct_change))
  
  if (nrow(bii_2050) == 0) {
    return(NULL)
  }
  
  # Calculate mean percent change by scenario
  mean_change <- bii_2050 %>%
    group_by(scenario) %>%
    summarise(
      mean_pct_change = mean(pct_change, na.rm = TRUE),
      n_obs = n(),
      min_pct = min(pct_change),
      max_pct = max(pct_change),
      .groups = 'drop'
    )
  
  for (i in 1:nrow(mean_change)) {
        round(mean_change$mean_pct_change[i], 2), "%\n")
  }
  
  return(mean_change)
}

# FUNCTION: Load 2015 BII raster (FIXED for correct file names)

load_bii_2015 <- function(country_name, bii_path) {
  
  # Use country name directly (spain or uk)
  bii_file <- file.path(bii_path, paste0("bii_", country_name, "_2015.tif"))
  
  if (!file.exists(bii_file)) {
    return(NULL)
  }
  
  bii_rast <- rast(bii_file)
  
  return(bii_rast)
}

# FUNCTION: Apply percent change to create 2050 projection

apply_percent_change <- function(bii_2015_rast, pct_change) {
  
  # Formula: value_2050 = value_2015 * (1 + pct_change/100)
  bii_2050 <- bii_2015_rast * (1 + pct_change / 100)
  
  return(bii_2050)
}

# MAIN: SPAIN

# Load and summarise CSV
spain_mean_change <- load_and_summarize_csv("ESP", paths$bii_csv)

if (!is.null(spain_mean_change)) {
  
  # Load 2015 BII - FIXED: use "spain" not "esp"
  spain_bii_2015 <- load_bii_2015("spain", paths$bii_spatial_spain)
  
  if (!is.null(spain_bii_2015)) {
    
    for (i in 1:nrow(spain_mean_change)) {
      scenario <- spain_mean_change$scenario[i]
      pct_change <- spain_mean_change$mean_pct_change[i]
      
      tryCatch({
        # Apply percent change
        bii_2050 <- apply_percent_change(spain_bii_2015, pct_change)
        
        # Save
        out_file <- file.path(paths$output, 
                              paste0("spain_bii_2050_", scenario, ".tif"))
        writeRaster(bii_2050, out_file, overwrite = TRUE)
        
        # Summary stats
        vals <- values(bii_2050, mat = FALSE)
        vals <- vals[!is.na(vals)]
        
            round(max(vals), 4), "\n\n")
        
      },
      error = function(e) {
      })
    }
  }
}

# MAIN: UK

# Load and summarise CSV
uk_mean_change <- load_and_summarize_csv("GBR", paths$bii_csv)

if (!is.null(uk_mean_change)) {
  
  # Load 2015 BII - FIXED: use "uk" not "gbr"
  uk_bii_2015 <- load_bii_2015("uk", paths$bii_spatial_uk)
  
  if (!is.null(uk_bii_2015)) {
    
    for (i in 1:nrow(uk_mean_change)) {
      scenario <- uk_mean_change$scenario[i]
      pct_change <- uk_mean_change$mean_pct_change[i]
      
      tryCatch({
        # Apply percent change
        bii_2050 <- apply_percent_change(uk_bii_2015, pct_change)
        
        # Save
        out_file <- file.path(paths$output, 
                              paste0("uk_bii_2050_", scenario, ".tif"))
        writeRaster(bii_2050, out_file, overwrite = TRUE)
        
        # Summary stats
        vals <- values(bii_2050, mat = FALSE)
        vals <- vals[!is.na(vals)]
        
            round(max(vals), 4), "\n\n")
        
      },
      error = function(e) {
      })
    }
  }
}

# SUMMARY

