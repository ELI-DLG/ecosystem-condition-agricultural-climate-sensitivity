# CANVAS 5e2: REGIONAL PROJECTION MAPS (2050)
# Purpose: Predict irrigation for each region separately, identify winners/losers
# Output: 8 regional maps + rankings (5 Spain + 3 UK)
# Runtime: ~20 minutes

library(gbm)
library(terra)
library(tidyverse)

paths <- list(
  training_data = "~/Documents/FoodSecurityV2/WorkingData/Canvas4b_Normalised_Final_Updated",
  models_output = "~/Documents/FoodSecurityV2/WorkingData/Canvas5e_Advanced",
  climate_2050 = "~/Documents/FoodSecurityV2/BioclimModels",
  output = "~/Documents/FoodSecurityV2/WorkingData/Canvas5e_Advanced"
)

# LOAD MODELS AND DATA

load(file.path(paths$models_output, "country_separate_models.RData"))

spain_df <- read_csv(file.path(paths$training_data, "spain_training_irrigation_normalised.csv"), 
                     show_col_types = FALSE)
uk_df <- read_csv(file.path(paths$training_data, "uk_training_irrigation_normalised.csv"), 
                  show_col_types = FALSE)

# Add regional classifications (from Canvas 5d)
spain_df$region <- case_when(
  grepl("spain", tolower(spain_df$pixel_id)) & 
    (as.numeric(sub(".*_", "", spain_df$pixel_id)) > 41 & 
       as.numeric(sub(".*_", "", spain_df$pixel_id)) < 42.5) ~ "Castilla_Leon",
  grepl("spain", tolower(spain_df$pixel_id)) & 
    (as.numeric(sub(".*_", "", spain_df$pixel_id)) >= 39 & 
       as.numeric(sub(".*_", "", spain_df$pixel_id)) < 40.5) ~ "Castilla_LaMancha",
  grepl("spain", tolower(spain_df$pixel_id)) & 
    (as.numeric(sub(".*_", "", spain_df$pixel_id)) >= 37.8 & 
       as.numeric(sub(".*_", "", spain_df$pixel_id)) < 40) ~ "Extremadura",
  grepl("spain", tolower(spain_df$pixel_id)) & 
    (as.numeric(sub(".*_", "", spain_df$pixel_id)) < 38.5) ~ "Andalusia",
  grepl("spain", tolower(spain_df$pixel_id)) & 
    (as.numeric(sub(".*_", "", spain_df$pixel_id)) > 41.5) ~ "Catalonia",
  TRUE ~ "Other_Spain"
)

uk_df$region <- case_when(
  grepl("uk", tolower(uk_df$pixel_id)) & as.numeric(sub(".*_", "", uk_df$pixel_id)) < 51.2 ~ "Sussex",
  grepl("uk", tolower(uk_df$pixel_id)) & as.numeric(sub(".*_", "", uk_df$pixel_id)) >= 52 & 
    as.numeric(sub(".*_", "", uk_df$pixel_id)) <= 53 ~ "Norfolk_East_Anglia",
  grepl("uk", tolower(uk_df$pixel_id)) & as.numeric(sub(".*_", "", uk_df$pixel_id)) > 53.5 ~ "Yorkshire_Humber",
  TRUE ~ "Other_UK"
)

# LOAD 2050 CLIMATE (RCP585, 2041-2060)

spain_bio1_2050 <- rast(file.path(paths$climate_2050, "ESP/585_2041-2060/bio1.tif"))
spain_bio12_2050 <- rast(file.path(paths$climate_2050, "ESP/585_2041-2060/bio12.tif"))

uk_bio1_2050 <- rast(file.path(paths$climate_2050, "GBR/585_2041-2060/bio1.tif"))
uk_bio12_2050 <- rast(file.path(paths$climate_2050, "GBR/585_2041-2060/bio12.tif"))

# FUNCTION: Predict irrigation for region

predict_region_irrigation <- function(df, model_cascade, region_name, 
                                      bio1_2050, bio12_2050, country_name) {
  
  # Get region data
  region_data <- df %>% filter(region == region_name)
  
  if (nrow(region_data) == 0) {
    return(NULL)
  }
  
  # Extract 2050 climate for this region
  bio1_vals <- terra::extract(bio1_2050, region_data$pixel_id)[, 1]
  bio12_vals <- terra::extract(bio12_2050, region_data$pixel_id)[, 1]
  
  # Get model
  model <- model_cascade$models$Climate_plus_Both$model
  best_n <- model_cascade$models$Climate_plus_Both$best_n
  
  # Create prediction data (use 2050 climate for key variables)
  pred_data <- region_data
  
  # Update with 2050 climate
  bio1_col <- grep("bio1", colnames(pred_data), value = TRUE)[1]
  bio12_col <- grep("bio12", colnames(pred_data), value = TRUE)[1]
  
  if (!is.na(bio1_col)) pred_data[[bio1_col]] <- bio1_vals
  if (!is.na(bio12_col)) pred_data[[bio12_col]] <- bio12_vals
  
  # Predict
  pred_2050 <- predict(model, newdata = pred_data, n.trees = best_n)
  
  # Calculate loss
  irrigation_2015 <- region_data$prop_irrigated
  irrigation_loss <- irrigation_2015 - pred_2050
  
  # Create results
  results <- data.frame(
    Pixel_ID = region_data$pixel_id,
    Irrigation_2015 = irrigation_2015,
    Irrigation_2050 = pred_2050,
    Irrigation_Loss = irrigation_loss,
    At_Risk = irrigation_loss > 0.1,
    Winner = irrigation_loss < -0.05  # Gains irrigation
  )
  
  return(results)
}

# SPAIN: REGIONAL PREDICTIONS

spain_regions <- c("Castilla_Leon", "Castilla_LaMancha", "Extremadura", "Andalusia", "Catalonia")
spain_regional_results <- list()
spain_regional_summary <- data.frame()

for (region in spain_regions) {
  result <- predict_region_irrigation(spain_df, spain_cascade, region, 
                                      spain_bio1_2050, spain_bio12_2050, "Spain")
  
  if (!is.null(result)) {
    spain_regional_results[[region]] <- result
    
    # Summary
    summary_row <- data.frame(
      Country = "Spain",
      Region = region,
      Pixels = nrow(result),
      Mean_Loss = mean(result$Irrigation_Loss, na.rm = TRUE),
      Median_Loss = median(result$Irrigation_Loss, na.rm = TRUE),
      Pixels_at_Risk = sum(result$At_Risk, na.rm = TRUE),
      Pct_at_Risk = round(sum(result$At_Risk, na.rm = TRUE) / nrow(result) * 100, 1),
      Winners = sum(result$Winner, na.rm = TRUE),
      Pct_Winners = round(sum(result$Winner, na.rm = TRUE) / nrow(result) * 100, 1)
    )
    
    spain_regional_summary <- bind_rows(spain_regional_summary, summary_row)
  }
}

# UK: REGIONAL PREDICTIONS

uk_regions <- c("Norfolk_East_Anglia", "Yorkshire_Humber", "Sussex")
uk_regional_results <- list()
uk_regional_summary <- data.frame()

for (region in uk_regions) {
  result <- predict_region_irrigation(uk_df, uk_cascade, region,
                                      uk_bio1_2050, uk_bio12_2050, "UK")
  
  if (!is.null(result)) {
    uk_regional_results[[region]] <- result
    
    # Summary
    summary_row <- data.frame(
      Country = "UK",
      Region = region,
      Pixels = nrow(result),
      Mean_Loss = mean(result$Irrigation_Loss, na.rm = TRUE),
      Median_Loss = median(result$Irrigation_Loss, na.rm = TRUE),
      Pixels_at_Risk = sum(result$At_Risk, na.rm = TRUE),
      Pct_at_Risk = round(sum(result$At_Risk, na.rm = TRUE) / nrow(result) * 100, 1),
      Winners = sum(result$Winner, na.rm = TRUE),
      Pct_Winners = round(sum(result$Winner, na.rm = TRUE) / nrow(result) * 100, 1)
    )
    
    uk_regional_summary <- bind_rows(uk_regional_summary, summary_row)
  }
}

# COMBINE AND RANK

all_regional_summary <- bind_rows(spain_regional_summary, uk_regional_summary) %>%
  arrange(desc(Pct_at_Risk))

print(all_regional_summary)

# IDENTIFY WINNERS AND LOSERS

losers <- all_regional_summary %>% arrange(desc(Pct_at_Risk)) %>% head(3)
for (i in 1:nrow(losers)) {
      losers$Pct_at_Risk[i], "% at risk\n", sep = "")
}

winners <- all_regional_summary %>% arrange(desc(Pct_Winners)) %>% head(3)
for (i in 1:nrow(winners)) {
      winners$Pct_Winners[i], "% winners\n", sep = "")
}

# CREATE PLOTS

# Plot 1: Spain regions - Risk ranking
png(file.path(paths$output, "02a_spain_regional_risk_ranking.png"),
    width = 900, height = 600)

par(mar = c(8, 4, 3, 2))

spain_sorted <- spain_regional_summary %>% arrange(Pct_at_Risk)
colors_spain <- ifelse(spain_sorted$Pct_at_Risk > 20, "#e74c3c",
                       ifelse(spain_sorted$Pct_at_Risk > 10, "#f39c12", "#27ae60"))

barplot(spain_sorted$Pct_at_Risk,
        names.arg = spain_sorted$Region,
        las = 2,
        main = "SPAIN: Regional Vulnerability to Irrigation Loss (2050)",
        ylab = "% Pixels at Risk (loss > 0.1)",
        col = colors_spain,
        border = NA)
grid(NA, NULL, lty = 1, col = "grey80")
abline(h = 20, lty = 2, col = "red", lwd = 1)
text(0.5, 22, "High Risk", cex = 0.8, col = "red")

dev.off()

# Plot 2: UK regions - Risk ranking
png(file.path(paths$output, "02b_uk_regional_risk_ranking.png"),
    width = 900, height = 600)

par(mar = c(8, 4, 3, 2))

uk_sorted <- uk_regional_summary %>% arrange(Pct_at_Risk)
colors_uk <- ifelse(uk_sorted$Pct_at_Risk > 5, "#e74c3c",
                    ifelse(uk_sorted$Pct_at_Risk > 2, "#f39c12", "#27ae60"))

barplot(uk_sorted$Pct_at_Risk,
        names.arg = uk_sorted$Region,
        las = 2,
        main = "UK: Regional Vulnerability to Irrigation Loss (2050)",
        ylab = "% Pixels at Risk (loss > 0.1)",
        col = colors_uk,
        border = NA)
grid(NA, NULL, lty = 1, col = "grey80")
abline(h = 5, lty = 2, col = "red", lwd = 1)
text(0.5, 5.5, "High Risk", cex = 0.8, col = "red")

dev.off()

# Plot 3: Winners vs Losers
png(file.path(paths$output, "02c_winners_vs_losers.png"),
    width = 1000, height = 600)

par(mfrow = c(1, 2), mar = c(8, 4, 3, 2))

# Spain
spain_win_loss <- data.frame(
  Region = spain_regional_summary$Region,
  Losers = spain_regional_summary$Pct_at_Risk,
  Winners = spain_regional_summary$Pct_Winners
)

x_pos <- barplot(rbind(spain_win_loss$Losers, spain_win_loss$Winners),
                 beside = TRUE,
                 names.arg = spain_win_loss$Region,
                 las = 2,
                 main = "SPAIN: Winners vs Losers",
                 ylab = "% Pixels",
                 col = c("#e74c3c", "#27ae60"),
                 border = NA,
                 legend.text = c("At Risk (Loss)", "Winners (Gain)"),
                 args.legend = list(x = "topright"))

grid(NA, NULL, lty = 1, col = "grey80")

# UK
uk_win_loss <- data.frame(
  Region = uk_regional_summary$Region,
  Losers = uk_regional_summary$Pct_at_Risk,
  Winners = uk_regional_summary$Pct_Winners
)

x_pos <- barplot(rbind(uk_win_loss$Losers, uk_win_loss$Winners),
                 beside = TRUE,
                 names.arg = uk_win_loss$Region,
                 las = 2,
                 main = "UK: Winners vs Losers",
                 ylab = "% Pixels",
                 col = c("#e74c3c", "#27ae60"),
                 border = NA)

grid(NA, NULL, lty = 1, col = "grey80")

dev.off()

# SAVE RESULTS

write_csv(all_regional_summary, file.path(paths$output, "02_regional_risk_ranking.csv"))

write_csv(spain_regional_summary, file.path(paths$output, "02_spain_regional_detail.csv"))

write_csv(uk_regional_summary, file.path(paths$output, "02_uk_regional_detail.csv"))

# SUMMARY

most_vuln <- all_regional_summary %>% slice_max(Pct_at_Risk, n = 1)
    most_vuln$Pct_at_Risk, "% at risk\n\n", sep = "")

most_resilient <- all_regional_summary %>% slice_min(Pct_at_Risk, n = 1)
    most_resilient$Pct_at_Risk, "% at risk\n\n", sep = "")

