# CANVAS 3c: Load Future Climate Projections
# Purpose:
#   1. Load historical and future climate from WorldClim (Max Planck institute)
#   2. Load bioclim variables and other climate variables for all SSP scenarios
#   3. Align all rasters to reference grid (2015 BII)
#   4. Organize by scenario and time period
#   5. Save organised climate layers
# Output: Future climate rasters organised by scenario, aligned to 2015 BII grid

library(terra)
library(tidyverse)

# Paths
paths <- list(
  bii_spatial = "~/Documents/FoodSecurityV2/Biodiversity/BII_Spatial",
  worldclim = "~/Documents/FoodSecurityV2/BioclimModels",
  output = "~/Documents/FoodSecurityV2/WorkingData/Canvas3c_FutureClimate"
)

dir.create(paths$output, showWarnings = FALSE, recursive = TRUE)

# FUNCTION: Load reference raster for alignment

load_reference_grid <- function(country_code, bii_path) {
  
  country_label <- ifelse(country_code == "ESP", "Spain", "UK")
  
  bii_file <- file.path(bii_path, tolower(country_code),
                        paste0("bii_", tolower(country_code), "_2015.tif"))
  
  if (!file.exists(bii_file)) {
    return(NULL)
  }
  
  ref <- rast(bii_file)
  
  return(ref)
}

# FUNCTION: Align raster to reference if needed

align_to_reference <- function(rast_in, ref_grid, variable_name = "unknown") {
  
  if (identical(crs(rast_in), crs(ref_grid)) &&
      all(abs(res(rast_in) - res(ref_grid)) < 1e-6) &&
      isTRUE(all.equal(ext(rast_in), ext(ref_grid)))) {
    # Already aligned
    return(rast_in)
  } else {
    # Need to reproject and resample
    rast_aligned <- project(rast_in, ref_grid, method = "bilinear")
    rast_aligned <- crop(rast_aligned, ref_grid)
    return(rast_aligned)
  }
}

# FUNCTION: Load climate rasters for a scenario

load_scenario_climate <- function(country_code, scenario, worldclim_path, ref_grid) {
  
  country_dir <- ifelse(country_code == "ESP", "ESP", "GBR")
  scenario_path <- file.path(worldclim_path, country_dir, scenario)
  
  if (!dir.exists(scenario_path)) {
    return(list())
  }
  
  clim_list <- list()
  
  # Load bioclim variables
  bio_files <- list.files(scenario_path, pattern = "^bio[0-9]+\\.tif$", 
                          full.names = TRUE)
  
  if (length(bio_files) > 0) {
    for (bio_file in bio_files) {
      bio_name <- tools::file_path_sans_ext(basename(bio_file))
      
      bio_rast <- rast(bio_file)
      bio_aligned <- align_to_reference(bio_rast, ref_grid, bio_name)
      
      full_name <- paste0(tolower(country_code), "_", scenario, "_", bio_name)
      clim_list[[full_name]] <- bio_aligned
    }
  }
  
  # Load additional variables: pr (precip), tn (min temp), tx (max temp)
  other_vars <- c("pr", "tn", "tx")
  
  for (var in other_vars) {
    var_file <- file.path(scenario_path, paste0(var, ".tif"))
    
    if (file.exists(var_file)) {
      var_rast <- rast(var_file)
      var_aligned <- align_to_reference(var_rast, ref_grid, var)
      
      full_name <- paste0(tolower(country_code), "_", scenario, "_", var)
      clim_list[[full_name]] <- var_aligned
    }
  }
  
  return(clim_list)
}

# MAIN: SPAIN CLIMATE

# Load reference
spain_ref <- load_reference_grid("ESP", paths$bii_spatial)

if (!is.null(spain_ref)) {
  
  # Define scenarios
  scenarios <- c(
    "historical",
    "245_2021-2040", "245_2041-2060",
    "370_2021-2040", "370_2041-2060",
    "585_2021-2040", "585_2041-2060"
  )
  
  spain_climate_all <- list()
  
  for (scenario in scenarios) {
    
    scenario_clim <- load_scenario_climate("ESP", scenario, 
                                           paths$worldclim, spain_ref)
    
    spain_climate_all <- c(spain_climate_all, scenario_clim)
  }
  
  # Save all Spain climate rasters
  
  for (name in names(spain_climate_all)) {
    out_file <- file.path(paths$output, paste0(name, ".tif"))
    writeRaster(spain_climate_all[[name]], out_file, overwrite = TRUE)
  }
  
}

# MAIN: UK CLIMATE

# Load reference
uk_ref <- load_reference_grid("GBR", paths$bii_spatial)

if (!is.null(uk_ref)) {
  
  scenarios <- c(
    "historical",
    "245_2021-2040", "245_2041-2060",
    "370_2021-2040", "370_2041-2060",
    "585_2021-2040", "585_2041-2060"
  )
  
  uk_climate_all <- list()
  
  for (scenario in scenarios) {
    
    scenario_clim <- load_scenario_climate("GBR", scenario, 
                                           paths$worldclim, uk_ref)
    
    uk_climate_all <- c(uk_climate_all, scenario_clim)
  }
  
  # Save all UK climate rasters
  
  for (name in names(uk_climate_all)) {
    out_file <- file.path(paths$output, paste0(name, ".tif"))
    writeRaster(uk_climate_all[[name]], out_file, overwrite = TRUE)
  }
  
}

# SUMMARY

