# SCRIPT B — FIT PRESENT-DAY MODELS
#   - continuous for both countries
#   - binomial for Spain only
#   - irrigation gain continuous where possible
#   - imputes missing predictor values using country-level medians
#   - writes models, baseline rasters, audits, diagnostics

suppressPackageStartupMessages({
  library(terra)
  library(dplyr)
  library(mgcv)
  library(readr)
  library(tidyr)
})

terraOptions(memfrac = 0.7)

root <- path.expand("~/Documents/FoodSecurityV2")

stack_dir <- file.path(root, "WorkingData/CH6_FINAL_STACKS")
out_dir   <- file.path(root, "WorkingData/CH6_STAGE_B_FINAL")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

countries <- c("Spain", "UK")
crops_sp  <- c("wheat", "barley", "maize", "pulses", "potato")
crops_uk  <- c("wheat", "barley", "pulses", "potato")

predictor_set <- c(
  "bii_2015", "agb_2015", "agb_delta", "crop_diversity",
  "bio1", "bio4", "bio5", "bio6", "bio12", "bio15", "bio18", "bio19"
)

viability_thr <- 0.40
highyield_thr <- 0.70
heat_cutoff_c <- 35

}

get_crop_list <- function(country) {
  if (country == "Spain") crops_sp else crops_uk
}

load_country_stack <- function(country) {
  fp <- file.path(stack_dir, paste0(country, "_FINAL_STACK_2015.tif"))
  r <- rast(fp)
  names(r) <- tolower(names(r))
  r
}

detect_yield_column <- function(nms, crop, regime) {
  crop <- tolower(crop)
  regime <- tolower(regime)
  
  pats <- if (regime == "rf") {
    c(
      paste0("^", crop, "_yield_rf$"),
      paste0("^", crop, ".*yield.*rf$"),
      paste0("^", crop, ".*rainfed$"),
      paste0("^", crop, "_rf$"),
      paste0("^", crop, ".*_rf$")
    )
  } else {
    c(
      paste0("^", crop, "_yield_irr$"),
      paste0("^", crop, ".*yield.*irr$"),
      paste0("^", crop, ".*irrigated$"),
      paste0("^", crop, "_irr$"),
      paste0("^", crop, ".*_irr$")
    )
  }
  
  hits <- unique(unlist(lapply(pats, function(p) grep(p, nms, value = TRUE, ignore.case = TRUE))))
  if (length(hits) == 0) return(NA_character_)
  hits[1]
}

rescale01 <- function(x) {
  rng <- range(x, na.rm = TRUE)
  if (!is.finite(rng[1]) || !is.finite(rng[2]) || diff(rng) == 0) {
    return(rep(0.5, length(x)))
  }
  (x - rng[1]) / diff(rng)
}

make_regime_df <- function(df, y_col) {
  if (is.na(y_col) || !(y_col %in% names(df))) return(NULL)
  out <- df
  out$y_cont <- out[[y_col]]
  out %>% filter(is.finite(y_cont))
}

make_gain_df <- function(df, rf_col, irr_col) {
  if (is.na(rf_col) || is.na(irr_col)) return(NULL)
  if (!(rf_col %in% names(df) && irr_col %in% names(df))) return(NULL)
  
  out <- df
  out$gain_cont <- out[[irr_col]] - out[[rf_col]]
  out %>% filter(is.finite(gain_cont))
}

make_binary_response <- function(y_cont) {
  thr <- as.numeric(median(y_cont, na.rm = TRUE))
  y_bin <- ifelse(y_cont > thr, 1L, 0L)
  
  if (length(unique(y_bin)) < 2) {
    thr <- as.numeric(quantile(y_cont, 0.25, na.rm = TRUE))
    y_bin <- ifelse(y_cont > thr, 1L, 0L)
  }
  
  list(y_bin = y_bin, threshold_used = thr)
}

compute_predictor_medians <- function(df, predictors) {
  meds <- sapply(df[predictors], function(x) median(x[is.finite(x)], na.rm = TRUE))
  as.list(meds)
}

impute_df_predictors <- function(df, predictors, predictor_medians) {
  for (p in predictors) {
    miss <- !is.finite(df[[p]])
    if (any(miss)) {
      df[[p]][miss] <- predictor_medians[[p]]
    }
  }
  df
}

impute_raster_predictors <- function(r, predictors, predictor_medians) {
  out <- r[[predictors]]
  for (p in predictors) {
    out[[p]] <- ifel(is.na(out[[p]]), predictor_medians[[p]], out[[p]])
  }
  out
}

fit_bam_continuous <- function(df, response_col, predictors, predictor_medians, max_n = 50000, seed = 123) {
  df <- df %>% filter(is.finite(.data[[response_col]]))
  if (nrow(df) < 200) {
    return(list(model = NULL, predictors = predictors, n = nrow(df), predictor_medians = predictor_medians))
  }
  
  df <- impute_df_predictors(df, predictors, predictor_medians)
  df$y_scaled <- rescale01(df[[response_col]])
  
  if (nrow(df) > max_n) {
    set.seed(seed)
    df <- df[sample(seq_len(nrow(df)), max_n), , drop = FALSE]
  }
  
  form <- as.formula(
    paste("y_scaled ~", paste(sprintf("s(%s, bs='cr', k=5)", predictors), collapse = " + "))
  )
  
  mod <- tryCatch(
    bam(form, data = df, family = gaussian(), method = "fREML", discrete = TRUE),
    error = function(e) NULL
  )
  
  list(model = mod, predictors = predictors, n = nrow(df), predictor_medians = predictor_medians)
}

fit_bam_binomial <- function(df, response_col, predictors, predictor_medians, max_n = 50000, seed = 123) {
  df <- df %>% filter(is.finite(.data[[response_col]]))
  if (nrow(df) < 200) {
    return(list(model = NULL, predictors = predictors, n = nrow(df), threshold_used = NA_real_, predictor_medians = predictor_medians))
  }
  
  df <- impute_df_predictors(df, predictors, predictor_medians)
  resp <- make_binary_response(df[[response_col]])
  df$y_bin <- resp$y_bin
  
  if (length(unique(df$y_bin)) < 2) {
    return(list(model = NULL, predictors = predictors, n = nrow(df), threshold_used = resp$threshold_used, predictor_medians = predictor_medians))
  }
  
  if (nrow(df) > max_n) {
    set.seed(seed)
    idx0 <- which(df$y_bin == 0)
    idx1 <- which(df$y_bin == 1)
    n_each <- floor(max_n / 2)
    keep <- c(
      sample(idx0, min(length(idx0), n_each)),
      sample(idx1, min(length(idx1), n_each))
    )
    df <- df[keep, , drop = FALSE]
  }
  
  form <- as.formula(
    paste("y_bin ~", paste(sprintf("s(%s, bs='cr', k=5)", predictors), collapse = " + "))
  )
  
  mod <- tryCatch(
    bam(form, data = df, family = binomial(link = "logit"), method = "fREML", discrete = TRUE),
    error = function(e) NULL
  )
  
  list(
    model = mod,
    predictors = predictors,
    n = nrow(df),
    threshold_used = resp$threshold_used,
    predictor_medians = predictor_medians
  )
}

fit_bam_gain <- function(df, predictors, predictor_medians, max_n = 50000, seed = 123) {
  df <- df %>% filter(is.finite(gain_cont))
  if (nrow(df) < 200) {
    return(list(model = NULL, predictors = predictors, n = nrow(df), predictor_medians = predictor_medians))
  }
  
  df <- impute_df_predictors(df, predictors, predictor_medians)
  df$gain_scaled <- rescale01(df$gain_cont)
  
  if (nrow(df) > max_n) {
    set.seed(seed)
    df <- df[sample(seq_len(nrow(df)), max_n), , drop = FALSE]
  }
  
  form <- as.formula(
    paste("gain_scaled ~", paste(sprintf("s(%s, bs='cr', k=5)", predictors), collapse = " + "))
  )
  
  mod <- tryCatch(
    bam(form, data = df, family = gaussian(), method = "fREML", discrete = TRUE),
    error = function(e) NULL
  )
  
  list(model = mod, predictors = predictors, n = nrow(df), predictor_medians = predictor_medians)
}

count_threshold_pixels <- function(r, thr) {
  as.numeric(global(r > thr, "sum", na.rm = TRUE)[1,1])
}

for (country in countries) {
  
  r <- load_country_stack(country)
  df <- as.data.frame(r, xy = TRUE, na.rm = FALSE)
  nms <- names(df)
  crop_list <- get_crop_list(country)
  
  predictors_present <- intersect(predictor_set, nms)
  predictor_medians <- compute_predictor_medians(df, predictors_present)
  
  country_dir <- file.path(out_dir, country)
  dir.create(country_dir, recursive = TRUE, showWarnings = FALSE)
  
  yield_audit <- list()
  diagnostics <- list()
  baseline_summary <- list()
  
  for (crop in crop_list) {
    rf_col  <- detect_yield_column(nms, crop, "rf")
    irr_col <- detect_yield_column(nms, crop, "irr")
    
    yield_audit[[length(yield_audit) + 1]] <- tibble(
      country = country,
      crop = crop,
      rf_col = rf_col,
      irr_col = irr_col
    )
    
    # REGIME MODELS
    for (regime in c("rf", "irr")) {
      y_col <- if (regime == "rf") rf_col else irr_col
      df_reg <- make_regime_df(df, y_col)
      
      if (is.null(df_reg)) {
        diagnostics[[length(diagnostics) + 1]] <- tibble(
          country = country,
          crop = crop,
          regime = regime,
          model_type = "continuous",
          status = "missing_yield_column",
          n = 0,
          threshold_used = NA_real_,
          predictors_used = NA_character_
        )
        next
      }
      
      # continuous for both countries
      fit_cont <- fit_bam_continuous(df_reg, "y_cont", predictors_present, predictor_medians)
      
      diagnostics[[length(diagnostics) + 1]] <- tibble(
        country = country,
        crop = crop,
        regime = regime,
        model_type = "continuous",
        status = ifelse(is.null(fit_cont$model), "failed_or_insufficient", "ok"),
        n = fit_cont$n,
        threshold_used = NA_real_,
        predictors_used = paste(fit_cont$predictors, collapse = "; ")
      )
      
      if (!is.null(fit_cont$model)) {
        obj <- list(
          model = fit_cont$model,
          predictors = fit_cont$predictors,
          predictor_medians = fit_cont$predictor_medians,
          model_type = "continuous",
          yield_column = y_col,
          country = country,
          crop = crop,
          regime = regime
        )
        
        saveRDS(obj, file.path(country_dir, paste0(country, "_", crop, "_", regime, "_continuous_model.rds")))
        
        pred_stack <- impute_raster_predictors(r, fit_cont$predictors, fit_cont$predictor_medians)
        pred_base <- predict(pred_stack, fit_cont$model)
        pred_base <- clamp(pred_base, lower = 0, upper = 1, values = TRUE)
        
        heat_plausible <- r[["bio5"]] < heat_cutoff_c
        pred_feasible <- pred_base * heat_plausible
        
        prefix <- paste0(country, "_", crop, "_", regime, "_continuous_baseline")
        writeRaster(pred_base, file.path(country_dir, paste0(prefix, "_P.tif")), overwrite = TRUE)
        writeRaster(pred_feasible, file.path(country_dir, paste0(prefix, "_P_feasible35.tif")), overwrite = TRUE)
        writeRaster(heat_plausible, file.path(country_dir, paste0(prefix, "_heat_plausible.tif")), overwrite = TRUE)
        
        baseline_summary[[length(baseline_summary) + 1]] <- tibble(
          country = country,
          crop = crop,
          regime = regime,
          model_type = "continuous_baseline",
          mean_P = as.numeric(global(pred_base, "mean", na.rm = TRUE)[1,1]),
          mean_P_feasible35 = as.numeric(global(pred_feasible, "mean", na.rm = TRUE)[1,1]),
          viable_pixels = count_threshold_pixels(pred_base, viability_thr),
          highyield_pixels = count_threshold_pixels(pred_base, highyield_thr)
        )
      }
      
      # binomial for Spain only
      if (country == "Spain") {
        fit_bin <- fit_bam_binomial(df_reg, "y_cont", predictors_present, predictor_medians)
        
        diagnostics[[length(diagnostics) + 1]] <- tibble(
          country = country,
          crop = crop,
          regime = regime,
          model_type = "binomial",
          status = ifelse(is.null(fit_bin$model), "failed_or_insufficient", "ok"),
          n = fit_bin$n,
          threshold_used = fit_bin$threshold_used,
          predictors_used = paste(fit_bin$predictors, collapse = "; ")
        )
        
        if (!is.null(fit_bin$model)) {
          obj <- list(
            model = fit_bin$model,
            predictors = fit_bin$predictors,
            predictor_medians = fit_bin$predictor_medians,
            model_type = "binomial",
            yield_column = y_col,
            threshold_used = fit_bin$threshold_used,
            country = country,
            crop = crop,
            regime = regime
          )
          
          saveRDS(obj, file.path(country_dir, paste0(country, "_", crop, "_", regime, "_binomial_model.rds")))
          
          pred_stack <- impute_raster_predictors(r, fit_bin$predictors, fit_bin$predictor_medians)
          pred_base <- predict(pred_stack, fit_bin$model, type = "response")
          pred_base <- clamp(pred_base, lower = 0, upper = 1, values = TRUE)
          
          heat_plausible <- r[["bio5"]] < heat_cutoff_c
          pred_feasible <- pred_base * heat_plausible
          
          prefix <- paste0(country, "_", crop, "_", regime, "_binomial_baseline")
          writeRaster(pred_base, file.path(country_dir, paste0(prefix, "_P.tif")), overwrite = TRUE)
          writeRaster(pred_feasible, file.path(country_dir, paste0(prefix, "_P_feasible35.tif")), overwrite = TRUE)
          writeRaster(heat_plausible, file.path(country_dir, paste0(prefix, "_heat_plausible.tif")), overwrite = TRUE)
          
          baseline_summary[[length(baseline_summary) + 1]] <- tibble(
            country = country,
            crop = crop,
            regime = regime,
            model_type = "binomial_baseline",
            mean_P = as.numeric(global(pred_base, "mean", na.rm = TRUE)[1,1]),
            mean_P_feasible35 = as.numeric(global(pred_feasible, "mean", na.rm = TRUE)[1,1]),
            viable_pixels = count_threshold_pixels(pred_base, viability_thr),
            highyield_pixels = count_threshold_pixels(pred_base, highyield_thr)
          )
        }
      }
    }
    
    # IRRIGATION GAIN
    df_gain <- make_gain_df(df, rf_col, irr_col)
    
    if (!is.null(df_gain)) {
      fit_gain <- fit_bam_gain(df_gain, predictors_present, predictor_medians)
      
      diagnostics[[length(diagnostics) + 1]] <- tibble(
        country = country,
        crop = crop,
        regime = "gain",
        model_type = "gain_continuous",
        status = ifelse(is.null(fit_gain$model), "failed_or_insufficient", "ok"),
        n = fit_gain$n,
        threshold_used = NA_real_,
        predictors_used = paste(fit_gain$predictors, collapse = "; ")
      )
      
      if (!is.null(fit_gain$model)) {
        obj <- list(
          model = fit_gain$model,
          predictors = fit_gain$predictors,
          predictor_medians = fit_gain$predictor_medians,
          model_type = "gain_continuous",
          rf_col = rf_col,
          irr_col = irr_col,
          country = country,
          crop = crop,
          regime = "gain"
        )
        
        saveRDS(obj, file.path(country_dir, paste0(country, "_", crop, "_gain_continuous_model.rds")))
        
        pred_stack <- impute_raster_predictors(r, fit_gain$predictors, fit_gain$predictor_medians)
        pred_gain <- predict(pred_stack, fit_gain$model)
        pred_gain <- clamp(pred_gain, lower = 0, upper = 1, values = TRUE)
        
        writeRaster(pred_gain, file.path(country_dir, paste0(country, "_", crop, "_gain_continuous_baseline.tif")), overwrite = TRUE)
        
        baseline_summary[[length(baseline_summary) + 1]] <- tibble(
          country = country,
          crop = crop,
          regime = "gain",
          model_type = "gain_continuous_baseline",
          mean_P = as.numeric(global(pred_gain, "mean", na.rm = TRUE)[1,1]),
          mean_P_feasible35 = NA_real_,
          viable_pixels = NA_real_,
          highyield_pixels = NA_real_
        )
      }
    }
  }
  
  write_csv(bind_rows(yield_audit), file.path(country_dir, paste0(country, "_yield_layer_audit.csv")))
  write_csv(bind_rows(diagnostics), file.path(country_dir, paste0(country, "_model_diagnostics.csv")))
  write_csv(bind_rows(baseline_summary), file.path(country_dir, paste0(country, "_baseline_summary.csv")))
}

# SCRIPT B — FIT PRESENT-DAY MODELS WITH BRT / GBM
#   - continuous models for Spain and UK
#   - binomial models for Spain only
#   - continuous irrigation-gain models where possible
#   - writes models, baseline rasters, audits, diagnostics

suppressPackageStartupMessages({
  library(terra)
  library(dplyr)
  library(readr)
  library(gbm)
})

terraOptions(memfrac = 0.7)

root <- path.expand("~/Documents/FoodSecurityV2")

stack_dir <- file.path(root, "WorkingData/CH6_FINAL_STACKS")
out_dir   <- file.path(root, "WorkingData/CH6_STAGE_B_BRT")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

countries <- c("Spain", "UK")
crops_sp  <- c("wheat", "barley", "maize", "pulses", "potato")
crops_uk  <- c("wheat", "barley", "pulses", "potato")

predictor_set <- c(
  "bii_2015", "agb_2015", "agb_delta", "crop_diversity",
  "bio1", "bio4", "bio5", "bio6", "bio12", "bio15", "bio18", "bio19"
)

viability_thr <- 0.40
highyield_thr <- 0.70
heat_cutoff_c <- 35

# BRT SETTINGS
n_trees        <- 4000
interaction_d  <- 5
shrinkage      <- 0.005
bag_fraction   <- 0.5
train_fraction <- 0.8
cv_folds       <- 5
min_rows       <- 200
max_n          <- 50000

}

get_crop_list <- function(country) {
  if (country == "Spain") crops_sp else crops_uk
}

load_country_stack <- function(country) {
  fp <- file.path(stack_dir, paste0(country, "_FINAL_STACK_2015.tif"))
  r <- rast(fp)
  names(r) <- tolower(names(r))
  r
}

detect_yield_column <- function(nms, crop, regime) {
  crop <- tolower(crop)
  regime <- tolower(regime)
  
  pats <- if (regime == "rf") {
    c(
      paste0("^", crop, "_yield_rf$"),
      paste0("^", crop, ".*yield.*rf$"),
      paste0("^", crop, ".*rainfed$"),
      paste0("^", crop, "_rf$"),
      paste0("^", crop, ".*_rf$")
    )
  } else {
    c(
      paste0("^", crop, "_yield_irr$"),
      paste0("^", crop, ".*yield.*irr$"),
      paste0("^", crop, ".*irrigated$"),
      paste0("^", crop, "_irr$"),
      paste0("^", crop, ".*_irr$")
    )
  }
  
  hits <- unique(unlist(lapply(pats, function(p) grep(p, nms, value = TRUE, ignore.case = TRUE))))
  if (length(hits) == 0) return(NA_character_)
  hits[1]
}

rescale01 <- function(x) {
  rng <- range(x, na.rm = TRUE)
  if (!is.finite(rng[1]) || !is.finite(rng[2]) || diff(rng) == 0) {
    return(rep(0.5, length(x)))
  }
  (x - rng[1]) / diff(rng)
}

make_regime_df <- function(df, y_col) {
  if (is.na(y_col) || !(y_col %in% names(df))) return(NULL)
  out <- df
  out$y_cont <- out[[y_col]]
  out %>% filter(is.finite(y_cont))
}

make_gain_df <- function(df, rf_col, irr_col) {
  if (is.na(rf_col) || is.na(irr_col)) return(NULL)
  if (!(rf_col %in% names(df) && irr_col %in% names(df))) return(NULL)
  
  out <- df
  out$gain_cont <- out[[irr_col]] - out[[rf_col]]
  out %>% filter(is.finite(gain_cont))
}

make_binary_response <- function(y_cont) {
  thr <- as.numeric(median(y_cont, na.rm = TRUE))
  y_bin <- ifelse(y_cont > thr, 1L, 0L)
  
  if (length(unique(y_bin)) < 2) {
    thr <- as.numeric(quantile(y_cont, 0.25, na.rm = TRUE))
    y_bin <- ifelse(y_cont > thr, 1L, 0L)
  }
  
  list(y_bin = y_bin, threshold_used = thr)
}

compute_predictor_medians <- function(df, predictors) {
  meds <- sapply(df[predictors], function(x) median(x[is.finite(x)], na.rm = TRUE))
  as.list(meds)
}

impute_df_predictors <- function(df, predictors, predictor_medians) {
  for (p in predictors) {
    miss <- !is.finite(df[[p]])
    if (any(miss)) {
      df[[p]][miss] <- predictor_medians[[p]]
    }
  }
  df
}

impute_raster_predictors <- function(r, predictors, predictor_medians) {
  out <- r[[predictors]]
  for (p in predictors) {
    out[[p]] <- ifel(is.na(out[[p]]), predictor_medians[[p]], out[[p]])
  }
  out
}

count_threshold_pixels <- function(r, thr) {
  as.numeric(global(r > thr, "sum", na.rm = TRUE)[1,1])
}

# FITTERS

fit_gbm_continuous <- function(df, response_col, predictors, predictor_medians, seed = 123) {
  df <- df %>% filter(is.finite(.data[[response_col]]))
  if (nrow(df) < min_rows) {
    return(list(model = NULL, predictors = predictors, n = nrow(df), predictor_medians = predictor_medians))
  }
  
  df <- impute_df_predictors(df, predictors, predictor_medians)
  df$y_scaled <- rescale01(df[[response_col]])
  
  if (nrow(df) > max_n) {
    set.seed(seed)
    df <- df[sample(seq_len(nrow(df)), max_n), , drop = FALSE]
  }
  
  form <- as.formula(paste("y_scaled ~", paste(predictors, collapse = " + ")))
  
  mod <- tryCatch(
    gbm::gbm(
      formula = form,
      data = df,
      distribution = "gaussian",
      n.trees = n_trees,
      interaction.depth = interaction_d,
      shrinkage = shrinkage,
      bag.fraction = bag_fraction,
      train.fraction = train_fraction,
      cv.folds = cv_folds,
      n.minobsinnode = 10,
      keep.data = FALSE,
      verbose = FALSE
    ),
    error = function(e) NULL
  )
  
  if (is.null(mod)) {
    return(list(model = NULL, predictors = predictors, n = nrow(df), predictor_medians = predictor_medians))
  }
  
  best_iter <- tryCatch(
    gbm::gbm.perf(mod, method = "cv", plot.it = FALSE),
    error = function(e) NA_integer_
  )
  
  if (!is.finite(best_iter)) best_iter <- n_trees
  
  list(
    model = mod,
    predictors = predictors,
    n = nrow(df),
    predictor_medians = predictor_medians,
    best_iter = best_iter
  )
}

fit_gbm_binomial <- function(df, response_col, predictors, predictor_medians, seed = 123) {
  df <- df %>% filter(is.finite(.data[[response_col]]))
  if (nrow(df) < min_rows) {
    return(list(model = NULL, predictors = predictors, n = nrow(df), threshold_used = NA_real_, predictor_medians = predictor_medians))
  }
  
  df <- impute_df_predictors(df, predictors, predictor_medians)
  resp <- make_binary_response(df[[response_col]])
  df$y_bin <- resp$y_bin
  
  if (length(unique(df$y_bin)) < 2) {
    return(list(model = NULL, predictors = predictors, n = nrow(df), threshold_used = resp$threshold_used, predictor_medians = predictor_medians))
  }
  
  if (nrow(df) > max_n) {
    set.seed(seed)
    idx0 <- which(df$y_bin == 0)
    idx1 <- which(df$y_bin == 1)
    n_each <- floor(max_n / 2)
    keep <- c(
      sample(idx0, min(length(idx0), n_each)),
      sample(idx1, min(length(idx1), n_each))
    )
    df <- df[keep, , drop = FALSE]
  }
  
  form <- as.formula(paste("y_bin ~", paste(predictors, collapse = " + ")))
  
  mod <- tryCatch(
    gbm::gbm(
      formula = form,
      data = df,
      distribution = "bernoulli",
      n.trees = n_trees,
      interaction.depth = interaction_d,
      shrinkage = shrinkage,
      bag.fraction = bag_fraction,
      train.fraction = train_fraction,
      cv.folds = cv_folds,
      n.minobsinnode = 10,
      keep.data = FALSE,
      verbose = FALSE
    ),
    error = function(e) NULL
  )
  
  if (is.null(mod)) {
    return(list(model = NULL, predictors = predictors, n = nrow(df), threshold_used = resp$threshold_used, predictor_medians = predictor_medians))
  }
  
  best_iter <- tryCatch(
    gbm::gbm.perf(mod, method = "cv", plot.it = FALSE),
    error = function(e) NA_integer_
  )
  
  if (!is.finite(best_iter)) best_iter <- n_trees
  
  list(
    model = mod,
    predictors = predictors,
    n = nrow(df),
    threshold_used = resp$threshold_used,
    predictor_medians = predictor_medians,
    best_iter = best_iter
  )
}

fit_gbm_gain <- function(df, predictors, predictor_medians, seed = 123) {
  df <- df %>% filter(is.finite(gain_cont))
  if (nrow(df) < min_rows) {
    return(list(model = NULL, predictors = predictors, n = nrow(df), predictor_medians = predictor_medians))
  }
  
  df <- impute_df_predictors(df, predictors, predictor_medians)
  df$gain_scaled <- rescale01(df$gain_cont)
  
  if (nrow(df) > max_n) {
    set.seed(seed)
    df <- df[sample(seq_len(nrow(df)), max_n), , drop = FALSE]
  }
  
  form <- as.formula(paste("gain_scaled ~", paste(predictors, collapse = " + ")))
  
  mod <- tryCatch(
    gbm::gbm(
      formula = form,
      data = df,
      distribution = "gaussian",
      n.trees = n_trees,
      interaction.depth = interaction_d,
      shrinkage = shrinkage,
      bag.fraction = bag_fraction,
      train.fraction = train_fraction,
      cv.folds = cv_folds,
      n.minobsinnode = 10,
      keep.data = FALSE,
      verbose = FALSE
    ),
    error = function(e) NULL
  )
  
  if (is.null(mod)) {
    return(list(model = NULL, predictors = predictors, n = nrow(df), predictor_medians = predictor_medians))
  }
  
  best_iter <- tryCatch(
    gbm::gbm.perf(mod, method = "cv", plot.it = FALSE),
    error = function(e) NA_integer_
  )
  
  if (!is.finite(best_iter)) best_iter <- n_trees
  
  list(
    model = mod,
    predictors = predictors,
    n = nrow(df),
    predictor_medians = predictor_medians,
    best_iter = best_iter
  )
}

# PREDICTION HELPERS

predict_gbm_raster <- function(pred_stack, model_obj) {
  out <- terra::predict(
    pred_stack,
    model_obj$model,
    fun = function(model, data) {
      as.numeric(stats::predict(
        model,
        newdata = as.data.frame(data),
        n.trees = model_obj$best_iter,
        type = "response"
      ))
    }
  )
  clamp(out, lower = 0, upper = 1, values = TRUE)
}

# MAIN LOOP

for (country in countries) {
  
  r <- load_country_stack(country)
  df <- as.data.frame(r, xy = TRUE, na.rm = FALSE)
  nms <- names(df)
  crop_list <- get_crop_list(country)
  
  predictors_present <- intersect(predictor_set, nms)
  predictor_medians <- compute_predictor_medians(df, predictors_present)
  
  country_dir <- file.path(out_dir, country)
  dir.create(country_dir, recursive = TRUE, showWarnings = FALSE)
  
  yield_audit <- list()
  diagnostics <- list()
  baseline_summary <- list()
  
  for (crop in crop_list) {
    rf_col  <- detect_yield_column(nms, crop, "rf")
    irr_col <- detect_yield_column(nms, crop, "irr")
    
    yield_audit[[length(yield_audit) + 1]] <- tibble(
      country = country,
      crop = crop,
      rf_col = rf_col,
      irr_col = irr_col
    )
    
    for (regime in c("rf", "irr")) {
      y_col <- if (regime == "rf") rf_col else irr_col
      df_reg <- make_regime_df(df, y_col)
      
      if (is.null(df_reg)) {
        diagnostics[[length(diagnostics) + 1]] <- tibble(
          country = country,
          crop = crop,
          regime = regime,
          model_type = "continuous_brt",
          status = "missing_yield_column",
          n = 0,
          threshold_used = NA_real_,
          predictors_used = NA_character_
        )
        next
      }
      
      # continuous BRT for both countries
      fit_cont <- fit_gbm_continuous(df_reg, "y_cont", predictors_present, predictor_medians)
      
      diagnostics[[length(diagnostics) + 1]] <- tibble(
        country = country,
        crop = crop,
        regime = regime,
        model_type = "continuous_brt",
        status = ifelse(is.null(fit_cont$model), "failed_or_insufficient", "ok"),
        n = fit_cont$n,
        threshold_used = NA_real_,
        predictors_used = paste(fit_cont$predictors, collapse = "; ")
      )
      
      if (!is.null(fit_cont$model)) {
        obj <- list(
          model = fit_cont$model,
          predictors = fit_cont$predictors,
          predictor_medians = fit_cont$predictor_medians,
          best_iter = fit_cont$best_iter,
          model_type = "continuous_brt",
          yield_column = y_col,
          country = country,
          crop = crop,
          regime = regime
        )
        
        saveRDS(obj, file.path(country_dir, paste0(country, "_", crop, "_", regime, "_continuous_brt_model.rds")))
        
        pred_stack <- impute_raster_predictors(r, fit_cont$predictors, fit_cont$predictor_medians)
        pred_base <- predict_gbm_raster(pred_stack, obj)
        
        heat_plausible <- r[["bio5"]] < heat_cutoff_c
        pred_feasible <- pred_base * heat_plausible
        
        prefix <- paste0(country, "_", crop, "_", regime, "_continuous_brt_baseline")
        writeRaster(pred_base, file.path(country_dir, paste0(prefix, "_P.tif")), overwrite = TRUE)
        writeRaster(pred_feasible, file.path(country_dir, paste0(prefix, "_P_feasible35.tif")), overwrite = TRUE)
        writeRaster(heat_plausible, file.path(country_dir, paste0(prefix, "_heat_plausible.tif")), overwrite = TRUE)
        
        baseline_summary[[length(baseline_summary) + 1]] <- tibble(
          country = country,
          crop = crop,
          regime = regime,
          model_type = "continuous_brt_baseline",
          mean_P = as.numeric(global(pred_base, "mean", na.rm = TRUE)[1,1]),
          mean_P_feasible35 = as.numeric(global(pred_feasible, "mean", na.rm = TRUE)[1,1]),
          viable_pixels = count_threshold_pixels(pred_base, viability_thr),
          highyield_pixels = count_threshold_pixels(pred_base, highyield_thr)
        )
      }
      
      # binomial BRT for Spain only
      if (country == "Spain") {
        fit_bin <- fit_gbm_binomial(df_reg, "y_cont", predictors_present, predictor_medians)
        
        diagnostics[[length(diagnostics) + 1]] <- tibble(
          country = country,
          crop = crop,
          regime = regime,
          model_type = "binomial_brt",
          status = ifelse(is.null(fit_bin$model), "failed_or_insufficient", "ok"),
          n = fit_bin$n,
          threshold_used = fit_bin$threshold_used,
          predictors_used = paste(fit_bin$predictors, collapse = "; ")
        )
        
        if (!is.null(fit_bin$model)) {
          obj <- list(
            model = fit_bin$model,
            predictors = fit_bin$predictors,
            predictor_medians = fit_bin$predictor_medians,
            best_iter = fit_bin$best_iter,
            model_type = "binomial_brt",
            yield_column = y_col,
            threshold_used = fit_bin$threshold_used,
            country = country,
            crop = crop,
            regime = regime
          )
          
          saveRDS(obj, file.path(country_dir, paste0(country, "_", crop, "_", regime, "_binomial_brt_model.rds")))
          
          pred_stack <- impute_raster_predictors(r, fit_bin$predictors, fit_bin$predictor_medians)
          pred_base <- predict_gbm_raster(pred_stack, obj)
          
          heat_plausible <- r[["bio5"]] < heat_cutoff_c
          pred_feasible <- pred_base * heat_plausible
          
          prefix <- paste0(country, "_", crop, "_", regime, "_binomial_brt_baseline")
          writeRaster(pred_base, file.path(country_dir, paste0(prefix, "_P.tif")), overwrite = TRUE)
          writeRaster(pred_feasible, file.path(country_dir, paste0(prefix, "_P_feasible35.tif")), overwrite = TRUE)
          writeRaster(heat_plausible, file.path(country_dir, paste0(prefix, "_heat_plausible.tif")), overwrite = TRUE)
          
          baseline_summary[[length(baseline_summary) + 1]] <- tibble(
            country = country,
            crop = crop,
            regime = regime,
            model_type = "binomial_brt_baseline",
            mean_P = as.numeric(global(pred_base, "mean", na.rm = TRUE)[1,1]),
            mean_P_feasible35 = as.numeric(global(pred_feasible, "mean", na.rm = TRUE)[1,1]),
            viable_pixels = count_threshold_pixels(pred_base, viability_thr),
            highyield_pixels = count_threshold_pixels(pred_base, highyield_thr)
          )
        }
      }
    }
    
    # irrigation gain
    df_gain <- make_gain_df(df, rf_col, irr_col)
    
    if (!is.null(df_gain)) {
      fit_gain <- fit_gbm_gain(df_gain, predictors_present, predictor_medians)
      
      diagnostics[[length(diagnostics) + 1]] <- tibble(
        country = country,
        crop = crop,
        regime = "gain",
        model_type = "gain_continuous_brt",
        status = ifelse(is.null(fit_gain$model), "failed_or_insufficient", "ok"),
        n = fit_gain$n,
        threshold_used = NA_real_,
        predictors_used = paste(fit_gain$predictors, collapse = "; ")
      )
      
      if (!is.null(fit_gain$model)) {
        obj <- list(
          model = fit_gain$model,
          predictors = fit_gain$predictors,
          predictor_medians = fit_gain$predictor_medians,
          best_iter = fit_gain$best_iter,
          model_type = "gain_continuous_brt",
          rf_col = rf_col,
          irr_col = irr_col,
          country = country,
          crop = crop,
          regime = "gain"
        )
        
        saveRDS(obj, file.path(country_dir, paste0(country, "_", crop, "_gain_continuous_brt_model.rds")))
        
        pred_stack <- impute_raster_predictors(r, fit_gain$predictors, fit_gain$predictor_medians)
        pred_gain <- predict_gbm_raster(pred_stack, obj)
        
        writeRaster(pred_gain, file.path(country_dir, paste0(country, "_", crop, "_gain_continuous_brt_baseline.tif")), overwrite = TRUE)
        
        baseline_summary[[length(baseline_summary) + 1]] <- tibble(
          country = country,
          crop = crop,
          regime = "gain",
          model_type = "gain_continuous_brt_baseline",
          mean_P = as.numeric(global(pred_gain, "mean", na.rm = TRUE)[1,1]),
          mean_P_feasible35 = NA_real_,
          viable_pixels = NA_real_,
          highyield_pixels = NA_real_
        )
      }
    }
  }
  
  write_csv(bind_rows(yield_audit), file.path(country_dir, paste0(country, "_yield_layer_audit.csv")))
  write_csv(bind_rows(diagnostics), file.path(country_dir, paste0(country, "_model_diagnostics.csv")))
  write_csv(bind_rows(baseline_summary), file.path(country_dir, paste0(country, "_baseline_summary.csv")))
}

