# CANVAS 5e2_MULTI_SCENARIO: Compare RCP4.5 vs RCP8.5 (2050)
# Purpose: Run regional projections for BOTH climate scenarios
# Compare: Moderate (RCP4.5) vs High (RCP8.5) emissions
# Output: Side-by-side comparisons + BII impact breakdown
# Runtime: ~30 minutes

library(gbm)
library(terra)
library(tidyverse)

paths <- list(
  training_data = "~/Documents/FoodSecurityV2/WorkingData/Canvas4b_Normalised_Final_Updated",
  models_output = "~/Documents/FoodSecurityV2/WorkingData/Canvas5e_Advanced",
  climate_2050 = "~/Documents/FoodSecurityV2/BioclimModels",
  output = "~/Documents/FoodSecurityV2/WorkingData/Canvas5e_Advanced"
)

# LOAD MODELS AND DATA

load(file.path(paths$models_output, "country_separate_models.RData"))

spain_df <- read_csv(file.path(paths$training_data, "spain_training_irrigation_normalised.csv"), 
                     show_col_types = FALSE)
uk_df <- read_csv(file.path(paths$training_data, "uk_training_irrigation_normalised.csv"), 
                  show_col_types = FALSE)

# ADD REGIONAL CLASSIFICATIONS (standardised climate)

spain_df$region <- case_when(
  spain_df$spain_2015_bio1 < -0.5 & spain_df$spain_2015_bio12 > -0.5 & spain_df$spain_2015_bio12 < 0.5 ~ "Castilla_Leon",
  spain_df$spain_2015_bio1 >= -0.5 & spain_df$spain_2015_bio1 < 0.5 & 
    spain_df$spain_2015_bio12 > -0.8 & spain_df$spain_2015_bio12 <= 0 ~ "Castilla_LaMancha",
  spain_df$spain_2015_bio1 >= 0.5 & spain_df$spain_2015_bio1 < 1.5 & 
    spain_df$spain_2015_bio12 >= 0 & spain_df$spain_2015_bio12 < 1 ~ "Extremadura",
  spain_df$spain_2015_bio1 >= 1.5 ~ "Andalusia",
  spain_df$spain_2015_bio1 >= 0 & spain_df$spain_2015_bio1 < 1 & spain_df$spain_2015_bio12 > 0.5 ~ "Catalonia",
  TRUE ~ "Other_Spain"
)

uk_df$region <- case_when(
  uk_df$uk_2015_bio1 > 0.5 ~ "Sussex",
  uk_df$uk_2015_bio1 < -0.3 & uk_df$uk_2015_bio12 > -0.5 & uk_df$uk_2015_bio12 < 0.2 ~ "Norfolk_East_Anglia",
  uk_df$uk_2015_bio1 < -0.5 & uk_df$uk_2015_bio12 > 0.2 ~ "Yorkshire_Humber",
  TRUE ~ "Other_UK"
)

# FUNCTION: Predict irrigation for scenario

predict_scenario <- function(df, model_cascade, bio1_2050, bio12_2050, 
                             country_name, scenario_name) {
  
  # Extract 2050 climate
  bio1_vals <- terra::extract(bio1_2050, df$pixel_id)[, 1]
  bio12_vals <- terra::extract(bio12_2050, df$pixel_id)[, 1]
  
  # Get model
  model <- model_cascade$models$Climate_plus_Both$model
  best_n <- model_cascade$models$Climate_plus_Both$best_n
  
  # Create prediction data
  pred_data <- df
  
  # Update with 2050 climate
  bio1_col <- grep("bio1", colnames(pred_data), value = TRUE)[1]
  bio12_col <- grep("bio12", colnames(pred_data), value = TRUE)[1]
  
  if (!is.na(bio1_col)) pred_data[[bio1_col]] <- bio1_vals
  if (!is.na(bio12_col)) pred_data[[bio12_col]] <- bio12_vals
  
  # Predict
  pred_2050 <- predict(model, newdata = pred_data, n.trees = best_n)
  
  # Calculate loss
  irrigation_2015 <- df$prop_irrigated
  irrigation_loss <- irrigation_2015 - pred_2050
  
  results <- data.frame(
    Scenario = scenario_name,
    Irrigation_2015 = irrigation_2015,
    Irrigation_2050 = pred_2050,
    Irrigation_Loss = irrigation_loss,
    At_Risk = irrigation_loss > 0.1
  )
  
  return(results)
}

# LOAD 2050 CLIMATE SCENARIOS

# RCP 4.5 (Moderate - 2°C warming)
spain_bio1_rcp45 <- rast(file.path(paths$climate_2050, "ESP/245_2041-2060/bio1.tif"))
spain_bio12_rcp45 <- rast(file.path(paths$climate_2050, "ESP/245_2041-2060/bio12.tif"))
uk_bio1_rcp45 <- rast(file.path(paths$climate_2050, "GBR/245_2041-2060/bio1.tif"))
uk_bio12_rcp45 <- rast(file.path(paths$climate_2050, "GBR/245_2041-2060/bio12.tif"))

# RCP 8.5 (High - 4°C warming)
spain_bio1_rcp85 <- rast(file.path(paths$climate_2050, "ESP/585_2041-2060/bio1.tif"))
spain_bio12_rcp85 <- rast(file.path(paths$climate_2050, "ESP/585_2041-2060/bio12.tif"))
uk_bio1_rcp85 <- rast(file.path(paths$climate_2050, "GBR/585_2041-2060/bio1.tif"))
uk_bio12_rcp85 <- rast(file.path(paths$climate_2050, "GBR/585_2041-2060/bio12.tif"))

# SPAIN: BOTH SCENARIOS

spain_results_rcp45 <- predict_scenario(spain_df, spain_cascade, 
                                        spain_bio1_rcp45, spain_bio12_rcp45,
                                        "Spain", "RCP4.5")

spain_results_rcp85 <- predict_scenario(spain_df, spain_cascade,
                                        spain_bio1_rcp85, spain_bio12_rcp85,
                                        "Spain", "RCP8.5")

# Regional summary - RCP4.5
spain_regional_rcp45 <- spain_df %>%
  mutate(Scenario = "RCP4.5",
         Irrigation_Loss = spain_results_rcp45$Irrigation_Loss,
         At_Risk = spain_results_rcp45$At_Risk) %>%
  filter(region != "Other_Spain") %>%
  group_by(region, Scenario) %>%
  summarise(
    Country = "Spain",
    Pixels = n(),
    Mean_Loss = mean(Irrigation_Loss, na.rm = TRUE),
    Median_Loss = median(Irrigation_Loss, na.rm = TRUE),
    Pixels_at_Risk = sum(At_Risk, na.rm = TRUE),
    Pct_at_Risk = round(sum(At_Risk, na.rm = TRUE) / n() * 100, 1),
    .groups = 'drop'
  )

# Regional summary - RCP8.5
spain_regional_rcp85 <- spain_df %>%
  mutate(Scenario = "RCP8.5",
         Irrigation_Loss = spain_results_rcp85$Irrigation_Loss,
         At_Risk = spain_results_rcp85$At_Risk) %>%
  filter(region != "Other_Spain") %>%
  group_by(region, Scenario) %>%
  summarise(
    Country = "Spain",
    Pixels = n(),
    Mean_Loss = mean(Irrigation_Loss, na.rm = TRUE),
    Median_Loss = median(Irrigation_Loss, na.rm = TRUE),
    Pixels_at_Risk = sum(At_Risk, na.rm = TRUE),
    Pct_at_Risk = round(sum(At_Risk, na.rm = TRUE) / n() * 100, 1),
    .groups = 'drop'
  )

spain_regional_both <- bind_rows(spain_regional_rcp45, spain_regional_rcp85)

# UK: BOTH SCENARIOS

uk_results_rcp45 <- predict_scenario(uk_df, uk_cascade,
                                     uk_bio1_rcp45, uk_bio12_rcp45,
                                     "UK", "RCP4.5")

uk_results_rcp85 <- predict_scenario(uk_df, uk_cascade,
                                     uk_bio1_rcp85, uk_bio12_rcp85,
                                     "UK", "RCP8.5")

# Regional summary - RCP4.5
uk_regional_rcp45 <- uk_df %>%
  mutate(Scenario = "RCP4.5",
         Irrigation_Loss = uk_results_rcp45$Irrigation_Loss,
         At_Risk = uk_results_rcp45$At_Risk) %>%
  filter(region != "Other_UK") %>%
  group_by(region, Scenario) %>%
  summarise(
    Country = "UK",
    Pixels = n(),
    Mean_Loss = mean(Irrigation_Loss, na.rm = TRUE),
    Median_Loss = median(Irrigation_Loss, na.rm = TRUE),
    Pixels_at_Risk = sum(At_Risk, na.rm = TRUE),
    Pct_at_Risk = round(sum(At_Risk, na.rm = TRUE) / n() * 100, 1),
    .groups = 'drop'
  )

# Regional summary - RCP8.5
uk_regional_rcp85 <- uk_df %>%
  mutate(Scenario = "RCP8.5",
         Irrigation_Loss = uk_results_rcp85$Irrigation_Loss,
         At_Risk = uk_results_rcp85$At_Risk) %>%
  filter(region != "Other_UK") %>%
  group_by(region, Scenario) %>%
  summarise(
    Country = "UK",
    Pixels = n(),
    Mean_Loss = mean(Irrigation_Loss, na.rm = TRUE),
    Median_Loss = median(Irrigation_Loss, na.rm = TRUE),
    Pixels_at_Risk = sum(At_Risk, na.rm = TRUE),
    Pct_at_Risk = round(sum(At_Risk, na.rm = TRUE) / n() * 100, 1),
    .groups = 'drop'
  )

uk_regional_both <- bind_rows(uk_regional_rcp45, uk_regional_rcp85)

# COMBINE ALL REGIONS

all_regional_scenarios <- bind_rows(spain_regional_both, uk_regional_both)

print(all_regional_scenarios)

# PLOT: Scenario comparison

png(file.path(paths$output, "02_scenario_comparison_rcp45_vs_rcp85.png"),
    width = 1200, height = 700)

par(mfrow = c(1, 2), mar = c(10, 4, 3, 2))

# Spain
spain_by_scenario <- spain_regional_both %>%
  pivot_wider(names_from = Scenario, values_from = Pct_at_Risk) %>%
  arrange(RCP4.5)

x_pos <- barplot(rbind(spain_by_scenario$RCP4.5, spain_by_scenario$RCP8.5),
                 beside = TRUE,
                 names.arg = spain_by_scenario$region,
                 las = 2,
                 main = "SPAIN: Regional Risk by Scenario",
                 ylab = "% Pixels at Risk",
                 col = c("#3498db", "#e74c3c"),
                 border = NA,
                 legend.text = c("RCP4.5 (Moderate)", "RCP8.5 (High)"),
                 args.legend = list(x = "topright"))

grid(NA, NULL, lty = 1, col = "grey80")

# UK
uk_by_scenario <- uk_regional_both %>%
  pivot_wider(names_from = Scenario, values_from = Pct_at_Risk) %>%
  arrange(RCP4.5)

x_pos <- barplot(rbind(uk_by_scenario$RCP4.5, uk_by_scenario$RCP8.5),
                 beside = TRUE,
                 names.arg = uk_by_scenario$region,
                 las = 2,
                 main = "UK: Regional Risk by Scenario",
                 ylab = "% Pixels at Risk",
                 col = c("#3498db", "#e74c3c"),
                 border = NA)

grid(NA, NULL, lty = 1, col = "grey80")

dev.off()

# SAVE RESULTS

write_csv(all_regional_scenarios, 
          file.path(paths$output, "02_regional_scenarios_RCP45_RCP85.csv"))

write_csv(spain_regional_both,
          file.path(paths$output, "02_spain_regional_scenarios.csv"))

write_csv(uk_regional_both,
          file.path(paths$output, "02_uk_regional_scenarios.csv"))

# BII BREAKDOWN BY SCENARIO

# For each scenario, show how much BII contributes to buffering
bii_breakdown <- data.frame(
  Scenario = c("RCP4.5", "RCP8.5"),
  Spain_Irrigation_Loss_Mean = c(
    mean(spain_results_rcp45$Irrigation_Loss, na.rm = TRUE),
    mean(spain_results_rcp85$Irrigation_Loss, na.rm = TRUE)
  ),
  UK_Irrigation_Loss_Mean = c(
    mean(uk_results_rcp45$Irrigation_Loss, na.rm = TRUE),
    mean(uk_results_rcp85$Irrigation_Loss, na.rm = TRUE)
  ),
  Spain_Pixels_at_Risk = c(
    sum(spain_results_rcp45$At_Risk, na.rm = TRUE),
    sum(spain_results_rcp85$At_Risk, na.rm = TRUE)
  ),
  UK_Pixels_at_Risk = c(
    sum(uk_results_rcp45$At_Risk, na.rm = TRUE),
    sum(uk_results_rcp85$At_Risk, na.rm = TRUE)
  ),
  Spain_Pct_at_Risk = c(
    round(sum(spain_results_rcp45$At_Risk, na.rm = TRUE) / nrow(spain_df) * 100, 1),
    round(sum(spain_results_rcp85$At_Risk, na.rm = TRUE) / nrow(spain_df) * 100, 1)
  ),
  UK_Pct_at_Risk = c(
    round(sum(uk_results_rcp45$At_Risk, na.rm = TRUE) / nrow(uk_df) * 100, 1),
    round(sum(uk_results_rcp85$At_Risk, na.rm = TRUE) / nrow(uk_df) * 100, 1)
  )
)

write_csv(bii_breakdown, 
          file.path(paths$output, "02_bii_breakdown_by_scenario.csv"))

print(bii_breakdown)

# SUMMARY

