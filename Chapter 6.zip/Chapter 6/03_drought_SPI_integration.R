# CANVAS 3d FINAL: Drought Integration - SPI Data for Spain
# Mathematical basis: Mean SPI across 2000-2015 study period
# Standardisation: z-scores (mean=0, SD=1) for compatibility with other predictors

library(terra)
library(tidyverse)

paths <- list(
  drought_file = "~/Documents/FoodSecurityV2/Bioclimate/Spanish_Drought_Catalogue_v1.0.0-SPI_grids.nc",
  bii_spain = "~/Documents/FoodSecurityV2/Biodiversity/BII_Spatial/spain",
  training_data = "~/Documents/FoodSecurityV2/WorkingData/Canvas4_TrainingData_Final",
  output = "~/Documents/FoodSecurityV2/WorkingData/Canvas3d_DroughtIntegration_Final"
)

dir.create(paths$output, showWarnings = FALSE, recursive = TRUE)

# STEP 1: Load and validate drought catalogue

if (!file.exists(paths$drought_file)) {
  stop()
}

tryCatch({
  drought_rast <- rast(paths$drought_file)
}, error = function(e) {
  stop()
})

n_layers <- nlyr(drought_rast)
    ", ", ymin(drought_rast), "to", ymax(drought_rast), "\n\n")

# STEP 2: Extract 2000-2015 study period

# Assuming: spi01_1 = Jan 2000, spi01_2 = Feb 2000, etc.
# 2000-2015 = 16 years × 12 months = 192 months

study_months <- min(192, n_layers)

# Extract study period
spi_study <- drought_rast[[1:study_months]]

# Validate
spi_study_values <- values(spi_study, mat = FALSE)
n_valid <- sum(!is.na(spi_study_values))
    ncell(spi_study), "pixels)\n")
    "to", round(max(spi_study_values, na.rm = TRUE), 3), "\n\n")

# STEP 3: Calculate mean SPI (temporal average)

# Mathematical formula: SPI_mean_i = (1/n) * Σ SPI_{i,t}
spi_mean <- mean(spi_study, na.rm = TRUE)

spi_mean_values <- values(spi_mean, mat = FALSE)
n_cells_computed <- sum(!is.na(spi_mean_values))

    "to", round(max(spi_mean_values, na.rm = TRUE), 3), "\n")

# STEP 4: Classify drought severity

n_severe <- sum(spi_mean_values < -1.5, na.rm = TRUE)
n_moderate <- sum(spi_mean_values >= -1.5 & spi_mean_values < -1.0, na.rm = TRUE)
n_normal <- sum(spi_mean_values >= -1.0 & spi_mean_values <= 1.0, na.rm = TRUE)
n_wet <- sum(spi_mean_values > 1.0, na.rm = TRUE)
total_pixels <- n_severe + n_moderate + n_normal + n_wet

    "pixels (", round(n_severe/total_pixels*100, 1), "%)\n")
    "pixels (", round(n_moderate/total_pixels*100, 1), "%)\n")
    "pixels (", round(n_normal/total_pixels*100, 1), "%)\n")
    "pixels (", round(n_wet/total_pixels*100, 1), "%)\n\n")

# Save raw mean SPI
spi_mean_file <- file.path(paths$output, "spi_mean_2000_2015_spain.tif")
writeRaster(spi_mean, spi_mean_file, overwrite = TRUE)

# STEP 5: Align SPI to reference grid

ref <- rast(file.path(paths$bii_spain, "bii_spain_2015.tif"))

    ", y =", round(ymin(ref), 2), "to", round(ymax(ref), 2), "\n")

# Check if alignment needed
if (!identical(ext(spi_mean), ext(ref)) || !identical(res(spi_mean), res(ref))) {
  spi_aligned <- resample(spi_mean, ref, method = "bilinear")
} else {
  spi_aligned <- spi_mean
}

# STEP 6: Extract SPI for training pixels

spain_file <- file.path(paths$training_data, "spain_training_irrigation.csv")

if (!file.exists(spain_file)) {
  stop()
}

spain_df <- read_csv(spain_file, show_col_types = FALSE)

# Extract SPI for each pixel
# terra::extract() returns data.frame; get first column (SPI values)
spi_extracted <- terra::extract(spi_aligned, spain_df$pixel_id)
spi_values <- spi_extracted[, 1]

spain_df$spi_2000_2015 <- spi_values

n_spi_valid <- sum(!is.na(spain_df$spi_2000_2015))
pct_coverage <- n_spi_valid / nrow(spain_df) * 100

    "pixels (", round(pct_coverage, 1), "%)\n")

if (pct_coverage < 80) {
}

    round(min(spain_df$spi_2000_2015, na.rm = TRUE), 3), "to",
    round(max(spain_df$spi_2000_2015, na.rm = TRUE), 3), "\n\n")

# STEP 7: Standardise SPI (z-scores)

spi_vals <- spain_df$spi_2000_2015[!is.na(spain_df$spi_2000_2015)]

spi_mean_val <- mean(spi_vals)
spi_sd_val <- sd(spi_vals)

    ", SD =", round(spi_sd_val, 3), "\n")

# Formula: X_std = (X - μ) / σ
spain_df$spi_2000_2015_standardised <- 
  (spain_df$spi_2000_2015 - spi_mean_val) / spi_sd_val

    ", SD =", round(sd(spain_df$spi_2000_2015_standardised, na.rm = TRUE), 4), "\n\n")

# STEP 8: Add drought severity classification

spain_df$drought_severity <- cut(
  spain_df$spi_2000_2015,
  breaks = c(-Inf, -1.5, -1.0, 1.0, Inf),
  labels = c("Severe", "Moderate", "Normal", "Wet"),
  right = FALSE
)

drought_summary <- spain_df %>%
  group_by(drought_severity) %>%
  summarise(count = n(), .groups = 'drop') %>%
  mutate(percentage = round(count / nrow(spain_df) * 100, 1))

print(drought_summary)

# STEP 9: Save updated training data

spain_updated_file <- file.path(paths$output, "spain_training_with_drought.csv")
write_csv(spain_df, spain_updated_file)

# Save drought summary
summary_file <- file.path(paths$output, "drought_summary_statistics.csv")
write_csv(drought_summary, summary_file)

# STEP 10: Visualisation

png(file.path(paths$output, "spain_spi_2000_2015_map.png"),
    width = 1200, height = 800)

par(mar = c(4, 4, 3, 2))

plot(spi_aligned,
     main = "Spain: Mean SPI (2000-2015)\nStandardised Precipitation Index",
     xlab = "Longitude", ylab = "Latitude",
     col = colorRampPalette(c("darkred", "white", "darkblue"))(100),
     colNA = "grey90")

# Add colour bar annotation
legend("topright", 
       c("Severe drought", "Normal", "Wet"),
       col = c("darkred", "white", "darkblue"),
       pch = 15, cex = 1)

dev.off()

# SUMMARY & DIAGNOSTICS

    round(n_layers/12, 1), "years)\n")

    round(mean(spain_df$spi_2000_2015_standardised, na.rm = TRUE), 4), "\n")
    round(sd(spain_df$spi_2000_2015_standardised, na.rm = TRUE), 4), "\n\n")

if (pct_coverage >= 80) {
} else {
}

if (round(mean(spain_df$spi_2000_2015_standardised, na.rm = TRUE), 4) < 0.01) {
} else {
}

if (round(sd(spain_df$spi_2000_2015_standardised, na.rm = TRUE), 4) == 1.0) {
} else {
}

