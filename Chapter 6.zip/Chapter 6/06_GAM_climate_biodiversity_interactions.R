#!/usr/bin/env Rscript
# Script 09_FINAL: Complex SDM with Interactions - FIGURE PRODUCTION
# Purpose: GAM-based SDM with climate×biodiversity interactions
# Produces comprehensive publication-quality figures
# British spelling used throughout

library(terra)
library(tidyverse)
library(pROC)
library(sf)
library(rnaturalearth)
library(patchwork)
library(mgcv)
library(viridis)
library(scales)

base_dir <- "~/Documents/FoodSecurityV2"
setwd(base_dir)

# Configuration

output_dir <- file.path(base_dir, "SDM_Interactions")
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)
dir.create(file.path(output_dir, "maps"), showWarnings = FALSE)
dir.create(file.path(output_dir, "diagnostics"), showWarnings = FALSE)
dir.create(file.path(output_dir, "interactions"), showWarnings = FALSE)

# Boundaries
world <- ne_countries(scale = "medium", returnclass = "sf")
spain_boundary <- world %>% filter(admin == "Spain")
uk_boundary <- world %>% filter(admin == "United Kingdom")

# INTERACTION MODEL: 6 predictors with interactions
# Main effects: bio1, bio15, BII, PDSI
# Interactions: bio1:BII, PDSI:BII  (climate × biodiversity)
key_predictors <- c("bio1", "bio15", "BII", "PDSI", "aet", "bio12")

# Complex SDM function with full diagnostics

run_interaction_sdm <- function(country, crop) {
  
  # Load predictors
  pred_file <- file.path(base_dir, "AlignedPredictors", country,
                         paste0(country, "_predictors_baseline_2000_2015.tif"))
  
  if (!file.exists(pred_file)) return(NULL)
  
  predictors <- rast(pred_file)
  available_preds <- key_predictors[key_predictors %in% names(predictors)]
  
  if (length(available_preds) < 4) return(NULL)
  
  predictors <- predictors[[available_preds]]
  
  # Load harvested area
  harvest_dir <- file.path(base_dir, "HarvestedCropArea/HarvestedAreaTrimmed")
  harvest_file <- file.path(harvest_dir, paste0(country, "_", crop, "_harvested.tif"))
  
  if (!file.exists(harvest_file)) {
    return(NULL)
  }
  
  harvest <- rast(harvest_file)
  
  # Match geometries
  if (!compareGeom(predictors, harvest, stopOnError = FALSE)) {
    if (crs(predictors) != crs(harvest)) crs(harvest) <- crs(predictors)
    harvest <- resample(harvest, predictors, method = "bilinear")
  }
  
  # Define presence (top 30% of harvested areas)
  h_vals <- values(harvest, mat = FALSE)
  h_vals <- h_vals[!is.na(h_vals) & h_vals > 0]
  
  if (length(h_vals) < 100) return(NULL)
  
  threshold <- quantile(h_vals, 0.30, na.rm = TRUE)
  
  # Create binary presence layer
  presence_layer <- harvest
  values(presence_layer)[values(harvest) >= threshold] <- 1
  values(presence_layer)[values(harvest) < threshold | is.na(values(harvest))] <- 0
  
  # Stack and extract
  combined <- c(predictors, presence_layer)
  names(combined)[nlyr(combined)] <- "presence"
  
  all_data <- as.data.frame(combined, xy = TRUE, na.rm = TRUE)
  
  # Rename x,y to lon,lat to avoid conflicts with global environment
  names(all_data)[names(all_data) == "x"] <- "lon"
  names(all_data)[names(all_data) == "y"] <- "lat"
  
  # Separate presence and absence
  presence_data <- all_data[all_data$presence == 1, ]
  absence_data <- all_data[all_data$presence == 0, ]
  
  if (nrow(presence_data) < 50) return(NULL)
  
  # Balanced sampling
  n_sample <- min(2000, nrow(presence_data))
  
  if (nrow(presence_data) > n_sample) {
    presence_data <- presence_data[sample(nrow(presence_data), n_sample), ]
  }
  
  if (nrow(absence_data) > n_sample) {
    absence_data <- absence_data[sample(nrow(absence_data), n_sample), ]
  }
  
  # Combine
  train_data <- rbind(presence_data, absence_data)
  
  # Train/test split
  set.seed(42)
  train_idx <- sample(nrow(train_data), floor(0.7 * nrow(train_data)))
  train_set <- train_data[train_idx, ]
  test_set <- train_data[-train_idx, ]
  
  # Ensure lon,lat are numeric in both sets
  if (!"lon" %in% names(train_set) || !"lat" %in% names(train_set)) {
    return(NULL)
  }
  
  train_set$lon <- as.numeric(train_set$lon)
  train_set$lat <- as.numeric(train_set$lat)
  test_set$lon <- as.numeric(test_set$lon)
  test_set$lat <- as.numeric(test_set$lat)
  
  # Fit GAM with interactions
  tryCatch({
    
    # Check available predictors
    has_bio1 <- "bio1" %in% available_preds
    has_bio15 <- "bio15" %in% available_preds
    has_BII <- "BII" %in% available_preds
    has_PDSI <- "PDSI" %in% available_preds
    
    # Build formula
    formula_parts <- c()
    
    # Main smooth effects
    if (has_bio1) formula_parts <- c(formula_parts, "s(bio1, k=5)")
    if (has_bio15) formula_parts <- c(formula_parts, "s(bio15, k=4)")
    if (has_BII) formula_parts <- c(formula_parts, "s(BII, k=5)")
    if (has_PDSI) formula_parts <- c(formula_parts, "s(PDSI, k=4)")
    
    # Interactions (tensor product interactions)
    if (has_bio1 && has_BII) formula_parts <- c(formula_parts, "ti(bio1, BII, k=c(3,3))")
    if (has_PDSI && has_BII) formula_parts <- c(formula_parts, "ti(PDSI, BII, k=c(3,3))")
    
    # NOTE: Spatial smooth s(lon,lat) omitted due to R scoping issues
    # Focus is on climate×biodiversity interactions, which are captured above
    
    formula_str <- paste("presence ~", paste(formula_parts, collapse = " + "))
    
    # Standard GAM call (spatial smooth removed to avoid scoping issues)
    model <- gam(as.formula(formula_str),
                 data = train_set,
                 family = binomial(link = "logit"),
                 method = "REML")
    
    # Predict on full grid
    pred_raster <- predict(predictors, model, type = "response", na.rm = TRUE)
    
    # Performance metrics
    pred_test <- predict(model, newdata = test_set, type = "response")
    auc_test <- as.numeric(auc(roc(test_set$presence, pred_test, quiet = TRUE)))
    
    pred_train <- predict(model, newdata = train_set, type = "response")
    auc_train <- as.numeric(auc(roc(train_set$presence, pred_train, quiet = TRUE)))
    
    overfit <- auc_train - auc_test
    
    # Variable importance
    model_summary <- summary(model)
    
            " | Test AUC: ", round(auc_test, 3),
            " | Overfit: ", round(overfit, 3))
    
    return(list(
      prediction = pred_raster,
      model = model,
      model_summary = model_summary,
      auc_train = auc_train,
      auc_test = auc_test,
      overfit = overfit,
      crop = crop,
      country = country,
      n_presence = nrow(presence_data),
      n_absence = nrow(absence_data),
      train_set = train_set,
      test_set = test_set,
      predictors = predictors
    ))
    
  }, error = function(e) {
    if ("lon" %in% names(train_set)) message("    Class of lon: ", class(train_set$lon))
    if ("lat" %in% names(train_set)) message("    Class of lat: ", class(train_set$lat))
    return(NULL)
  })
}

# Visualisation functions

# 1. MAIN SUITABILITY MAP
plot_suitability_map <- function(result, boundary, output_dir) {
  
  df <- as.data.frame(result$prediction, xy = TRUE, na.rm = TRUE)
  names(df)[3] <- "suitability"
  
  country <- result$country
  crop <- result$crop
  
  p <- ggplot() +
    geom_tile(data = df, aes(x = x, y = y, fill = suitability)) +
    geom_sf(data = boundary, fill = NA, colour = "black", linewidth = 0.4) +
    scale_fill_gradientn(
      colours = c("#d73027", "#fc8d59", "#fee090", "#e0f3f8", "#91bfdb", "#4575b4"),
      name = "Suitability\nProbability",
      limits = c(0, 1),
      breaks = c(0, 0.25, 0.5, 0.75, 1)
    ) +
    coord_sf(xlim = if(country == "spain") c(-10, 5) else NULL,
             ylim = if(country == "spain") c(36, 44) else NULL,
             expand = FALSE) +
    labs(
      title = paste0("Habitat Suitability: ", tools::toTitleCase(crop)),
      subtitle = paste0(tools::toTitleCase(country), 
                       " | Test AUC: ", round(result$auc_test, 2),
                       " | Overfit: ", round(result$overfit, 3))
    ) +
    theme_minimal() +
    theme(
      panel.grid = element_blank(),
      axis.title = element_blank(),
      plot.title = element_text(size = 14, face = "bold"),
      plot.subtitle = element_text(size = 11),
      legend.position = "right"
    )
  
  filename <- file.path(output_dir, "maps", 
                       paste0(country, "_", crop, "_suitability.png"))
  
  ggsave(filename, p, width = 10, height = 8, dpi = 300)
  
  return(p)
}

# 2. PARTIAL EFFECTS PLOTS (marginal effects of each predictor)
plot_partial_effects <- function(result, output_dir) {
  
  model <- result$model
  country <- result$country
  crop <- result$crop
  
  # Extract smooth terms
  smooth_terms <- model$smooth
  
  plot_list <- list()
  
  for (i in seq_along(smooth_terms)) {
    term <- smooth_terms[[i]]
    
    # Skip spatial terms and interactions for now
    if (grepl("x,y", term$label) || grepl("ti\\(", term$label)) next
    
    tryCatch({
      # Extract variable name
      var_name <- gsub("s\\(|\\)", "", term$label)
      var_name <- strsplit(var_name, ",")[[1]][1]
      
      # Create prediction grid
      range_vals <- range(result$train_set[[var_name]], na.rm = TRUE)
      new_data <- data.frame(
        lon = mean(result$train_set$lon, na.rm = TRUE),
        lat = mean(result$train_set$lat, na.rm = TRUE)
      )
      new_data[[var_name]] <- seq(range_vals[1], range_vals[2], length.out = 100)
      
      # Add other predictors at their means
      for (pred in names(result$train_set)) {
        if (!pred %in% c("presence", "lon", "lat", var_name)) {
          new_data[[pred]] <- mean(result$train_set[[pred]], na.rm = TRUE)
        }
      }
      
      # Predict
      pred_vals <- predict(model, newdata = new_data, type = "response", se.fit = TRUE)
      
      plot_df <- data.frame(
        x = new_data[[var_name]],
        fit = pred_vals$fit,
        se = pred_vals$se.fit
      )
      
      p <- ggplot(plot_df, aes(x = x, y = fit)) +
        geom_ribbon(aes(ymin = fit - 1.96*se, ymax = fit + 1.96*se), 
                   alpha = 0.2, fill = "blue") +
        geom_line(colour = "blue", size = 1) +
        labs(
          title = tools::toTitleCase(var_name),
          x = var_name,
          y = "Suitability"
        ) +
        theme_minimal() +
        theme(
          plot.title = element_text(face = "bold", hjust = 0.5)
        )
      
      plot_list[[var_name]] <- p
      
    }, error = function(e) {
    })
  }
  
  if (length(plot_list) > 0) {
    combined <- wrap_plots(plot_list, ncol = 2) +
      plot_annotation(
        title = paste0("Partial Effects: ", tools::toTitleCase(crop), " (", tools::toTitleCase(country), ")"),
        theme = theme(plot.title = element_text(size = 14, face = "bold"))
      )
    
    filename <- file.path(output_dir, "diagnostics",
                         paste0(country, "_", crop, "_partial_effects.png"))
    
    ggsave(filename, combined, width = 10, height = 8, dpi = 300)
  }
  
  return(plot_list)
}

# 3. INTERACTION PLOTS (climate × biodiversity)
plot_interactions <- function(result, output_dir) {
  
  model <- result$model
  country <- result$country
  crop <- result$crop
  train_set <- result$train_set
  
  interaction_plots <- list()
  
  # bio1 × BII interaction
  if ("bio1" %in% names(train_set) && "BII" %in% names(train_set)) {
    
    tryCatch({
      # Create prediction grid
      bio1_vals <- seq(min(train_set$bio1, na.rm = TRUE),
                      max(train_set$bio1, na.rm = TRUE),
                      length.out = 50)
      BII_vals <- quantile(train_set$BII, c(0.25, 0.5, 0.75), na.rm = TRUE)
      
      pred_list <- list()
      
      for (bii_val in BII_vals) {
        new_data <- data.frame(
          bio1 = bio1_vals,
          BII = bii_val,
          lon = mean(train_set$lon, na.rm = TRUE),
          lat = mean(train_set$lat, na.rm = TRUE)
        )
        
        # Add other predictors at means
        for (pred in names(train_set)) {
          if (!pred %in% c("presence", "lon", "lat", "bio1", "BII")) {
            new_data[[pred]] <- mean(train_set[[pred]], na.rm = TRUE)
          }
        }
        
        pred_vals <- predict(model, newdata = new_data, type = "response")
        
        pred_list[[paste0("BII_", round(bii_val, 2))]] <- data.frame(
          bio1 = bio1_vals,
          suitability = pred_vals,
          BII_level = paste0("BII = ", round(bii_val, 2))
        )
      }
      
      plot_df <- bind_rows(pred_list)
      
      p1 <- ggplot(plot_df, aes(x = bio1, y = suitability, colour = BII_level)) +
        geom_line(size = 1.2) +
        scale_colour_manual(
          values = c("#d73027", "#fee090", "#4575b4"),
          name = "Biodiversity"
        ) +
        labs(
          title = "Temperature × Biodiversity Interaction",
          x = "Mean Annual Temperature (°C)",
          y = "Suitability Probability"
        ) +
        theme_minimal() +
        theme(
          plot.title = element_text(face = "bold"),
          legend.position = "right"
        )
      
      interaction_plots[["bio1_BII"]] <- p1
      
    }, error = function(e) {
    })
  }
  
  # PDSI × BII interaction
  if ("PDSI" %in% names(train_set) && "BII" %in% names(train_set)) {
    
    tryCatch({
      PDSI_vals <- seq(min(train_set$PDSI, na.rm = TRUE),
                      max(train_set$PDSI, na.rm = TRUE),
                      length.out = 50)
      BII_vals <- quantile(train_set$BII, c(0.25, 0.5, 0.75), na.rm = TRUE)
      
      pred_list <- list()
      
      for (bii_val in BII_vals) {
        new_data <- data.frame(
          PDSI = PDSI_vals,
          BII = bii_val,
          lon = mean(train_set$lon, na.rm = TRUE),
          lat = mean(train_set$lat, na.rm = TRUE)
        )
        
        for (pred in names(train_set)) {
          if (!pred %in% c("presence", "lon", "lat", "PDSI", "BII")) {
            new_data[[pred]] <- mean(train_set[[pred]], na.rm = TRUE)
          }
        }
        
        pred_vals <- predict(model, newdata = new_data, type = "response")
        
        pred_list[[paste0("BII_", round(bii_val, 2))]] <- data.frame(
          PDSI = PDSI_vals,
          suitability = pred_vals,
          BII_level = paste0("BII = ", round(bii_val, 2))
        )
      }
      
      plot_df <- bind_rows(pred_list)
      
      p2 <- ggplot(plot_df, aes(x = PDSI, y = suitability, colour = BII_level)) +
        geom_line(size = 1.2) +
        scale_colour_manual(
          values = c("#d73027", "#fee090", "#4575b4"),
          name = "Biodiversity"
        ) +
        labs(
          title = "Drought Stress × Biodiversity Interaction",
          x = "Palmer Drought Severity Index",
          y = "Suitability Probability"
        ) +
        theme_minimal() +
        theme(
          plot.title = element_text(face = "bold"),
          legend.position = "right"
        )
      
      interaction_plots[["PDSI_BII"]] <- p2
      
    }, error = function(e) {
    })
  }
  
  # Save combined interaction plot
  if (length(interaction_plots) > 0) {
    combined <- wrap_plots(interaction_plots, ncol = 1) +
      plot_annotation(
        title = paste0("Climate × Biodiversity Interactions: ", tools::toTitleCase(crop)),
        subtitle = tools::toTitleCase(country),
        theme = theme(plot.title = element_text(size = 14, face = "bold"))
      )
    
    filename <- file.path(output_dir, "interactions",
                         paste0(country, "_", crop, "_interactions.png"))
    
    ggsave(filename, combined, width = 10, height = 10, dpi = 300)
  }
  
  return(interaction_plots)
}

# 4. ROC CURVE
plot_roc_curve <- function(result, output_dir) {
  
  country <- result$country
  crop <- result$crop
  
  # Training ROC
  roc_train <- roc(result$train_set$presence, 
                   predict(result$model, newdata = result$train_set, type = "response"),
                   quiet = TRUE)
  
  # Test ROC
  roc_test <- roc(result$test_set$presence,
                  predict(result$model, newdata = result$test_set, type = "response"),
                  quiet = TRUE)
  
  # Combine for plotting
  plot_df <- rbind(
    data.frame(
      fpr = 1 - roc_train$specificities,
      tpr = roc_train$sensitivities,
      set = "Training"
    ),
    data.frame(
      fpr = 1 - roc_test$specificities,
      tpr = roc_test$sensitivities,
      set = "Testing"
    )
  )
  
  p <- ggplot(plot_df, aes(x = fpr, y = tpr, colour = set)) +
    geom_line(size = 1.2) +
    geom_abline(slope = 1, intercept = 0, linetype = "dashed", colour = "grey50") +
    scale_colour_manual(
      values = c("Training" = "#d73027", "Testing" = "#4575b4"),
      name = ""
    ) +
    annotate("text", x = 0.7, y = 0.3, 
             label = paste0("Train AUC: ", round(result$auc_train, 3)), 
             colour = "#d73027", size = 4) +
    annotate("text", x = 0.7, y = 0.2,
             label = paste0("Test AUC: ", round(result$auc_test, 3)),
             colour = "#4575b4", size = 4) +
    labs(
      title = paste0("ROC Curve: ", tools::toTitleCase(crop)),
      subtitle = tools::toTitleCase(country),
      x = "False Positive Rate",
      y = "True Positive Rate"
    ) +
    theme_minimal() +
    theme(
      plot.title = element_text(face = "bold"),
      legend.position = c(0.8, 0.2)
    )
  
  filename <- file.path(output_dir, "diagnostics",
                       paste0(country, "_", crop, "_roc_curve.png"))
  
  ggsave(filename, p, width = 8, height = 8, dpi = 300)
  
  return(p)
}

# 5. PRESENCE/ABSENCE DISTRIBUTION
plot_distributions <- function(result, output_dir) {
  
  country <- result$country
  crop <- result$crop
  train_set <- result$train_set
  
  # Key predictors to plot
  vars_to_plot <- intersect(c("bio1", "bio15", "BII", "PDSI"), names(train_set))
  
  plot_list <- list()
  
  for (var in vars_to_plot) {
    
    plot_df <- train_set %>%
      select(all_of(c(var, "presence"))) %>%
      mutate(presence = factor(presence, levels = c(0, 1), labels = c("Absence", "Presence")))
    
    names(plot_df)[1] <- "value"
    
    p <- ggplot(plot_df, aes(x = value, fill = presence)) +
      geom_density(alpha = 0.6) +
      scale_fill_manual(
        values = c("Absence" = "#d73027", "Presence" = "#4575b4"),
        name = ""
      ) +
      labs(
        title = tools::toTitleCase(var),
        x = var,
        y = "Density"
      ) +
      theme_minimal() +
      theme(
        plot.title = element_text(face = "bold", hjust = 0.5),
        legend.position = "top"
      )
    
    plot_list[[var]] <- p
  }
  
  if (length(plot_list) > 0) {
    combined <- wrap_plots(plot_list, ncol = 2) +
      plot_annotation(
        title = paste0("Predictor Distributions: ", tools::toTitleCase(crop)),
        subtitle = paste0(tools::toTitleCase(country), " | Red = Absence, Blue = Presence"),
        theme = theme(plot.title = element_text(size = 14, face = "bold"))
      )
    
    filename <- file.path(output_dir, "diagnostics",
                         paste0(country, "_", crop, "_distributions.png"))
    
    ggsave(filename, combined, width = 10, height = 8, dpi = 300)
  }
  
  return(plot_list)
}

# Run analyses

# Detect available crops
harvest_dir <- file.path(base_dir, "HarvestedCropArea/HarvestedAreaTrimmed")

spain_files <- list.files(harvest_dir, pattern = "^spain_.*_harvested\\.tif$")
spain_crops <- gsub("spain_|_harvested.tif", "", spain_files)

uk_files <- list.files(harvest_dir, pattern = "^uk_.*_harvested\\.tif$")
uk_crops <- gsub("uk_|_harvested.tif", "", uk_files)

# Run models and generate ALL figures
all_results <- list()
all_performance <- list()

# Spain
for (crop in spain_crops) {
  result <- run_interaction_sdm("spain", crop)
  
  if (!is.null(result)) {
    all_results[[paste0("spain_", crop)]] <- result
    
    # Generate all figures
    plot_suitability_map(result, spain_boundary, output_dir)
    plot_partial_effects(result, output_dir)
    plot_interactions(result, output_dir)
    plot_roc_curve(result, output_dir)
    plot_distributions(result, output_dir)
    
    # Save performance
    all_performance[[paste0("spain_", crop)]] <- data.frame(
      crop = crop,
      country = "spain",
      n_presence = result$n_presence,
      n_absence = result$n_absence,
      train_AUC = result$auc_train,
      test_AUC = result$auc_test,
      overfit = result$overfit
    )
  }
}

# UK
for (crop in uk_crops) {
  result <- run_interaction_sdm("uk", crop)
  
  if (!is.null(result)) {
    all_results[[paste0("uk_", crop)]] <- result
    
    # Generate all figures
    plot_suitability_map(result, uk_boundary, output_dir)
    plot_partial_effects(result, output_dir)
    plot_interactions(result, output_dir)
    plot_roc_curve(result, output_dir)
    plot_distributions(result, output_dir)
    
    # Save performance
    all_performance[[paste0("uk_", crop)]] <- data.frame(
      crop = crop,
      country = "uk",
      n_presence = result$n_presence,
      n_absence = result$n_absence,
      train_AUC = result$auc_train,
      test_AUC = result$auc_test,
      overfit = result$overfit
    )
  }
}

# Save summary statistics

perf_df <- bind_rows(all_performance)

if (nrow(perf_df) == 0) {
} else {
  write_csv(perf_df, file.path(output_dir, "interaction_sdm_performance.csv"))
  
  print(perf_df %>% arrange(desc(test_AUC)))
  
}
