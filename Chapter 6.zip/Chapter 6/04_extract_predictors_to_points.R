# Data cleaning: extract raster predictors to presence/absence points
# For all countries, extracts yield, harvest area, BII, VHI,
# and bioclim variables at each presence/absence point location.
# Output feeds into the BRT cascade models (chapter 5).
#
# Inputs:
#   BRT_inputs/ISO_pseudo_presence.gpkg and _pseudo_absence.gpkg
#   YieldTrimmed/ and HarvestedCropArea/ rasters
#   Biodiversity/BII_trim/ and VHI_trim/ rasters
#   BioclimModels/ISO/ rasters
#
# Outputs:
#   BRT_inputs/ISO_predictors.csv (one per country)

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(sf)
  library(terra)
})

root      <- "~/Documents/FoodSecurityV2"
pres_dir  <- file.path(root, "BRT_inputs")
out_dir   <- file.path(root, "BRT_inputs")
countries <- c("BRA", "KEN", "GBR", "MEX", "IDN", "ESP", "USA")

build_pa <- function(iso) {
  pres_gpkg <- file.path(pres_dir, paste0(iso, "_pseudo_presence.gpkg"))
  abs_gpkg  <- file.path(pres_dir, paste0(iso, "_pseudo_absence.gpkg"))
  if (!file.exists(pres_gpkg) || !file.exists(abs_gpkg)) return(NULL)

  pres <- st_read(pres_gpkg, quiet = TRUE) |>
    mutate(lon = st_coordinates(geometry)[, 1],
           lat = st_coordinates(geometry)[, 2],
           presence = 1) |>
    st_drop_geometry()

  abs <- st_read(abs_gpkg, quiet = TRUE) |>
    mutate(lon      = st_coordinates(geometry)[, 1],
           lat      = st_coordinates(geometry)[, 2],
           presence = 0,
           class    = "absence") |>
    st_drop_geometry()

  bind_rows(pres, abs) |> select(lon, lat, class, presence, everything())
}

extract_predictors <- function(iso, pa) {
  pts        <- vect(pa[, c("lon", "lat")], geom = c("lon", "lat"), crs = "EPSG:4326")
  predictors <- pa

  extract_layer <- function(f, prefix = "") {
    r <- tryCatch(rast(f), error = function(e) NULL)
    if (is.null(r)) return(NULL)
    val <- terra::extract(r, pts)[, 2]
    nm  <- paste0(prefix, tools::file_path_sans_ext(basename(f)))
    list(name = nm, values = val)
  }

  add_layers <- function(files, prefix = "") {
    for (f in files) {
      result <- extract_layer(f, prefix)
      if (!is.null(result)) predictors[[result$name]] <<- result$values
    }
  }

  add_layers(list.files(file.path(root, "YieldTrimmed"),
                        pattern = tolower(iso), recursive = TRUE, full.names = TRUE))

  add_layers(list.files(file.path(root, "HarvestedCropArea"),
                        pattern = tolower(iso), recursive = TRUE, full.names = TRUE),
             prefix = "harvest_")

  bii_f <- file.path(root, "Biodiversity", "BII_trim",
                     paste0(tolower(iso), "_bii_index.tif"))
  vhi_f <- file.path(root, "Biodiversity", "VHI_trim",
                     paste0(tolower(iso), "_vhi.tif"))
  add_layers(c(bii_f, vhi_f)[file.exists(c(bii_f, vhi_f))])

  clim_dir <- file.path(root, "BioclimModels", iso)
  if (dir.exists(clim_dir)) {
    clim_files <- list.files(clim_dir, pattern = "\.tif$",
                             recursive = TRUE, full.names = TRUE)
    clim_files <- clim_files[!grepl("climate_stack", clim_files)]
    add_layers(clim_files)
  }

  predictors
}

for (iso in countries) {
  pa <- build_pa(iso)
  if (is.null(pa)) { warning("Missing PA files for ", iso); next }
  predictors <- extract_predictors(iso, pa)
  write_csv(predictors, file.path(out_dir, paste0(iso, "_predictors.csv")))
}
