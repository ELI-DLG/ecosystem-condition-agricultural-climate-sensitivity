# CANVAS 5a_CROP_MECHANISM: Explaining Diversity Buffering
# KEY INSIGHT: Diversity buffers because it includes BOTH:
#   - Drought-tolerant crops (negative correlation with irrigation)
#   - Water-demanding crops (positive correlation with irrigation)
# This mix allows farmers to adapt to climate stress

library(tidyverse)

paths <- list(
  training_data = "~/Documents/FoodSecurityV2/WorkingData/Canvas5a_CropAnalysis_Debug",
  output = "~/Documents/FoodSecurityV2/WorkingData/Canvas5a_CropMechanism"
)

dir.create(paths$output, showWarnings = FALSE, recursive = TRUE)

# Load crop analysis results

crops <- read_csv(file.path(paths$training_data, "spain_crop_analysis.csv"), 
                  show_col_types = FALSE)

# CATEGORISE CROPS: Drought-tolerant vs Water-demanding

# Classification based on correlation with irrigation
# Negative correlation = grown rainfed = drought-tolerant
# Positive correlation = grown irrigated = water-demanding

crops$Irrigation_Demand <- case_when(
  crops$Correlation_with_Irrigation < -0.15 ~ "Drought-Tolerant (Rainfed)",
  crops$Correlation_with_Irrigation > 0.50 ~ "Water-Demanding (Irrigated)",
  crops$Correlation_with_Irrigation >= -0.15 & crops$Correlation_with_Irrigation <= 0.50 ~ "Moderate",
  TRUE ~ "Other"
)

# Extract crop name and irrigation type
crops <- crops %>%
  mutate(
    Crop_Name = gsub("spain_2015_|uk_2015_|_Irrigated|_Rainfed", "", Column),
    Irrigation_Type = ifelse(grepl("Irrigated", Column), "Irrigated", "Rainfed")
  )

# Group by crop name
crops_grouped <- crops %>%
  group_by(Crop_Name) %>%
  summarise(
    Rainfed_Prevalence = sum(Pixels_With_Data[Irrigation_Type == "Rainfed"], na.rm = TRUE),
    Irrigated_Prevalence = sum(Pixels_With_Data[Irrigation_Type == "Irrigated"], na.rm = TRUE),
    Total_Prevalence = Rainfed_Prevalence + Irrigated_Prevalence,
    Rainfed_Correlation = mean(Correlation_with_Irrigation[Irrigation_Type == "Rainfed"], na.rm = TRUE),
    Irrigated_Correlation = mean(Correlation_with_Irrigation[Irrigation_Type == "Irrigated"], na.rm = TRUE),
    .groups = 'drop'
  ) %>%
  arrange(desc(Total_Prevalence))

# IDENTIFY KEY INSIGHT: Crops grown both rainfed AND irrigated

# Crops that are grown BOTH rainfed AND irrigated = diversity mechanism
dual_purpose <- crops_grouped %>%
  filter(Rainfed_Prevalence > 100 & Irrigated_Prevalence > 100) %>%
  arrange(desc(Total_Prevalence))

# PLOT 1: Drought-Tolerant vs Water-Demanding Crops

# Prepare data
drought_tolerant <- crops %>%
  filter(grepl("Rainfed", Column) & Correlation_with_Irrigation < -0.15) %>%
  arrange(desc(Pixels_With_Data)) %>%
  head(8)

water_demanding <- crops %>%
  filter(grepl("Irrigated", Column) & Correlation_with_Irrigation > 0.50) %>%
  arrange(desc(Pixels_With_Data)) %>%
  head(8)

png(file.path(paths$output, "01_crop_categories.png"),
    width = 1200, height = 600)

par(mfrow = c(1, 2), mar = c(8, 4, 3, 2))

# Drought-tolerant
barplot(drought_tolerant$Pixels_With_Data,
        names.arg = gsub("spain_2015_|_Rainfed", "", drought_tolerant$Column),
        las = 2,
        main = "Drought-Tolerant Crops\n(Grown Rainfed, Correlation < -0.15)",
        ylab = "Pixels",
        col = "#27ae60",
        border = NA,
        cex.names = 0.8)
grid(NA, NULL, lty = 1, col = "grey80")

# Water-demanding
barplot(water_demanding$Pixels_With_Data,
        names.arg = gsub("spain_2015_|_Irrigated", "", water_demanding$Column),
        las = 2,
        main = "Water-Demanding Crops\n(Grown Irrigated, Correlation > 0.50)",
        ylab = "Pixels",
        col = "#e74c3c",
        border = NA,
        cex.names = 0.8)
grid(NA, NULL, lty = 1, col = "grey80")

dev.off()

# PLOT 2: Dual-Purpose Crops (The Diversity Mechanism!)

png(file.path(paths$output, "02_dual_purpose_crops.png"),
    width = 1000, height = 600)

par(mar = c(8, 4, 3, 2))

# Show rainfed vs irrigated for dual-purpose crops
dual_top <- head(dual_purpose, 8)

x_pos <- barplot(rbind(dual_top$Rainfed_Prevalence, dual_top$Irrigated_Prevalence),
                 beside = TRUE,
                 names.arg = dual_top$Crop_Name,
                 las = 2,
                 main = "Dual-Purpose Crops: Grown Both Rainfed AND Irrigated\n(This is the Diversity Mechanism!)",
                 ylab = "Number of Pixels",
                 col = c("#27ae60", "#e74c3c"),
                 border = NA,
                 legend.text = c("Rainfed (Drought-Tolerant)", "Irrigated (Water-Demanding)"),
                 args.legend = list(x = "topright"))

grid(NA, NULL, lty = 1, col = "grey80")

dev.off()

# PLOT 3: Crop Correlations with Irrigation

# Top crops by prevalence
top_crops <- head(crops, 15)

png(file.path(paths$output, "03_crop_irrigation_correlations.png"),
    width = 900, height = 600)

par(mar = c(8, 4, 3, 2))

# Colour by correlation: red (water-demanding) to green (drought-tolerant)
colors <- ifelse(top_crops$Correlation_with_Irrigation > 0, "#e74c3c", "#27ae60")

barplot(top_crops$Correlation_with_Irrigation,
        names.arg = gsub("spain_2015_|uk_2015_|_Irrigated|_Rainfed", "", top_crops$Column),
        las = 2,
        main = "Top 15 Crops: Correlation with Irrigation\nRed = Water-demanding | Green = Drought-tolerant",
        ylab = "Correlation Coefficient",
        col = colors,
        border = NA,
        cex.names = 0.8)
abline(h = 0, lty = 1, col = "black", lwd = 1)
grid(NA, NULL, lty = 1, col = "grey80")

dev.off()

# Export key tables

write_csv(crops_grouped, file.path(paths$output, "crops_grouped_by_type.csv"))

write_csv(dual_purpose, file.path(paths$output, "dual_purpose_crops_DIVERSITY_MECHANISM.csv"))

# SUMMARY: THE MECHANISM EXPLAINED

dt <- crops %>% filter(Correlation_with_Irrigation < -0.15)

wd <- crops %>% filter(Correlation_with_Irrigation > 0.50)

