# CANVAS 5a FINAL: Cascade BRT Models (M1 Optimised)
# Question: Which buffers climate stress better—BII or crop diversity?
# Method: Cascade from climate-only through to full model with interactions
# RAM: Optimised for M1 MacBook Pro

library(gbm)
library(tidyverse)

paths <- list(
  training_data = "~/Documents/FoodSecurityV2/WorkingData/Canvas4b_Normalised_Final",
  output = "~/Documents/FoodSecurityV2/WorkingData/Canvas5a_CascadeBRT_Final"
)

dir.create(paths$output, showWarnings = FALSE, recursive = TRUE)

# Load combined data

spain_df <- read_csv(file.path(paths$training_data, "spain_training_irrigation_normalised.csv"), 
                     show_col_types = FALSE)
uk_df <- read_csv(file.path(paths$training_data, "uk_training_irrigation_normalised.csv"), 
                  show_col_types = FALSE)

combined_df <- bind_rows(spain_df, uk_df)

# Prepare predictor sets

climate_cols <- grep("^.*_(bio|tc_)", colnames(combined_df), value = TRUE)
bii_cols <- grep("bii_", colnames(combined_df), value = TRUE)
diversity_cols <- grep("crop_diversity", colnames(combined_df), value = TRUE)

# Define cascade
predictor_sets <- list(
  "Climate_only" = climate_cols,
  "Climate_plus_BII" = c(climate_cols, bii_cols),
  "Climate_plus_Diversity" = c(climate_cols, diversity_cols),
  "Climate_plus_Both" = c(climate_cols, bii_cols, diversity_cols)
)

# Fit cascade models

results <- list()

for (model_name in names(predictor_sets)) {
  
  predictors <- predictor_sets[[model_name]]
  df <- combined_df[, c("prop_irrigated", predictors)]
  df <- na.omit(df)
  
  set.seed(42)
  
  formula_str <- paste("prop_irrigated ~", paste(predictors, collapse = "+"))
  
  model <- gbm(
    formula = as.formula(formula_str),
    data = df,
    distribution = "gaussian",
    n.trees = 2000,
    interaction.depth = 3,
    shrinkage = 0.01,
    bag.fraction = 0.7,
    train.fraction = 1.0,
    cv.folds = 5,
    verbose = FALSE
  )
  
  best_n <- gbm.perf(model, method = "cv", plot = FALSE)
  pred <- predict(model, n.trees = best_n)
  actual <- df$prop_irrigated
  
  r2 <- cor(pred, actual)^2
  rmse <- sqrt(mean((pred - actual)^2))
  
  results[[model_name]] <- list(
    model = model,
    best_n = best_n,
    r2 = r2,
    rmse = rmse,
    n_pixels = nrow(df)
  )
}

# Compare results

comparison_df <- data.frame(
  Model = names(results),
  Pixels = sapply(results, function(x) x$n_pixels),
  R_squared = round(sapply(results, function(x) x$r2), 4),
  RMSE = round(sapply(results, function(x) x$rmse), 4)
)

# Interpret

baseline_r2 <- comparison_df$R_squared[1]

bii_r2 <- comparison_df$R_squared[2]
diversity_r2 <- comparison_df$R_squared[3]
both_r2 <- comparison_df$R_squared[4]

bii_improve <- (bii_r2 - baseline_r2) / baseline_r2 * 100
diversity_improve <- (diversity_r2 - baseline_r2) / baseline_r2 * 100
both_improve <- (both_r2 - baseline_r2) / baseline_r2 * 100

if (bii_improve > diversity_improve) {
  diff <- (bii_improve - diversity_improve) / diversity_improve * 100
} else {
  diff <- (diversity_improve - bii_improve) / bii_improve * 100
}

synergy <- both_improve - bii_improve - diversity_improve
if (synergy > 0.1) {
} else {
}

# Save
write_csv(comparison_df, file.path(paths$output, "cascade_comparison.csv"))
save(results, file = file.path(paths$output, "cascade_models.RData"))

