# CANVAS 4b FINAL: Normalise BII & Standardise Predictors (M1 Optimised)

library(tidyverse)

paths <- list(
  training_data = "~/Documents/FoodSecurityV2/WorkingData/Canvas4_TrainingData_Final",
  output = "~/Documents/FoodSecurityV2/WorkingData/Canvas4b_Normalised_Final"
)

dir.create(paths$output, showWarnings = FALSE, recursive = TRUE)

# Process one country at a time
for (country_code in c("spain", "uk")) {
  
  country_label <- ifelse(country_code == "spain", "Spain", "UK")
  
  # Load
  file <- file.path(paths$training_data, paste0(country_code, "_training_irrigation.csv"))
  df <- read_csv(file, show_col_types = FALSE)
  
  # Normalise BII to 0-1
  bii_cols <- grep("bii_", colnames(df), value = TRUE)
  for (col in bii_cols) {
    max_val <- max(df[[col]], na.rm = TRUE)
    if (max_val > 1.5) {
      df[[col]] <- df[[col]] / 100
    }
  }
  
  # Scale UK diversity to 60% (realistic)
  if (country_code == "uk") {
    diversity_cols <- grep("crop_diversity", colnames(df), value = TRUE)
    for (col in diversity_cols) {
      df[[col]] <- df[[col]] * 0.6
    }
  }
  
  # Standardise predictors (z-scores)
  predictor_cols <- colnames(df)[!grepl("prop_irrigated|total_area|pixel_id|country", colnames(df))]
  
  std_count <- 0
  for (col in predictor_cols) {
    if (is.numeric(df[[col]])) {
      valid_vals <- df[[col]][!is.na(df[[col]])]
      
      if (length(valid_vals) > 10) {
        col_mean <- mean(valid_vals)
        col_sd <- sd(valid_vals)
        
        if (!is.na(col_sd) && col_sd > 0) {
          df[[col]] <- (df[[col]] - col_mean) / col_sd
          std_count <- std_count + 1
        }
      }
    }
  }
  
  # Save
  out_file <- file.path(paths$output, paste0(country_code, "_training_irrigation_normalised.csv"))
  write_csv(df, out_file)
}

