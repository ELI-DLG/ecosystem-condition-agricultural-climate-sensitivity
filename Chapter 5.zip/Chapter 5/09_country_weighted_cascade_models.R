# CANVAS 5e1: COUNTRY-WEIGHTED CASCADE MODELS
# Purpose: Fit separate BRT cascades for Spain and UK, then combined model
# Question: Are diversity effects significantly different between countries?
# Output: Coefficient comparison + weighted combined model
# Runtime: ~15 minutes

library(gbm)
library(tidyverse)

paths <- list(
  training_data = "~/Documents/FoodSecurityV2/WorkingData/Canvas4b_Normalised_Final_Updated",
  output = "~/Documents/FoodSecurityV2/WorkingData/Canvas5e_Advanced"
)

dir.create(paths$output, showWarnings = FALSE, recursive = TRUE)

# LOAD DATA ONCE

spain_df <- read_csv(file.path(paths$training_data, "spain_training_irrigation_normalised.csv"), 
                     show_col_types = FALSE)
uk_df <- read_csv(file.path(paths$training_data, "uk_training_irrigation_normalised.csv"), 
                  show_col_types = FALSE)

# Add country identifier
spain_df$country <- "Spain"
uk_df$country <- "UK"

# FUNCTION: Fit cascade for one country

fit_cascade_country <- function(df, country_name) {
  
  # Get predictors
  climate_cols <- grep("^.*_(bio|tc_)", colnames(df), value = TRUE)
  diversity_col <- grep("crop_diversity", colnames(df), value = TRUE)[1]
  bii_col <- grep("bii_2015", colnames(df), value = TRUE)[1]
  
  # Define cascade
  cascade_models <- list()
  results_table <- data.frame()
  
  # Model 1: Climate only
  df_model <- df[, c("prop_irrigated", climate_cols)]
  df_model <- df_model[!is.na(df_model$prop_irrigated), ]
  
  set.seed(42)
  model1 <- gbm(
    prop_irrigated ~ .,
    data = df_model,
    distribution = "gaussian",
    n.trees = ifelse(country_name == "Spain", 3500, 2500),
    interaction.depth = ifelse(country_name == "Spain", 3, 2),
    shrinkage = ifelse(country_name == "Spain", 0.005, 0.008),
    bag.fraction = ifelse(country_name == "Spain", 0.75, 0.80),
    train.fraction = 0.9,
    cv.folds = 10,
    verbose = FALSE
  )
  
  best_n_1 <- gbm.perf(model1, method = "cv", plot = FALSE)
  pred_1 <- predict(model1, n.trees = best_n_1)
  r2_1 <- cor(pred_1, df_model$prop_irrigated)^2
  
  cascade_models$Climate_only <- list(model = model1, r2 = r2_1, best_n = best_n_1)
  
  # Model 2: Climate + BII
  df_model <- df[, c("prop_irrigated", climate_cols, bii_col)]
  df_model <- df_model[!is.na(df_model$prop_irrigated), ]
  
  set.seed(42)
  model2 <- gbm(
    prop_irrigated ~ .,
    data = df_model,
    distribution = "gaussian",
    n.trees = ifelse(country_name == "Spain", 3500, 2500),
    interaction.depth = ifelse(country_name == "Spain", 3, 2),
    shrinkage = ifelse(country_name == "Spain", 0.005, 0.008),
    bag.fraction = ifelse(country_name == "Spain", 0.75, 0.80),
    train.fraction = 0.9,
    cv.folds = 10,
    verbose = FALSE
  )
  
  best_n_2 <- gbm.perf(model2, method = "cv", plot = FALSE)
  pred_2 <- predict(model2, n.trees = best_n_2)
  r2_2 <- cor(pred_2, df_model$prop_irrigated)^2
  
  cascade_models$Climate_plus_BII <- list(model = model2, r2 = r2_2, best_n = best_n_2)
  
  # Model 3: Climate + Diversity
  df_model <- df[, c("prop_irrigated", climate_cols, diversity_col)]
  df_model <- df_model[!is.na(df_model$prop_irrigated), ]
  
  set.seed(42)
  model3 <- gbm(
    prop_irrigated ~ .,
    data = df_model,
    distribution = "gaussian",
    n.trees = ifelse(country_name == "Spain", 3500, 2500),
    interaction.depth = ifelse(country_name == "Spain", 3, 2),
    shrinkage = ifelse(country_name == "Spain", 0.005, 0.008),
    bag.fraction = ifelse(country_name == "Spain", 0.75, 0.80),
    train.fraction = 0.9,
    cv.folds = 10,
    verbose = FALSE
  )
  
  best_n_3 <- gbm.perf(model3, method = "cv", plot = FALSE)
  pred_3 <- predict(model3, n.trees = best_n_3)
  r2_3 <- cor(pred_3, df_model$prop_irrigated)^2
  
  cascade_models$Climate_plus_Diversity <- list(model = model3, r2 = r2_3, best_n = best_n_3)
  
  # Model 4: Climate + Both
  df_model <- df[, c("prop_irrigated", climate_cols, bii_col, diversity_col)]
  df_model <- df_model[!is.na(df_model$prop_irrigated), ]
  
  set.seed(42)
  model4 <- gbm(
    prop_irrigated ~ .,
    data = df_model,
    distribution = "gaussian",
    n.trees = ifelse(country_name == "Spain", 3500, 2500),
    interaction.depth = ifelse(country_name == "Spain", 3, 2),
    shrinkage = ifelse(country_name == "Spain", 0.005, 0.008),
    bag.fraction = ifelse(country_name == "Spain", 0.75, 0.80),
    train.fraction = 0.9,
    cv.folds = 10,
    verbose = FALSE
  )
  
  best_n_4 <- gbm.perf(model4, method = "cv", plot = FALSE)
  pred_4 <- predict(model4, n.trees = best_n_4)
  r2_4 <- cor(pred_4, df_model$prop_irrigated)^2
  
  cascade_models$Climate_plus_Both <- list(model = model4, r2 = r2_4, best_n = best_n_4)
  
  # Create comparison table
  results_table <- data.frame(
    Country = country_name,
    Model = c("Climate only", "Climate + BII", "Climate + Diversity", "Climate + Both"),
    R_squared = c(r2_1, r2_2, r2_3, r2_4),
    BII_Improvement = c(NA, (r2_2 - r2_1) / r2_1 * 100, NA, NA),
    Diversity_Improvement = c(NA, NA, (r2_3 - r2_1) / r2_1 * 100, NA),
    Synergy = c(NA, NA, NA, (r2_4 - r2_1 - (r2_2 - r2_1) - (r2_3 - r2_1)) / r2_1 * 100)
  )
  
  return(list(
    models = cascade_models,
    results = results_table,
    country = country_name
  ))
}

# FIT SEPARATE CASCADES

spain_cascade <- fit_cascade_country(spain_df, "Spain")
uk_cascade <- fit_cascade_country(uk_df, "UK")

# COMPARE COUNTRIES

comparison_table <- bind_rows(spain_cascade$results, uk_cascade$results)
print(comparison_table)

# Extract key metrics
spain_div_imp <- spain_cascade$results$Diversity_Improvement[3]
uk_div_imp <- uk_cascade$results$Diversity_Improvement[3]

spain_bii_imp <- spain_cascade$results$BII_Improvement[2]
uk_bii_imp <- uk_cascade$results$BII_Improvement[2]

if (abs(spain_div_imp - uk_div_imp) > 5) {
} else {
}

# SAVE RESULTS

write_csv(comparison_table, file.path(paths$output, "01_country_comparison.csv"))

# Save model details
save(spain_cascade, uk_cascade, 
     file = file.path(paths$output, "country_separate_models.RData"))

# SUMMARY PLOT

png(file.path(paths$output, "01_country_cascade_comparison.png"),
    width = 1000, height = 600)

par(mfrow = c(1, 2), mar = c(5, 4, 3, 2))

# Spain
spain_r2s <- c(
  spain_cascade$results$R_squared[1],
  spain_cascade$results$R_squared[2],
  spain_cascade$results$R_squared[3],
  spain_cascade$results$R_squared[4]
)
models <- c("Climate", "Climate\n+ BII", "Climate\n+ Diversity", "Climate\n+ Both")

barplot(spain_r2s,
        names.arg = models,
        ylim = c(0, max(spain_r2s) * 1.15),
        main = "SPAIN: Cascade Models",
        ylab = "R²",
        col = c("#7f7f7f", "#e67e22", "#8e44ad", "#2ecc71"),
        border = NA)
grid(NA, NULL, lty = 1, col = "grey80")

# Add value labels
text(seq_along(spain_r2s), spain_r2s + 0.01, 
     round(spain_r2s, 3), cex = 0.9, fontface = "bold")

# UK
uk_r2s <- c(
  uk_cascade$results$R_squared[1],
  uk_cascade$results$R_squared[2],
  uk_cascade$results$R_squared[3],
  uk_cascade$results$R_squared[4]
)

barplot(uk_r2s,
        names.arg = models,
        ylim = c(0, max(spain_r2s) * 1.15),  # Match Spain scale
        main = "UK: Cascade Models",
        ylab = "R²",
        col = c("#7f7f7f", "#e67e22", "#8e44ad", "#2ecc71"),
        border = NA)
grid(NA, NULL, lty = 1, col = "grey80")

# Add value labels
text(seq_along(uk_r2s), uk_r2s + 0.01,
     round(uk_r2s, 3), cex = 0.9, fontface = "bold")

dev.off()

# FINAL SUMMARY

    ifelse(abs(spain_div_imp - uk_div_imp) > 5, "DIFFERENT", "SIMILAR"),
    "between countries\n")
    "diversity effect\n\n")

