# CANVAS 5a_CLIMATE_DRIVERS: Which Climate Variables Matter Most?
# Purpose:
#   1. Extract ALL climate variables from model
#   2. Rank by relative importance
#   3. Show Spain vs UK differences
#   4. Identify key climate drivers for irrigation

library(gbm)
library(tidyverse)

paths <- list(
  models = "~/Documents/FoodSecurityV2/WorkingData/Canvas5a_CascadeBRT_Final",
  output = "~/Documents/FoodSecurityV2/WorkingData/Canvas5a_ClimateDrivers"
)

dir.create(paths$output, showWarnings = FALSE, recursive = TRUE)

# Load models

load(file.path(paths$models, "spain_models.RData"))
spain_models <- results

load(file.path(paths$models, "uk_models.RData"))
uk_models <- results

spain_model <- spain_models$Climate_plus_Both$model
spain_best_n <- spain_models$Climate_plus_Both$best_n_trees

uk_model <- uk_models$Climate_plus_Both$model
uk_best_n <- uk_models$Climate_plus_Both$best_n_trees

# Extract importance for ALL variables

spain_rel_inf <- summary(spain_model, n.trees = spain_best_n, plot = FALSE)
uk_rel_inf <- summary(uk_model, n.trees = uk_best_n, plot = FALSE)

# Clean up variable names for readability
clean_variable_name <- function(var_name) {
  # Temperature variables
  if (var_name == "bio1_2015") return("Annual Mean Temperature (BIO1)")
  if (var_name == "bio2_2015") return("Mean Diurnal Range (BIO2)")
  if (var_name == "bio4_2015") return("Temperature Seasonality (BIO4)")
  if (var_name == "tc_tmx_2015") return("Max Temperature (TerraClimate)")
  if (var_name == "tc_tmn_2015") return("Min Temperature (TerraClimate)")
  
  # Precipitation variables
  if (var_name == "bio12_2015") return("Annual Precipitation (BIO12)")
  if (var_name == "bio13_2015") return("Wettest Month (BIO13)")
  if (var_name == "bio14_2015") return("Driest Month (BIO14)")
  if (var_name == "bio15_2015") return("Precipitation Seasonality (BIO15)")
  if (var_name == "tc_pr_2015") return("Precipitation (TerraClimate)")
  
  # Water balance variables
  if (var_name == "tc_aet_2015") return("Actual Evapotranspiration (AET)")
  if (var_name == "tc_def_2015") return("Water Deficit (DEF)")
  if (var_name == "tc_pet_2015") return("Potential Evapotranspiration (PET)")
  if (var_name == "pdsi_2015") return("Palmer Drought Severity Index (PDSI)")
  if (var_name == "tc_soil_2015") return("Soil Moisture")
  
  # Diversity & BII
  if (var_name == "crop_diversity_shannon_2015") return("Crop Diversity (Shannon Index)")
  if (var_name == "spain_2015_bii_2015") return("Biodiversity Intactness Index (BII)")
  
  # If no match, return cleaned version
  return(gsub("_2015$", "", gsub("_", " ", var_name)))
}

# Classify variables
classify_variable <- function(var_name) {
  if (grepl("bio1$|bio2$|bio4$|tc_tmx|tc_tmn", var_name)) {
    return("Temperature")
  } else if (grepl("bio12$|bio13$|bio14$|bio15$|tc_pr", var_name)) {
    return("Precipitation")
  } else if (grepl("tc_aet|tc_def|tc_pet|pdsi", var_name)) {
    return("Water Balance")
  } else if (grepl("tc_soil", var_name)) {
    return("Soil Moisture")
  } else if (grepl("crop_diversity", var_name)) {
    return("Crop Diversity")
  } else if (grepl("bii", var_name)) {
    return("BII")
  } else {
    return("Other")
  }
}

spain_rel_inf$category <- sapply(spain_rel_inf$var, classify_variable)
spain_rel_inf$var_clean <- sapply(spain_rel_inf$var, clean_variable_name)

uk_rel_inf$category <- sapply(uk_rel_inf$var, classify_variable)
uk_rel_inf$var_clean <- sapply(uk_rel_inf$var, clean_variable_name)

# SPAIN: Climate Variable Importance

        arrange(desc(rel.inf)) %>%
        select(var_clean, rel.inf, category) %>%
        mutate(rel.inf = round(rel.inf, 2)) %>%
        rename("Variable" = var_clean, "Importance (%)" = rel.inf, "Category" = category))

# Spain: Climate variables only
spain_climate <- spain_rel_inf %>%
  filter(category %in% c("Temperature", "Precipitation", "Water Balance", "Soil Moisture")) %>%
  arrange(desc(rel.inf))

# Spain: By category
spain_by_cat <- spain_rel_inf %>%
  filter(category %in% c("Temperature", "Precipitation", "Water Balance", "Soil Moisture")) %>%
  group_by(category) %>%
  summarise(
    n_variables = n(),
    total_importance = round(sum(rel.inf), 2),
    max_variable = var[which.max(rel.inf)],
    max_importance = round(max(rel.inf), 2),
    .groups = 'drop'
  ) %>%
  arrange(desc(total_importance))

# UK: Climate Variable Importance

        arrange(desc(rel.inf)) %>%
        select(var_clean, rel.inf, category) %>%
        mutate(rel.inf = round(rel.inf, 2)) %>%
        rename("Variable" = var_clean, "Importance (%)" = rel.inf, "Category" = category))

# UK: Climate variables only
uk_climate <- uk_rel_inf %>%
  filter(category %in% c("Temperature", "Precipitation", "Water Balance", "Soil Moisture")) %>%
  arrange(desc(rel.inf))

# UK: By category
uk_by_cat <- uk_rel_inf %>%
  filter(category %in% c("Temperature", "Precipitation", "Water Balance", "Soil Moisture")) %>%
  group_by(category) %>%
  summarise(
    n_variables = n(),
    total_importance = round(sum(rel.inf), 2),
    max_variable = var[which.max(rel.inf)],
    max_importance = round(max(rel.inf), 2),
    .groups = 'drop'
  ) %>%
  arrange(desc(total_importance))

# COMPARISON: Spain vs UK

# PLOT 1: Climate Variable Importance - Horizontal Bars

png(file.path(paths$output, "01_climate_variables_importance.png"),
    width = 1200, height = 800)

par(mfrow = c(1, 2), mar = c(5, 15, 3, 2))

# Spain - Top 12 climate variables
spain_top_climate <- head(spain_climate, 12)
barplot(spain_top_climate$rel.inf,
        names.arg = spain_top_climate$var_clean,
        horiz = TRUE,
        las = 1,
        main = "Spain: Top 12 Climate Variables",
        xlab = "Relative Influence (%)",
        col = "#e67e22",
        border = NA,
        cex.names = 0.9)
grid(NA, NULL, lty = 1, col = "grey80")

# UK - Top 12 climate variables
uk_top_climate <- head(uk_climate, 12)
barplot(uk_top_climate$rel.inf,
        names.arg = uk_top_climate$var_clean,
        horiz = TRUE,
        las = 1,
        main = "UK: Top 12 Climate Variables",
        xlab = "Relative Influence (%)",
        col = "#3498db",
        border = NA,
        cex.names = 0.9)
grid(NA, NULL, lty = 1, col = "grey80")

dev.off()

# PLOT 2: Climate Categories (Temperature vs Precipitation vs Water Balance)

png(file.path(paths$output, "02_climate_categories_comparison.png"),
    width = 1000, height = 600)

par(mfrow = c(1, 2), mar = c(4, 8, 3, 2))

# Spain by category
spain_cat_order <- spain_by_cat %>% arrange(desc(total_importance))
barplot(spain_cat_order$total_importance,
        names.arg = spain_cat_order$category,
        horiz = TRUE,
        las = 1,
        main = "Spain: Climate Categories",
        xlab = "Total Relative Influence (%)",
        col = c("#e74c3c", "#f39c12", "#2ecc71", "#3498db")[1:nrow(spain_cat_order)],
        border = NA)
grid(NA, NULL, lty = 1, col = "grey80")

# UK by category
uk_cat_order <- uk_by_cat %>% arrange(desc(total_importance))
barplot(uk_cat_order$total_importance,
        names.arg = uk_cat_order$category,
        horiz = TRUE,
        las = 1,
        main = "UK: Climate Categories",
        xlab = "Total Relative Influence (%)",
        col = c("#e74c3c", "#f39c12", "#2ecc71", "#3498db")[1:nrow(uk_cat_order)],
        border = NA)
grid(NA, NULL, lty = 1, col = "grey80")

dev.off()

# PLOT 3: Top Variables Across All Categories

png(file.path(paths$output, "03_top_variables_all_categories.png"),
    width = 1200, height = 600)

par(mfrow = c(1, 2), mar = c(5, 12, 3, 2))

# Spain - Top 15 all variables
spain_top_all <- head(spain_rel_inf %>% arrange(desc(rel.inf)), 15)
colors_spain <- ifelse(spain_top_all$category == "Crop Diversity", "#8e44ad",
                       ifelse(spain_top_all$category == "BII", "#e67e22", "#95a5a6"))
barplot(spain_top_all$rel.inf,
        names.arg = spain_top_all$var_clean,
        horiz = TRUE,
        las = 1,
        main = "Spain: Top 15 Variables (All Categories)",
        xlab = "Relative Influence (%)",
        col = colors_spain,
        border = NA,
        cex.names = 0.85)
legend("bottomright", c("Climate", "Diversity", "BII"),
       col = c("#95a5a6", "#8e44ad", "#e67e22"),
       pch = 15, cex = 0.8)
grid(NA, NULL, lty = 1, col = "grey80")

# UK - Top 15 all variables
uk_top_all <- head(uk_rel_inf %>% arrange(desc(rel.inf)), 15)
colors_uk <- ifelse(uk_top_all$category == "Crop Diversity", "#8e44ad",
                    ifelse(uk_top_all$category == "BII", "#e67e22", "#95a5a6"))
barplot(uk_top_all$rel.inf,
        names.arg = uk_top_all$var_clean,
        horiz = TRUE,
        las = 1,
        main = "UK: Top 15 Variables (All Categories)",
        xlab = "Relative Influence (%)",
        col = colors_uk,
        border = NA,
        cex.names = 0.85)
legend("bottomright", c("Climate", "Diversity", "BII"),
       col = c("#95a5a6", "#8e44ad", "#e67e22"),
       pch = 15, cex = 0.8)
grid(NA, NULL, lty = 1, col = "grey80")

dev.off()

# Export detailed tables to CSV

# Spain full details
spain_export <- spain_rel_inf %>%
  arrange(desc(rel.inf)) %>%
  select(var_clean, rel.inf, category) %>%
  rename(Variable = var_clean, "Importance (%)" = rel.inf, Category = category)

write_csv(spain_export, file.path(paths$output, "spain_all_variables_importance.csv"))

# UK full details
uk_export <- uk_rel_inf %>%
  arrange(desc(rel.inf)) %>%
  select(var_clean, rel.inf, category) %>%
  rename(Variable = var_clean, "Importance (%)" = rel.inf, Category = category)

write_csv(uk_export, file.path(paths$output, "uk_all_variables_importance.csv"))

# Summary comparison
comparison_export <- data.frame(
  Spain_Top_Climate = paste(head(spain_climate$var, 5), collapse = ", "),
  UK_Top_Climate = paste(head(uk_climate$var, 5), collapse = ", "),
  Spain_Key_Finding = paste0("Diversity: ", round(spain_rel_inf$rel.inf[grep("crop_diversity", spain_rel_inf$var)][1], 2), "%, BII: ", 
                             round(spain_rel_inf$rel.inf[grep("bii_2015", spain_rel_inf$var)][1], 2), "%"),
  UK_Key_Finding = paste0("Diversity: ", round(uk_rel_inf$rel.inf[grep("crop_diversity", uk_rel_inf$var)][1], 2), "%, BII: ", 
                          round(uk_rel_inf$rel.inf[grep("bii_2015", uk_rel_inf$var)][1], 2), "%")
)

write_csv(comparison_export, file.path(paths$output, "spain_uk_comparison_summary.csv"))

# Summary Output

spain_top3 <- head(spain_climate, 3)
for (i in 1:nrow(spain_top3)) {
}

uk_top3 <- head(uk_climate, 3)
for (i in 1:nrow(uk_top3)) {
}

# CANVAS 5a_CLIMATE_DRIVERS: Which Climate Variables Matter Most?
# Purpose:
#   1. Extract ALL climate variables from model
#   2. Rank by relative importance
#   3. Show Spain vs UK differences
#   4. Identify key climate drivers for irrigation

