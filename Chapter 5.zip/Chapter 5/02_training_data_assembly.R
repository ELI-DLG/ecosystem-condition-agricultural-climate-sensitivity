# CANVAS 4 FIXED: Training Data Assembly (with diversity alignment)

library(terra)
library(tidyverse)

paths <- list(
  aligned_data = "~/Documents/FoodSecurityV2/WorkingData/Canvas1_Aligned2015",
  diversity_spain = "~/Documents/FoodSecurityV2/WorkingData/Canvas2_Diversity_BIIChange",
  diversity_uk = "~/Documents/FoodSecurityV2/WorkingData/Canvas2b_UKDiversityFine",
  bii_spain = "~/Documents/FoodSecurityV2/Biodiversity/BII_Spatial/spain",
  bii_uk = "~/Documents/FoodSecurityV2/Biodiversity/BII_Spatial/uk",
  output = "~/Documents/FoodSecurityV2/WorkingData/Canvas4_TrainingData_Final"
)

dir.create(paths$output, showWarnings = FALSE, recursive = TRUE)

# Function: Load reference & extract data
process_country <- function(country_code) {
  
  country_label <- ifelse(country_code == "spain", "Spain", "UK")
  
  # Load reference
  bii_path <- if (country_code == "spain") paths$bii_spain else paths$bii_uk
  bii_file <- file.path(bii_path, paste0("bii_", country_code, "_2015.tif"))
  ref <- rast(bii_file)
  
  # Load crops
  crop_files <- list.files(paths$aligned_data, 
                           pattern = paste0("^", country_code, "_2015_.*Irrig|.*Rainfed"),
                           full.names = TRUE)
  
  crops <- lapply(crop_files, rast)
  names(crops) <- tools::file_path_sans_ext(basename(crop_files))
  
  # Load climate
  climate_files <- list.files(paths$aligned_data,
                              pattern = paste0("^", country_code, "_2015_(bio|tc_)"),
                              full.names = TRUE)
  
  climate <- lapply(climate_files, rast)
  names(climate) <- tools::file_path_sans_ext(basename(climate_files))
  
  # Load BII
  bii_files <- list.files(paths$aligned_data,
                          pattern = paste0("^", country_code, "_2015_bii"),
                          full.names = TRUE)
  
  bii <- lapply(bii_files, rast)
  names(bii) <- tools::file_path_sans_ext(basename(bii_files))
  
  # Load diversity (ALIGNED to reference)
  
  div_path <- if (country_code == "spain") paths$diversity_spain else paths$diversity_uk
  
  if (country_code == "spain") {
    div_files <- list.files(div_path, pattern = "^spain_crop_diversity", full.names = TRUE)
  } else {
    div_files <- file.path(div_path, "uk_crop_diversity_shannon_2015_fine.tif")
  }
  
  diversity <- list()
  for (file in div_files) {
    rast_raw <- rast(file)
    
    # Align to reference if needed
    if (!identical(crs(rast_raw), crs(ref)) || 
        !isTRUE(all.equal(ext(rast_raw), ext(ref)))) {
      rast_aligned <- resample(rast_raw, ref, method = "bilinear")
    } else {
      rast_aligned <- rast_raw
    }
    
    name <- tools::file_path_sans_ext(basename(file))
    diversity[[name]] <- rast_aligned
  }
  
  # Combine all (now all same dimensions)
  all_rasts <- c(crops, climate, bii, diversity)
  
  # Extract to dataframe
  
  df <- data.frame(pixel_id = 1:ncell(ref), country = country_label)
  
  for (i in seq_along(all_rasts)) {
    vals <- values(all_rasts[[i]], mat = FALSE)
    df[[names(all_rasts)[i]]] <- vals
    if (i %% 10 == 0) cat("  ", i, "/", length(all_rasts), "\n")
  }
  
  # Calculate irrigation response
  
  irrig_cols <- grep("Irrigated", colnames(df), value = TRUE)
  rainfed_cols <- grep("Rainfed", colnames(df), value = TRUE)
  
  irrig_total <- rowSums(df[, irrig_cols], na.rm = TRUE)
  total_harvest <- rowSums(df[, c(irrig_cols, rainfed_cols)], na.rm = TRUE)
  
  df$prop_irrigated <- ifelse(total_harvest > 0, irrig_total / total_harvest, NA)
  df$total_area_sum <- total_harvest
  
  # Filter: only pixels with harvested area
  df_clean <- df[df$total_area_sum > 0, ]
  
  # Remove NAs
  key_cols <- c("country", "pixel_id", "prop_irrigated",
                grep("^(.*bio|tc_|bii_|crop_diversity)", colnames(df_clean), value = TRUE))
  
  df_clean <- df_clean[complete.cases(df_clean[, key_cols]), ]
  
  # Save
  out_file <- file.path(paths$output, paste0(tolower(country_code), "_training_irrigation.csv"))
  write_csv(df_clean, out_file)
  
  return(df_clean)
}

# Process both countries
spain_df <- process_country("spain")
uk_df <- process_country("uk")

