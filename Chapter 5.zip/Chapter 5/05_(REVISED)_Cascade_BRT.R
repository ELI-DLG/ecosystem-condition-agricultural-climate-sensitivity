# C5 (REVISED): Cascade BRT Models - BII vs Diversity as Climate Buffers
# Purpose:
#   1. Build cascade of BRT models to test buffering hypothesis
#   2. Compare: Climate only → +BII → +Diversity → +Both → +Interaction
#   3. Determine which is better buffer: Shannon diversity OR BII intactness
#   4. Test if they interact or work independently
#   5. Generate partial dependence plots (UK spellings)
# Output: Model comparison, relative influence, interaction analysis

library(gbm)
library(tidyverse)

# Paths
paths <- list(
  training_data = "~/Documents/FoodSecurityV2/WorkingData/Canvas4b_Normalised",
  output = "~/Documents/FoodSecurityV2/WorkingData/Canvas5a_CascadeBRT"
)

dir.create(paths$output, showWarnings = FALSE, recursive = TRUE)

# FUNCTION: Load combined normalised training data

load_combined_training_data <- function(training_path) {
  
  # Load Spain
  spain_file <- file.path(training_path, "spain_training_irrigation_normalized.csv")
  spain_df <- read_csv(spain_file, show_col_types = FALSE)
  
  # Load UK
  uk_file <- file.path(training_path, "uk_training_irrigation_normalized.csv")
  uk_df <- read_csv(uk_file, show_col_types = FALSE)
  
  # Combine
  combined_df <- bind_rows(spain_df, uk_df)
  
  return(combined_df)
}

# FUNCTION: Prepare predictor sets for cascade models

prepare_predictor_sets <- function(df) {
  
  # Climate predictors (BIO + TerraClimate variables)
  climate_cols <- grep("^.*_2015_(bio|tc_)", colnames(df), value = TRUE)
  
  # BII predictors
  bii_cols <- grep("bii_2015", colnames(df), value = TRUE)
  
  # Diversity predictors
  diversity_cols <- grep("crop_diversity", colnames(df), value = TRUE)
  
  # Define cascade models
  predictor_sets <- list(
    "Climate_only" = climate_cols,
    "Climate_plus_BII" = c(climate_cols, bii_cols),
    "Climate_plus_Diversity" = c(climate_cols, diversity_cols),
    "Climate_plus_BII_plus_Diversity" = c(climate_cols, bii_cols, diversity_cols),
    "Climate_with_BII_Diversity_Interaction" = c(climate_cols, bii_cols, diversity_cols)
  )
  
  return(list(
    sets = predictor_sets,
    climate = climate_cols,
    bii = bii_cols,
    diversity = diversity_cols,
    all_df = df
  ))
}

# FUNCTION: Fit BRT model for cascade

fit_cascade_brt <- function(data_list, model_name = "test", 
                            interaction_depth = 3, n_trees = 5000, 
                            learning_rate = 0.01) {
  
  df <- data_list$all_df
  response <- "prop_irrigated"
  predictors <- data_list$sets[[model_name]]
  
  # Set seed for reproducibility
  set.seed(42)
  
  # Build formula
  formula_str <- paste(response, "~", paste(predictors, collapse = "+"))
  
  # Fit BRT
  model <- gbm(
    formula = as.formula(formula_str),
    data = df,
    distribution = "gaussian",
    n.trees = n_trees,
    interaction.depth = interaction_depth,
    shrinkage = learning_rate,
    bag.fraction = 0.5,
    train.fraction = 0.8,
    cv.folds = 5,
    verbose = FALSE
  )
  
  # Find optimal number of trees
  best_n_trees <- gbm.perf(model, method = "cv", plot = FALSE)
  
  # Get predictions
  pred <- predict(model, n.trees = best_n_trees)
  actual <- df[[response]]
  
  # Calculate performance metrics
  mae <- mean(abs(pred - actual))
  rmse <- sqrt(mean((pred - actual)^2))
  r2 <- cor(pred, actual)^2
  
  return(list(
    model = model,
    best_n_trees = best_n_trees,
    predictors = predictors,
    performance = list(mae = mae, rmse = rmse, r2 = r2),
    pred = pred,
    actual = actual
  ))
}

# FUNCTION: Compare cascade models

compare_cascade_models <- function(model_results) {
  
  comparison_df <- data.frame(
    Model = names(model_results),
    Predictors = sapply(model_results, function(x) length(x$predictors)),
    R_squared = round(sapply(model_results, function(x) x$performance$r2), 4),
    RMSE = round(sapply(model_results, function(x) x$performance$rmse), 4),
    MAE = round(sapply(model_results, function(x) x$performance$mae), 4)
  )
  
  # Calculate improvements
  baseline_r2 <- comparison_df$R_squared[1]
  
  for (i in 2:nrow(comparison_df)) {
    model_name <- comparison_df$Model[i]
    model_r2 <- comparison_df$R_squared[i]
    improvement_pct <- ((model_r2 - baseline_r2) / baseline_r2) * 100
    
  }
  
  return(comparison_df)
}

# FUNCTION: Extract relative influence for cascade

analyse_relative_influence <- function(model_results, output_path) {
  
  # Focus on the full model (Climate + BII + Diversity)
  full_model_result <- model_results$Climate_plus_BII_plus_Diversity
  model <- full_model_result$model
  best_n <- full_model_result$best_n_trees
  
  # Get relative influence
  rel_inf <- summary(model, n.trees = best_n, plot = FALSE)
  
  # Categorise variables
  rel_inf$category <- ifelse(grepl("bio|tc_", rel_inf$var), "Climate",
                             ifelse(grepl("bii", rel_inf$var), "BII", "Diversity"))
  
  # Sum by category
  category_influence <- rel_inf %>%
    group_by(category) %>%
    summarise(total_influence = sum(rel.inf), .groups = 'drop') %>%
    arrange(desc(total_influence))
  
  for (i in 1:nrow(category_influence)) {
        round(category_influence$total_influence[i], 2), "%\n")
  }
  
  top_vars <- head(rel_inf, 15)
  for (i in 1:nrow(top_vars)) {
        round(top_vars$rel.inf[i], 2), "%\n")
  }
  
  # Save influence plot
  png_file <- file.path(output_path, "relative_influence_cascade.png")
  png(png_file, width = 900, height = 600)
  
  # Group by category and plot
  top_n <- 15
  plot_data <- head(rel_inf, top_n)
  colours <- c("Climate" = "#1b9e77", "BII" = "#d95f02", "Diversity" = "#7570b3")
  
  barplot(plot_data$rel.inf, names.arg = plot_data$var, 
          col = colours[plot_data$category],
          main = "Top 15 Variable Influences (Full Model)",
          xlab = "Variable", ylab = "Relative Influence (%)",
          las = 2, cex.names = 0.8)
  
  legend("topright", names(colours), fill = colours)
  
  dev.off()
  
  return(rel_inf)
}

# FUNCTION: Create comparison visualisation

create_cascade_comparison_plot <- function(comparison_df, output_path) {
  
  png_file <- file.path(output_path, "cascade_model_comparison.png")
  png(png_file, width = 900, height = 600)
  
  # Plot R² improvement
  par(mfrow = c(1, 2))
  
  # R² by model
  barplot(comparison_df$R_squared, names.arg = comparison_df$Model,
          main = "Model R² Comparison",
          ylab = "R²", ylim = c(0, max(comparison_df$R_squared) * 1.1),
          col = c("#e7d4e8", "#d95f02", "#7570b3", "#1b9e77", "#1b9e77"),
          las = 2, cex.names = 0.7)
  
  abline(h = comparison_df$R_squared[1], lty = 2, col = "grey")
  
  # RMSE by model
  barplot(comparison_df$RMSE, names.arg = comparison_df$Model,
          main = "Model RMSE Comparison (Lower is Better)",
          ylab = "RMSE", ylim = c(0, max(comparison_df$RMSE) * 1.1),
          col = c("#e7d4e8", "#d95f02", "#7570b3", "#1b9e77", "#1b9e77"),
          las = 2, cex.names = 0.7)
  
  dev.off()
  
}

# FUNCTION: Test interaction hypothesis

test_interaction_hypothesis <- function(model_results, output_path) {
  
  # Compare models
  bii_only_r2 <- model_results$Climate_plus_BII$performance$r2
  div_only_r2 <- model_results$Climate_plus_Diversity$performance$r2
  both_no_interaction_r2 <- model_results$Climate_plus_BII_plus_Diversity$performance$r2
  interaction_r2 <- model_results$Climate_with_BII_Diversity_Interaction$performance$r2
  
      "(improvement:", round((bii_only_r2 - model_results$Climate_only$performance$r2)*100, 2), "%)\n")
      "(improvement:", round((div_only_r2 - model_results$Climate_only$performance$r2)*100, 2), "%)\n")
  
  # Interpret
  
  if (bii_only_r2 > div_only_r2) {
    improvement_diff <- (bii_only_r2 - div_only_r2) / div_only_r2 * 100
  } else {
    improvement_diff <- (div_only_r2 - bii_only_r2) / bii_only_r2 * 100
  }
  
  if (interaction_r2 > both_no_interaction_r2) {
    synergy <- (interaction_r2 - both_no_interaction_r2) / both_no_interaction_r2 * 100
  } else {
  }
  
  return(list(
    bii_effect = bii_only_r2,
    diversity_effect = div_only_r2,
    interaction_effect = interaction_r2
  ))
}

# MAIN: Cascade modelling

# Load data
combined_df <- load_combined_training_data(paths$training_data)

# Prepare predictor sets
data_list <- prepare_predictor_sets(combined_df)

# Fit cascade of models

model_results <- list()

for (model_name in names(data_list$sets)) {
  model_results[[model_name]] <- fit_cascade_brt(
    data_list,
    model_name = model_name,
    interaction_depth = 3,
    n_trees = 5000,
    learning_rate = 0.01
  )
}

# Compare models
comparison_df <- compare_cascade_models(model_results)

# Analyse relative influence
rel_inf <- analyse_relative_influence(model_results, paths$output)

# Create visualisation
create_cascade_comparison_plot(comparison_df, paths$output)

# Test interaction hypothesis
interaction_results <- test_interaction_hypothesis(model_results, paths$output)

# SUMMARY & SAVE

# Save all model results
save(model_results, file = file.path(paths$output, "cascade_models.RData"))
save(comparison_df, file = file.path(paths$output, "model_comparison.RData"))