# CANVAS 2b: UK Crop Diversity - Fine Resolution (M1 Optimised)

library(terra)
library(tidyverse)

paths <- list(
  aligned_data = "~/Documents/FoodSecurityV2/WorkingData/Canvas1_Aligned2015",
  output = "~/Documents/FoodSecurityV2/WorkingData/Canvas2b_UKDiversityFine"
)

dir.create(paths$output, showWarnings = FALSE, recursive = TRUE)

# Load UK crops

files <- list.files(paths$aligned_data, 
                    pattern = "^uk_2015_.*Irrig|.*Rainfed",
                    full.names = TRUE)

crop_rasts <- list()
for (file in files) {
  name <- tools::file_path_sans_ext(basename(file))
  crop_rasts[[name]] <- rast(file)
}

# Calculate Shannon diversity

ref <- crop_rasts[[1]]
diversity <- ref * NA

pb <- txtProgressBar(min = 0, max = ncell(ref), style = 3)

for (pixel in 1:ncell(ref)) {
  
  pixel_values <- c()
  
  for (i in seq_along(crop_rasts)) {
    val <- as.numeric(crop_rasts[[i]][pixel])
    if (!is.na(val) && val > 0) {
      pixel_values <- c(pixel_values, val)
    }
  }
  
  if (length(pixel_values) > 0) {
    total <- sum(pixel_values)
    if (total > 0) {
      proportions <- pixel_values / total
      proportions <- proportions[proportions > 0]
      shannon_h <- -sum(proportions * log(proportions))
      diversity[pixel] <- shannon_h
    }
  }
  
  setTxtProgressBar(pb, pixel)
}

close(pb)

# Save
out_file <- file.path(paths$output, "uk_crop_diversity_shannon_2015_fine.tif")
writeRaster(diversity, out_file, overwrite = TRUE)

