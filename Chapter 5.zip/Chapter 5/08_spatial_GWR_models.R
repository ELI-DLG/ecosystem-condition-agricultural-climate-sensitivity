# CANVAS 5b: Spatial Models - Geographically Weighted Regression
# Purpose:
#   1. Build spatially-explicit models using GWR (geographically weighted regression)
#   2. Estimate LOCAL coefficients for diversity buffering effect
#   3. Map diversity × climate interaction strength across space
#   4. Identify regions where diversity buffering is strongest/weakest
#   5. Test spatial autocorrelation in residuals
# Output: Local coefficient maps, interaction strength maps, spatial diagnostics

library(terra)
library(sf)
library(tidyverse)
library(spgwr)  # For GWR

# Paths
paths <- list(
  training_data = "~/Documents/FoodSecurityV2/WorkingData/Canvas4_TrainingData",
  bii_spatial_spain = "~/Documents/FoodSecurityV2/Biodiversity/BII_Spatial/spain",
  bii_spatial_uk = "~/Documents/FoodSecurityV2/Biodiversity/BII_Spatial/uk",
  output = "~/Documents/FoodSecurityV2/WorkingData/Canvas5b_SpatialBRT"
)

dir.create(paths$output, showWarnings = FALSE, recursive = TRUE)

# FUNCTION: Load training data with coordinates

load_training_with_coords <- function(training_path) {
  
  # Load Spain
  spain_file <- file.path(training_path, "spain_training_irrigation.csv")
  spain_df <- read_csv(spain_file, show_col_types = FALSE)
  spain_df$country <- "Spain"
  
  # Load UK
  uk_file <- file.path(training_path, "uk_training_irrigation.csv")
  uk_df <- read_csv(uk_file, show_col_types = FALSE)
  uk_df$country <- "UK"
  
  # Combine
  combined_df <- bind_rows(spain_df, uk_df)
  
  # We need pixel coordinates - get from reference rasters
  
  # For Spain
  spain_ref <- rast("~/Documents/FoodSecurityV2/Biodiversity/BII_Spatial/spain/bii_spain_2015.tif")
  spain_coords <- xyFromCell(spain_ref, spain_df$pixel_id)
  spain_df$x <- spain_coords[, 1]
  spain_df$y <- spain_coords[, 2]
  
  # For UK
  uk_ref <- rast("~/Documents/FoodSecurityV2/Biodiversity/BII_Spatial/uk/bii_uk_2015.tif")
  uk_coords <- xyFromCell(uk_ref, uk_df$pixel_id)
  uk_df$x <- uk_coords[, 1]
  uk_df$y <- uk_coords[, 2]
  
  # Recombine with coordinates
  combined_df <- bind_rows(spain_df, uk_df)
  
  return(combined_df)
}

# FUNCTION: Prepare GWR dataset

prepare_gwr_dataset <- function(df) {
  
  # Select key predictors (subset for computational efficiency)
  # Focus on: climate seasonality, BII, diversity
  
  gwr_cols <- c(
    "x", "y",  # Coordinates
    "prop_irrigated",  # Response
    grep("bio1|bio2|bio4|bio7|bio12|bio15", colnames(df), value = TRUE)[1:6],  # Climate
    grep("bii_2015", colnames(df), value = TRUE)[1],  # BII
    grep("crop_diversity_shannon|crop_diversity_focal5x5", colnames(df), value = TRUE)[1:2]  # Diversity
  )
  
  gwr_df <- df[, gwr_cols]
  gwr_df <- na.omit(gwr_df)
  
  return(gwr_df)
}

# FUNCTION: Fit GWR model

fit_gwr_model <- function(gwr_df) {
  
  # Convert to sp object for gwr.basic
  coordinates(gwr_df) <- ~x+y
  
  # Build formula
  formula <- prop_irrigated ~ .
  
  # Compute adaptive bandwidth (using CV)
  bw <- bw.gwr(
    formula,
    data = gwr_df,
    approach = "AIC",
    adaptive = TRUE,
    p = 2
  )
  
  # Fit GWR
  
  gwr_model <- gwr.basic(
    formula,
    data = gwr_df,
    bw = bw,
    adaptive = TRUE,
    p = 2
  )
  
  return(list(
    model = gwr_model,
    data = gwr_df,
    bandwidth = bw
  ))
}

# FUNCTION: Extract local coefficients

extract_local_coefficients <- function(gwr_list) {
  
  gwr_model <- gwr_list$model
  gwr_df <- gwr_list$data
  
  # Get local coefficients
  local_coefs <- gwr_model$SDF@data
  
  # Calculate statistics on diversity coefficient
  # Find diversity column
  diversity_cols <- grep("diversity", colnames(local_coefs), value = TRUE)
  
  if (length(diversity_cols) > 0) {
    div_coef <- local_coefs[[diversity_cols[1]]]
    
        round(max(div_coef, na.rm = TRUE), 4), "\n")
    
    # Proportion negative (protective)
    n_negative <- sum(div_coef < 0, na.rm = TRUE)
    pct_negative <- (n_negative / length(div_coef)) * 100
    
        n_negative, "(", round(pct_negative, 1), "%)\n")
  }
  
  return(local_coefs)
}

# FUNCTION: Map local coefficients back to raster

map_coefficients_to_raster <- function(gwr_list, local_coefs, output_path) {
  
  gwr_df <- gwr_list$data
  
  # Load reference rasters
  spain_ref <- rast("~/Documents/FoodSecurityV2/Biodiversity/BII_Spatial/spain/bii_spain_2015.tif")
  uk_ref <- rast("~/Documents/FoodSecurityV2/Biodiversity/BII_Spatial/uk/bii_uk_2015.tif")
  
  # Get country assignments
  spain_n <- ncell(spain_ref)
  
  spain_local_coefs <- local_coefs[1:nrow(gwr_df[gwr_df@coords[, 1] < 0, ]), ]  # Approximate
  
  # Create rasters for key coefficients
  coef_cols <- grep("diversity|bii", colnames(local_coefs), value = TRUE)
  
  for (coef_col in coef_cols) {
    
    # Create empty raster
    coef_rast <- spain_ref * NA
    
    # Fill with coefficients
    pixel_ids <- gwr_df@coords  # This needs proper mapping
    
    # Simplified approach: save as dataframe for now
    coef_df <- data.frame(
      pixel_id = 1:nrow(local_coefs),
      coef_value = local_coefs[[coef_col]]
    )
    
    # Save coefficient CSV
    coef_csv <- file.path(output_path, paste0("local_coef_", coef_col, ".csv"))
    write_csv(coef_df, coef_csv)
    
  }
}

# FUNCTION: Test spatial autocorrelation

test_spatial_autocorrelation <- function(gwr_list) {
  
  gwr_model <- gwr_list$model
  
  # Get global model residuals
  residuals <- gwr_model$residuals
  
  # Moran's I would require spatial weights matrix
  # For now, just report residual distribution
  
  return(residuals)
}

# MAIN: Spatial modelling

# Load data with coordinates
combined_df <- load_training_with_coords(paths$training_data)

# Prepare for GWR
gwr_data <- prepare_gwr_dataset(combined_df)

# Fit GWR
gwr_result <- fit_gwr_model(gwr_data)

# Extract local coefficients
local_coefs <- extract_local_coefficients(gwr_result)

# Map coefficients to rasters
map_coefficients_to_raster(gwr_result, local_coefs, paths$output)

# Test spatial autocorrelation
residuals <- test_spatial_autocorrelation(gwr_result)

# SUMMARY

